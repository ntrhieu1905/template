$(document).ready(function(){
    $('#birthday_from_csv').val($('[name="birthday_from"]').val());
    $('[name="birthday_from"]').change(function () {
        $('#birthday_from_csv').val($(this).val());
    });
    $('#birthday_to_csv').val($('[name="birthday_to"]').val());
    $('[name="birthday_to"]').change(function () {
        $('#birthday_to_csv').val($(this).val());
    });
    $('#csv-export-tmp').click(function () {
        var form = $('form');
        form.each(function (i, obj) {
            var frma005 = $('#frma005').find('input').clone();
            if($(obj).is(':hidden')) {
                $(obj).append(frma005);
            }
        });
        //append to postLink form then click csv-export button
        setTimeout(
            function()
            {
                $('#csv-export').click();
            }, 500); //Set the time 500 to wait for the button to click next time
    });
});