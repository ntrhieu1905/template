<?php
/**
 * Created by PhpStorm.
 * User: dat.tnt
 * Date: 2019/10/23
 * Time: 12:24
 */
namespace App\Controller;

use App\Libs\ConfigUtil;
use App\Libs\ValueUtil;
use App\Libs\DateUtil;
use Cake\Event\Event;
use Cake\ORM\TableRegistry;
use App\Libs\ExportDataUtil;

/**
 * Fan content controller
 */
class FanController extends AppAdminController
{
    /**
     * Override beforeFilter callback
     *
     * @return \Cake\Network\Response|null|void
     */
    public function beforeFilter(Event $event) {
        parent::beforeFilter($event);
        //Load common model
        $this->loadModel('Fan');
    }

    /**
     * A005 ファン一覧
     * A005
     */
    public function a005() {
        //get user_flg from session
        $user_flg = $this->Auth->user()['user_flg'];
        //Get login user data
        $session = $this->getRequest()->getSession();
        //Check searching data session
        $params = [];
        if($session->check('Fan.a005')) {// when have session
            $params = $session->read('Fan.a005');
            $this->set([
                'searchData' => $params,
            ]);
        }
        //Process after submit form
        if($this->getRequest()->is(['post'])) {
            $searchData = $this->getRequest()->getData();
            //Write session
            $session->delete('Fan.a005');
            $session->write('Fan.a005', $searchData);
            //redirect to a020
            if(isset($searchData['mail-btn'])) {
                return $this->redirect(['controller' => 'Mai', 'action' => 'a020']);
            }
            //Reload page
            return $this->redirect(['action' => 'a005']);
        }
        //Get records from database then paginate result
        $result = $this->Fan->search($params);
        $disabled = true;
        if(!empty($result->toArray())) {
            $disabled = false;
        }
        $fans = $this->paginate($result, ['limit' => ConfigUtil::get('paginate.ten_pages')]);
        //Show list evaluation
        $this->set(compact('fans', 'disabled', 'user_flg'));
        $this->set('_serialize', ['fans']);
    }

    /**
     * A006 ファン表示
     * A006
     */
    public function a006($id =null) {
        //Check valid Id
        if(empty($id) || !is_numeric($id)){
            return $this->redirect(['controller' => 'Top', 'action' => 'error']);
        }
        //get data of fan
        $fan = $this->Fan->getFanById($id);
        if(empty($fan)){
            return $this->redirect(['controller' => 'Top', 'action' => 'error']);
        }
        //explode interest
        $interest_arr = [];
        if(!empty($fan['interest'])) {
            $interest_arr = explode(',', $fan['interest']);
        }
        //config data
        $join_checkbox = $this->processCheckbox($fan);
        //Show list evaluation
        $this->set(compact('fan', 'join_checkbox', 'interest_arr'));
    }

    /**
     * A007 ファン編集
     * A007
     */
    public function a007($id =null) {
        //Check valid Id
        if(empty($id) || !is_numeric($id)){
            return $this->redirect(['controller' => 'Top', 'action' => 'error']);
        }
        //get data of fan
        $fan = $this->Fan->getFanById($id);
        if(empty($fan)){
            return $this->redirect(['controller' => 'Top', 'action' => 'error']);
        }
        $fanTable = 'Fan';
        if($this->getRequest()->is(['post', 'put', 'patch'])) {
            $params = $this->getRequest()->getData();
            $params = $this->processDataOnProScreen($params);
            //load query component
            $queryComponent = $this->loadComponent('Query');
            //Check duplicate email
            $fanExisted = $queryComponent->checkEmailExisted('Fan', $params['email'], $params['id_fan'])->first();
            if ($fanExisted) {
                $this->set(compact('fan'));
                return $this->Flash->error(ConfigUtil::getMessage('ECL049',['メールアドレス']));
            }
            //save staff data
            $fan = $queryComponent->saveTable($fanTable, $params, $id);
            //check when save data not success
            if(is_bool($fan)) {
                $this->set(compact('fan'));
                return $this->Flash->error(ConfigUtil::getMessage('UPDATE_FAILURE'));
            }
            if(empty($fan->getErrors())) {
                $this->Flash->success(ConfigUtil::getMessage('UPDATE_SUCCESS'));
                return $this->redirect(['action' => 'a005']);
            }
            $this->showErrors($fan->getErrors());
        }
        //process data export to screen
        $fan = $this->processDataExportScreen($fan);
        //Show list evaluation
        $this->set(compact('fan'));
    }

    /**
     * process data export to screen
     * @return object
     */
    public function processDataExportScreen($fan) {
        if(!empty($fan['user_name'])) {
            $user_name = explode(' ', $fan['user_name']);
            if(count($user_name) > 1) {
                $fan['user_name_first'] = $user_name[0];
                $fan['user_name_last'] = '';
                for ($i = 1; $i < count($user_name); $i++) {
                    $fan['user_name_last'] .= $user_name[$i].' ';
                }
                $fan['user_name_last'] = rtrim($fan['user_name_last']);
            } else {
                $fan['user_name_first'] = $user_name[0];
            }
        }
        if(!empty($fan['user_kana'])) {
            $user_kana = explode(' ', $fan['user_kana']);
            if(count($user_kana) > 1) {
                $fan['user_kana_first'] = $user_kana[0];
                $fan['user_kana_last'] = '';
                for ($i = 1; $i < count($user_kana); $i++) {
                    $fan['user_kana_last'] .= $user_kana[$i].' ';
                }
                $fan['user_kana_last'] = rtrim($fan['user_kana_last']);
            } else {
                $fan['user_kana_first'] = $user_kana[0];
            }
        }
        if(!empty($fan['birthday']) && gettype($fan['birthday']) == 'object') {
            $fan['birthday'] = $fan['birthday']->format('Y/m/d');
        }
        $checkbox_list = [
            'sns_relation',
            'used_sns',
            'interest',
            'read',
            'bukatsu',
        ];
        foreach ($checkbox_list as $check) {
            if(isset($fan[$check])) {
                $fan[$check] = explode(',', $fan[$check]);
            }
        }
        return $fan;
    }

    /**
     * process data enter on screen
     * @return array
     */
    public function processDataOnProScreen($params) {
        if(empty($params['user_name_first']) || empty($params['user_name_last'])) {
            $params['user_name'] = '';
        } else {
            $params['user_name'] = $params['user_name_first'].' '.$params['user_name_last'];
        }
        if(empty($params['user_kana_first']) || empty($params['user_kana_last'])) {
            $params['user_kana'] = '';
        } else {
            $params['user_kana'] = $params['user_kana_first'].' '.$params['user_kana_last'];
        }
        if(!isset($params['job_type_other'])) {
            $params['job_type_other'] = null;
        }
        if(!isset($params['working_type_other'])) {
            $params['working_type_other'] = null;
        }
        if(!isset($params['interest_other'])) {
            $params['interest_other'] = null;
        }
        //process password
        if(!empty($params['password_edit'])) {
            $params['password'] = $params['password_edit'];
        }
        $checkbox_list = [
            'sns_relation',
            'used_sns',
            'interest',
            'read',
            'bukatsu'
        ];
        foreach ($checkbox_list as $check) {
            if(!empty($params[$check])) {
                $params[$check] = implode(',', $params[$check]);
            }
        }
        //Replace empty value with null value
        foreach ($params as $key => $value) {
            if ($value == '') {
                 $params[$key] = null;
            }
        }
        return $params;
    }

    /**
     * Remote check exists email
     */
    public function checkExistsEmail() {
        if ($this->getRequest()->is(['post'])) {
            $data = $this->getRequest()->getData();
            $queryComponent = $this->loadComponent('Query');
            $fan = $queryComponent->checkEmailExisted('Fan', $data['email'], $data['id'])->first();
            echo $fan ? false : true;
        }
        exit();
    }

    /**
     * ajax get working_area list
     * @return \Cake\Network\Response|null
     */
    public function getWorkingAreaList() {
        $params = $this->getRequest()->getData();
        $workingAreaList = [];
        if(!empty($params['area'])) {
            $area = $params['area'];
            if($area == 1) {
                $workingAreaList = ValueUtil::get('fan.working_area_custom_1');
            } elseif($area == 2) {
                $workingAreaList = ValueUtil::get('fan.working_area_custom_2');
            } elseif($area == 3) {
                $workingAreaList = ValueUtil::get('fan.working_area_custom_3');
            } else {
                $workingAreaList = ValueUtil::get('fan.working_area_custom_4');
            }
        }
        echo json_encode($workingAreaList);
        exit();
    }

    public function processCheckbox($fan) {
        $checkbox_list = [
            'sns_relation' => \App\Libs\ValueUtil::get('fan.sns_relation'),
            'used_sns' => \App\Libs\ValueUtil::get('fan.used_sns'),
            'interest' => \App\Libs\ValueUtil::get('fan.interest'),
            'read' => ValueUtil::get('fan.read'),
            'bukatsu' => ValueUtil::get('fan.bukatsu')
        ];
        $join_checkbox = [];
        foreach ($checkbox_list as $key => $check) {
            if(!empty($fan[$key])) {
                $fan[$key] = explode(',', $fan[$key]);
                foreach ($fan[$key] as $value) {
                    $fan[$key] = [];
                    if(isset($checkbox_list[$key][$value])){
                        $join_checkbox[$key][] = $checkbox_list[$key][$value];
                    }
                }
                if(!empty($join_checkbox[$key])) {
                    $join_checkbox[$key] = implode('、 ', $join_checkbox[$key]);
                }
            }
        }
        return $join_checkbox;
    }

    /**
     * export Csv
     */
    public function exportCsv() {
        if ($this->getRequest()->is(['post'])) {
            $params = $this->getRequest()->getData();
            $params['birthday_from'] = isset($params['birthday_from_csv']) ? $params['birthday_from_csv'] : '';
            $params['birthday_to'] = isset($params['birthday_to_csv']) ? $params['birthday_to_csv'] : '';
            //Get records from database then paginate result
            $fans = $this->Fan->search($params)->toArray();
            // get header
            $header = ValueUtil::get('fan.header_csv');
            // value options
            $options = [
                'sex' => ValueUtil::get('fan.sex'),
                'sns_relation' => ValueUtil::get('fan.sns_relation'),
                'job_type' => ValueUtil::get('fan.job_type'),
                'prefecture' => ValueUtil::get('fan.prefecture'),
                'working_type' => ValueUtil::get('fan.working_type'),
                'used_sns' => ValueUtil::get('fan.used_sns'),
                'interest' => ValueUtil::get('fan.interest'),
                'read' => ValueUtil::get('fan.read'),
                'bukatsu_join' => ValueUtil::get('fan.bukatsu_join'),
                'working_area' => ValueUtil::get('fan.working_area'),
                'area' => ValueUtil::get('fan.area'),
                'bukatsu' => ValueUtil::get('fan.bukatsu'),
                'black_flg' => ValueUtil::get('fan.black_flg'),
                'payment_method' => ValueUtil::get('fan.payment_method'),
                'status' => ValueUtil::get('fan.status'),
                'reg_route' => ValueUtil::get('fan.reg_route'),
                'del_flg' => ValueUtil::get('common.del_flg'),
            ];
            $listFans = [];
            $listFans[] = $header;
            foreach ($fans as $fan) {
                $arrData = [];
                $fan['birthday'] = !empty($fan['birthday']) ? DateUtil::getJapaneseDate($fan['birthday']) : '';
                $fan['access_token_expire'] = !empty($fan['access_token_expire']) ? DateUtil::getJapaneseDate($fan['access_token_expire'], true) : '';
                $fan['last_login'] = !empty($fan['last_login']) ? DateUtil::getJapaneseDate($fan['last_login'], false, true) : '';
                $fan['created_at'] = !empty($fan['created_at']) ? DateUtil::getJapaneseDate($fan['created_at'], false, true) : '';
                $fan['updated_at'] = !empty($fan['updated_at']) ? DateUtil::getJapaneseDate($fan['updated_at'], false, true) : '';
                $fan['deleted_at'] = !empty($fan['deleted_at']) ? DateUtil::getJapaneseDate($fan['deleted_at'], false, true) : '';
                $fan['created_by'] = !empty($fan['created_staff']['user_name']) ? $fan['created_staff']['user_name'] : '';
                $fan['updated_by'] = !empty($fan['updated_staff']['user_name']) ? $fan['updated_staff']['user_name'] : '';
                $fan['deleted_by'] = !empty($fan['deleted_staff']['user_name']) ? $fan['deleted_staff']['user_name'] : '';
                $fan['sex'] = isset($fan['sex']) && isset($options['sex'][$fan['sex']]) ? $options['sex'][$fan['sex']] : '';
                $fan['job_type'] = isset($fan['job_type']) && isset($options['job_type'][$fan['job_type']]) ? $options['job_type'][$fan['job_type']] : '';
                $fan['prefecture'] = isset($fan['prefecture']) && isset($options['prefecture'][$fan['prefecture']]) ? $options['prefecture'][$fan['prefecture']] : '';
                $fan['working_type'] = isset($fan['working_type']) && isset($options['working_type'][$fan['working_type']]) ? $options['working_type'][$fan['working_type']] : '';
                $fan['bukatsu_join'] = isset($fan['bukatsu_join']) && isset($options['bukatsu_join'][$fan['bukatsu_join']]) ? $options['bukatsu_join'][$fan['bukatsu_join']] : '';
                $fan['working_area'] = isset($fan['working_area']) && isset($options['working_area'][$fan['working_area']]) ? $options['working_area'][$fan['working_area']] : '';
                $fan['area'] = isset($fan['area']) && isset($options['area'][$fan['area']]) ? $options['area'][$fan['area']] : '';
                $fan['black_flg'] = isset($fan['black_flg']) && isset($options['black_flg'][$fan['black_flg']]) ? $options['black_flg'][$fan['black_flg']] : '';
                $fan['payment_method'] = isset($fan['payment_method']) && isset($options['payment_method'][$fan['payment_method']]) ? $options['payment_method'][$fan['payment_method']] : '';
                $fan['status'] = isset($fan['status']) && isset($options['status'][$fan['status']]) ? $options['status'][$fan['status']] : '';
                $fan['reg_route'] = isset($fan['reg_route']) && isset($options['reg_route'][$fan['reg_route']]) ? $options['reg_route'][$fan['reg_route']] : '';
                $fan['del_flg'] = isset($fan['del_flg']) && isset($options['del_flg'][$fan['del_flg']]) ? $options['del_flg'][$fan['del_flg']] : '';
                $join_checkbox = $this->processCheckbox($fan);
                $fan['sns_relation'] = isset($join_checkbox['sns_relation']) ? $join_checkbox['sns_relation'] : '';
                $fan['used_sns'] = isset($join_checkbox['used_sns']) ? $join_checkbox['used_sns'] : '';
                $fan['interest'] = isset($join_checkbox['interest']) ? $join_checkbox['interest'] : '';
                $fan['read'] = isset($join_checkbox['read']) ? $join_checkbox['read'] : '';
                $fan['bukatsu'] = isset($join_checkbox['bukatsu']) ? $join_checkbox['bukatsu'] : '';
                //add column name to csv
                foreach ($header as $colName => $colTitle) {
                    $arrData[$colName] = !empty($fan[$colName]) ? $fan[$colName] : '';
                }
                $listFans[] = $arrData;
            }
            // Csv file name
            $fileName = 'A005_'. DateUtil::getFileNameByCurrentTime() . '.csv';
            // excecute export csv
            $exportData = new ExportDataUtil();
            $exportData->exportCSV($listFans, $fileName);
        }
    }
}
