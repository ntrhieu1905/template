<?php
namespace App\Model\Table;

use Cake\I18n\Date;
use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;
use App\Libs\ValueUtil;
use App\Libs\ConfigUtil;

/**
 * MastTicket Model
 *
 * @method \App\Model\Entity\MastTicket get($primaryKey, $options = [])
 * @method \App\Model\Entity\MastTicket newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\MastTicket[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\MastTicket|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\MastTicket saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\MastTicket patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\MastTicket[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\MastTicket findOrCreate($search, callable $callback = null, $options = [])
 */
class MastTicketTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config) {
        parent::initialize($config);

        $this->setTable('mast_ticket');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');
        //Add behavior
        $this->addBehavior('UpdateSync');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator) {
        $validator
            ->allowEmptyString('id', null, 'create');

        $validator
            ->notEmptyString('ticket_name', ConfigUtil::getMessage("ECL001", ["チケット名"]))
            ->add('ticket_name', 'max-length', [
                'rule' => function ($value, $context) {
                    $len = mb_strlen($value);
                    if($len > 50) {
                        return ConfigUtil::getMessage("ECL002", ["チケット名", 50, $len]);
                    }
                    return true;
                }
            ]);

        $validator
            ->notEmptyString('list_price', ConfigUtil::getMessage("ECL001", ["定価"]))
            ->add('list_price', 'max-length', [
                'rule' => function ($value, $context) {
                    $len = mb_strlen($value);
                    if($len > 255) {
                        return ConfigUtil::getMessage("ECL002", ["定価", 255, $len]);
                    }
                    return true;
                }
            ]);

        $validator
            ->notEmptyString('unit_price', ConfigUtil::getMessage("ECL001", ["価格"]))
            ->add('unit_price', [
                'numeric' => [
                    'rule' => 'numeric',
                    'message' => ConfigUtil::getMessage("ECL004", ["価格"])
                ],
                'notNegative' => [
                    'rule' => function($value, $context) {
                        if($value < 0) {
                            return false;
                        }
                        return true;
                    },
                    'message' => ConfigUtil::getMessage("ECL004", ["価格"])
                ],
                'max-length' => [
                    'rule' => function ($value, $context) {
                        $len = mb_strlen($value);
                        if($len > 10) {
                            return ConfigUtil::getMessage("ECL002", ["価格", 10, $len]);
                        }
                        return true;
                    }
                ]
            ]);

        $validator
            ->notEmptyString('summary_description', ConfigUtil::getMessage("ECL001", ["概要説明"]))
            ->add('summary_description', 'max-length', [
                'rule' => function ($value, $context) {
                    $length = ValueUtil::validateTextArea($value);
                    if($length > 1000) {
                        return ConfigUtil::getMessage("ECL002", ["概要説明", 1000, $length]);
                    }
                    return true;
                }
            ]);

        $validator
            ->notEmptyString('detail_description', ConfigUtil::getMessage("ECL001", ["詳細説明"]))
            ->add('detail_description', 'max-length', [
                'rule' => function ($value, $context) {
                    $length = ValueUtil::countCharacters($value);
                    if($length > 3000) {
                        return ConfigUtil::getMessage("ECL002", ["詳細説明", 3000, $length]);
                    }
                    return true;
                }
            ]);

        $validator
            ->allowEmptyFile('image_url1')
            ->add('image_url1', [
                'extension' => [
                    'rule' => ['extension', ['jpg', 'jpeg', 'png']],
                    'message' => ConfigUtil::getMessage("ECL022", ["「jpg、jpeg、png」"]),
                    'on' => function($context) {
                        return !empty($context['data']['image_url1']);
                    }
                ],
                'fileSize' => [
                    'rule' => function($value, $context) {
                        $imgSize = isset($value['size']) ? $value['size'] : null;
                        $sizeDefault = 4*1024*1024;
                        if($imgSize > $sizeDefault) {
                            return ConfigUtil::getMessage("ECL022", ["4MB"]);
                        }
                        return true;
                    },
                    'on' => function($context) {
                        return !empty($context['data']['image_url1']);
                    }
                ],
                'max-length' => [
                    'rule' => function ($value, $context) {
                        $len = !empty($value['name']) ? mb_strlen($value['name']) : 0;
                        if($len > 50) {
                            return ConfigUtil::getMessage("ECL002", ["画像URL1", 50, $len]);
                        }
                        return true;
                    },
                    'on' => function($context) {
                        return !empty($context['data']['image_url1']);
                    }
                ]
            ]);

        $validator
            ->allowEmptyFile('image_url2')
            ->add('image_url2', [
                'extension' => [
                    'rule' => ['extension', ['jpg', 'jpeg', 'png']],
                    'message' => ConfigUtil::getMessage("ECL022", ["「jpg、jpeg、png」"]),
                    'on' => function($context) {
                        return !empty($context['data']['image_url2']);
                    }
                ],
                'fileSize' => [
                    'rule' => function($value, $context) {
                        $imgSize = isset($value['size']) ? $value['size'] : null;
                        $sizeDefault = 4*1024*1024;
                        if($imgSize > $sizeDefault) {
                            return ConfigUtil::getMessage("ECL022", ["4MB"]);
                        }
                        return true;
                    },
                    'on' => function($context) {
                        return !empty($context['data']['image_url2']);
                    }
                ],
                'max-length' => [
                    'rule' => function ($value, $context) {
                        $len = !empty($value['name']) ? mb_strlen($value['name']) : 0;
                        if($len > 50) {
                            return ConfigUtil::getMessage("ECL002", ["画像URL2", 50, $len]);
                        }
                        return true;
                    },
                    'on' => function($context) {
                        return !empty($context['data']['image_url2']);
                    }
                ]
            ]);

        $validator
            ->allowEmptyFile('image_url3')
            ->add('image_url3', [
                'extension' => [
                    'rule' => ['extension', ['jpg', 'jpeg', 'png']],
                    'message' => ConfigUtil::getMessage("ECL022", ["「jpg、jpeg、png」"]),
                    'on' => function($context) {
                        return !empty($context['data']['image_url3']);
                    }
                ],
                'fileSize' => [
                    'rule' => function($value, $context) {
                        $imgSize = isset($value['size']) ? $value['size'] : null;
                        $sizeDefault = 4*1024*1024;
                        if($imgSize > $sizeDefault) {
                            return ConfigUtil::getMessage("ECL022", ["4MB"]);
                        }
                        return true;
                    },
                    'on' => function($context) {
                        return !empty($context['data']['image_url3']);
                    }
                ],
                'max-length' => [
                    'rule' => function ($value, $context) {
                        $len = !empty($value['name']) ? mb_strlen($value['name']) : 0;
                        if($len > 50) {
                            return ConfigUtil::getMessage("ECL002", ["画像URL3", 50, $len]);
                        }
                        return true;
                    },
                    'on' => function($context) {
                        return !empty($context['data']['image_url3']);
                    }
                ]
            ]);

        $validator
            ->notEmptyString('category', ConfigUtil::getMessage("ECL001", ["カテゴリー"]));

        $validator
            ->notEmptyString('area', ConfigUtil::getMessage("ECL001", ["エリア"]));

        $validator
            ->notEmptyString('number', ConfigUtil::getMessage("ECL001", ["残枚数"]))
            ->add('number', [
                'numeric' => [
                    'rule' => 'numeric',
                    'message' => ConfigUtil::getMessage("ECL004", ["残枚数"])
                ],
                'notNegative' => [
                    'rule' => function($value, $context) {
                        if($value < 0) {
                            return false;
                        }
                        return true;
                    },
                    'message' => ConfigUtil::getMessage("ECL004", ["残枚数"])
                ],
                'max-length' => [
                    'rule' => function ($value, $context) {
                        $len = mb_strlen($value);
                        if($len > 5) {
                            return ConfigUtil::getMessage("ECL002", ["残枚数", 5, $len]);
                        }
                        return true;
                    }
                ]
            ]);

        $validator
            ->notEmptyString('start_time', ConfigUtil::getMessage("ECL001", ["販売開始日時"]))
            ->add('start_time', [
                'datetime' => [
                    'rule' => 'datetime',
                    'message' => ConfigUtil::getMessage("ECL014", ["販売開始日時"])
                ]
            ]);

        $validator
            ->notEmptyString('end_time', ConfigUtil::getMessage("ECL001", ["販売終了日時"]))
            ->add('end_time', [
                'datetime' => [
                    'rule' => 'datetime',
                    'message' => ConfigUtil::getMessage("ECL014", ["販売終了日時"])
                ],
                'greaterThanDate' => [
                    'rule' => function($value, $context) {
                        $startTime = !empty($context['data']['start_time']) ? $context['data']['start_time'] : '';
                        $endTime = !empty($context['data']['end_time']) ? $context['data']['end_time'] : '';
                        if($endTime < $startTime) {
                            return ConfigUtil::getMessage("ECL036", ["販売終了日時", "販売開始日時"]);
                        }
                        return true;
                    }
                ]
            ]);

        $validator
            ->allowEmptyString('lower_limit', ConfigUtil::getMessage("ECL001", ["購入下限枚数"]))
            ->add('lower_limit', [
                'numeric' => [
                    'rule' => 'numeric',
                    'message' => ConfigUtil::getMessage("ECL004", ["購入下限枚数"])
                ],
                'notNegative' => [
                    'rule' => function($value, $context) {
                        if($value < 0) {
                            return false;
                        }
                        return true;
                    },
                    'message' => ConfigUtil::getMessage("ECL004", ["購入下限枚数"])
                ],
                'max-length' => [
                    'rule' => function ($value, $context) {
                        $len = mb_strlen($value);
                        if($len > 5) {
                            return ConfigUtil::getMessage("ECL002", ["購入下限枚数", 5, $len]);
                        }
                        return true;
                    }
                ],
                'limit' => [ //0 < lower_limit <= upper_limit <= mast_ticket.number
                    'rule' => function ($value, $context) {
                        $number = $context['data']['number'];
                        $upper = $context['data']['upper_limit'];
                        if($upper != ""){
                            if($value > $upper) {
                                return ConfigUtil::getMessage("ECL059");
                            }
                        }
                        if($value <= 0 ||
                            $value > $number ||
                            $upper > $number) {
                            return ConfigUtil::getMessage("ECL059");
                        }
                        return true;
                    }
                ]
            ]);

        $validator
            ->allowEmptyString('upper_limit', ConfigUtil::getMessage("ECL001", ["購入上限枚数"]))
            ->add('upper_limit', [
                'numeric' => [
                    'rule' => 'numeric',
                    'message' => ConfigUtil::getMessage("ECL004", ["購入上限枚数"])
                ],
                'notNegative' => [
                    'rule' => function($value, $context) {
                        if($value < 0) {
                            return false;
                        }
                        return true;
                    },
                    'message' => ConfigUtil::getMessage("ECL004", ["購入上限枚数"])
                ],
                'max-length' => [
                    'rule' => function ($value, $context) {
                        $len = mb_strlen($value);
                        if($len > 5) {
                            return ConfigUtil::getMessage("ECL002", ["購入上限枚数", 5, $len]);
                        }
                        return true;
                    }
                ]
            ]);

        $validator
            ->allowEmptyString('exp_from')
            ->add('exp_from', [
                'datetime' => [
                    'rule' => 'date',
                    'message' => ConfigUtil::getMessage("ECL010", ["有効期限(from)"])
                ]
            ]);

        $validator
            ->allowEmptyString('exp_to')
            ->add('exp_to', [
                'datetime' => [
                    'rule' => 'date',
                    'message' => ConfigUtil::getMessage("ECL010", ["有効期限(to)"])
                ],
                'greaterThanDate' => [
                    'rule' => function($value, $context) {
                        $startTime = !empty($context['data']['exp_from']) ? $context['data']['exp_from'] : '';
                        $endTime = !empty($context['data']['exp_to']) ? $context['data']['exp_to'] : '';
                        if($endTime < $startTime) {
                            return ConfigUtil::getMessage("ECL036", ["有効期限(to)", "有効期限(from)"]);
                        }
                        return true;
                    }
                ]
            ]);

        $validator
            ->notEmptyString('del_flg');

        $validator
            ->allowEmptyString('created_by');

        $validator
            ->dateTime('created_at')
            ->allowEmptyDateTime('created_at');

        $validator
            ->allowEmptyString('updated_by');

        $validator
            ->dateTime('updated_at')
            ->allowEmptyDateTime('updated_at');

        $validator
            ->allowEmptyString('deleted_by');

        $validator
            ->dateTime('deleted_at')
            ->allowEmptyDateTime('deleted_at');

        return $validator;
    }

    /**
     * Validation for a009
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationMastTicketA009(Validator $validator) {
        $validator
            ->allowEmptyString('id', null, 'create');

        $validator
            ->notEmptyString('ticket_name', ConfigUtil::getMessage("ECL001", ["チケット名"]))
            ->add('ticket_name', 'max-length', [
                'rule' => function ($value, $context) {
                    $len = mb_strlen($value);
                    if($len > 50) {
                        return ConfigUtil::getMessage("ECL002", ["チケット名", 50, $len]);
                    }
                    return true;
                }
            ]);

        $validator
            ->allowEmptyString('list_price')
            ->add('list_price', 'max-length', [
                'rule' => function ($value, $context) {
                    $len = mb_strlen($value);
                    if($len > 255) {
                        return ConfigUtil::getMessage("ECL002", ["定価", 255, $len]);
                    }
                    return true;
                }
            ]);

        $validator
            ->notEmptyString('unit_price', ConfigUtil::getMessage("ECL001", ["価格"]))
            ->add('unit_price', [
                'numeric' => [
                    'rule' => 'numeric',
                    'message' => ConfigUtil::getMessage("ECL004", ["価格"])
                ],
                'notNegative' => [
                    'rule' => function($value, $context) {
                        if($value < 0) {
                            return false;
                        }
                        return true;
                    },
                    'message' => ConfigUtil::getMessage("ECL004", ["価格"])
                ],
                'max-length' => [
                    'rule' => function ($value, $context) {
                        $len = mb_strlen($value);
                        if($len > 10) {
                            return ConfigUtil::getMessage("ECL002", ["価格", 10, $len]);
                        }
                        return true;
                    }
                ]
            ]);

        $validator
            ->notEmptyString('number', ConfigUtil::getMessage("ECL001", ["残枚数"]))
            ->add('number', [
                'numeric' => [
                    'rule' => 'numeric',
                    'message' => ConfigUtil::getMessage("ECL004", ["残枚数"])
                ],
                'notNegative' => [
                    'rule' => function($value, $context) {
                        if($value < 0) {
                            return false;
                        }
                        return true;
                    },
                    'message' => ConfigUtil::getMessage("ECL004", ["残枚数"])
                ],
                'max-length' => [
                    'rule' => function ($value, $context) {
                        $len = mb_strlen($value);
                        if($len > 10) {
                            return ConfigUtil::getMessage("ECL002", ["残枚数", 10, $len]);
                        }
                        return true;
                    }
                ]
            ]);

        $validator
            ->allowEmptyString('lower_limit')
            ->add('lower_limit', [
                'numeric' => [
                    'rule' => 'numeric',
                    'message' => ConfigUtil::getMessage("ECL004", ["購入下限枚数"])
                ],
                'notNegative' => [
                    'rule' => function($value, $context) {
                        if($value < 0) {
                            return false;
                        }
                        return true;
                    },
                    'message' => ConfigUtil::getMessage("ECL004", ["購入下限枚数"])
                ],
                'max-length' => [
                    'rule' => function ($value, $context) {
                        $len = mb_strlen($value);
                        if($len > 10) {
                            return ConfigUtil::getMessage("ECL002", ["購入下限枚数", 10, $len]);
                        }
                        return true;
                    }
                ],
                'limit' => [ //0 < lower_limit <= upper_limit <= mast_ticket.total_number
                    'rule' => function ($value, $context) {
                        $number = $context['data']['number'];
                        $upper = $context['data']['upper_limit'];
                        if($upper != ""){
                            if($value > $upper) {
                                return ConfigUtil::getMessage("ECL059");
                            }
                        }
                        if($value <= 0 ||
                            $value > $number ||
                            $upper > $number) {
                            return ConfigUtil::getMessage("ECL059");
                        }
                        return true;
                    }
                ]
            ]);

        $validator
            ->allowEmptyString('upper_limit', ConfigUtil::getMessage("ECL001", ["購入上限枚数"]))
            ->add('upper_limit', [
                'numeric' => [
                    'rule' => 'numeric',
                    'message' => ConfigUtil::getMessage("ECL004", ["購入上限枚数"])
                ],
                'notNegative' => [
                    'rule' => function($value, $context) {
                        if($value < 0) {
                            return false;
                        }
                        return true;
                    },
                    'message' => ConfigUtil::getMessage("ECL004", ["購入上限枚数"])
                ],
                'max-length' => [
                    'rule' => function ($value, $context) {
                        $len = mb_strlen($value);
                        if($len > 10) {
                            return ConfigUtil::getMessage("ECL002", ["購入上限枚数", 10, $len]);
                        }
                        return true;
                    }
                ]
            ]);

        $validator
            ->allowEmptyString('exp_from')
            ->add('exp_from', [
                'date' => [
                    'rule' => 'date',
                    'message' => ConfigUtil::getMessage("ECL010", ["有効期限(from)"])
                ],
            ]);

        $validator
            ->allowEmptyString('exp_to')
            ->add('exp_to', [
                'date' => [
                    'rule' => 'date',
                    'message' => ConfigUtil::getMessage("ECL010", ["有効期限(to)"])
                ],
                'greaterThanDate' => [
                    'rule' => function($value, $context) {
                        $startTime = !empty($context['data']['exp_from']) ? $context['data']['exp_from'] : '';
                        $endTime = !empty($context['data']['exp_to']) ? $context['data']['exp_to'] : '';
                        if($endTime < $startTime) {
                            return ConfigUtil::getMessage("ECL036", ["有効期限(to)", "有効期限(from)"]);
                        }
                        return true;
                    }
                ]
            ]);

        $validator
            ->allowEmptyString('start_time')
            ->add('start_time', [
                'datetime' => [
                    'rule' => 'datetime',
                    'message' => ConfigUtil::getMessage("ECL014", ["販売開始日時"])
                ]
            ]);

        $validator
            ->allowEmptyString('end_time')
            ->add('end_time', [
                'datetime' => [
                    'rule' => 'datetime',
                    'message' => ConfigUtil::getMessage("ECL014", ["販売終了日時"])
                ],
                'greaterThanDate' => [
                    'rule' => function($value, $context) {
                        $startTime = !empty($context['data']['start_time']) ? $context['data']['start_time'] : '';
                        $endTime = !empty($context['data']['end_time']) ? $context['data']['end_time'] : '';
                        if($endTime < $startTime) {
                            return ConfigUtil::getMessage("ECL036", ["販売終了日時", "販売開始日時"]);
                        }
                        return true;
                    }
                ]
            ]);

        $validator
            ->notEmptyString('del_flg');

        $validator
            ->allowEmptyString('created_by');

        $validator
            ->dateTime('created_at')
            ->allowEmptyDateTime('created_at');

        $validator
            ->allowEmptyString('updated_by');

        $validator
            ->dateTime('updated_at')
            ->allowEmptyDateTime('updated_at');

        $validator
            ->allowEmptyString('deleted_by');

        $validator
            ->dateTime('deleted_at')
            ->allowEmptyDateTime('deleted_at');

        return $validator;
    }

    /**
     * Search mast_ticket
     *
     * @param $params
     * @return Query
     * @throws \Exception
     */
    public function search($params) {
        $category = isset($params['category']) ? $params['category'] : '';
        $area = isset($params['area']) ? $params['area'] : '';
        $unitPriceFrom = isset($params['unit_price_from']) ? $params['unit_price_from'] : '';
        $unitPriceTo = isset($params['unit_price_to']) ? $params['unit_price_to'] : '';
        $numberFrom = isset($params['number_from']) ? $params['number_from'] : '';
        $numberTo = isset($params['number_to']) ? $params['number_to'] : '';
        $timeSearch = isset($params['time_search']) ? $params['time_search'] : '';
        $search['conditions'] = [];
        $timeNow = new \DateTime();
        $timeNow = $timeNow->format('Y/m/d H:i:s');
        //Search by category
        if(!empty($category)){
            if(is_string($category) && strpos($category, ',') !== false){
                $category = explode(',', $category);
            }
            if(is_array($category)){
                array_push($search['conditions'], ['MastTicket.category IN' => $category]);
            } else {
                array_push($search['conditions'], ['MastTicket.category' => $category]);
            }
        }
        //Search by area
        if(!empty($area)){
            if(is_string($area) && strpos($area, ',') !== false){
                $area = explode(',', $area);
            }
            if(is_array($area)){
                array_push($search['conditions'], ['MastTicket.area IN' => $area]);
            } else {
                array_push($search['conditions'], ['MastTicket.area' => $area]);
            }
        }
        //Search by both unit_price_from & unit_pirce_to
        if(strlen($unitPriceFrom) > 0 && strlen($unitPriceTo) > 0){
            if(is_numeric($unitPriceFrom) && is_numeric($unitPriceTo)){
                array_push($search['conditions'], sprintf("MastTicket.unit_price BETWEEN %s AND %s", $unitPriceFrom, $unitPriceTo));
            } else {
                array_push($search['conditions'], ['MastTicket.unit_price' => null]);
            }
        }
        //Search by unit_price_from
        else if(strlen($unitPriceFrom) > 0){
            if(is_numeric($unitPriceFrom)){
                array_push($search['conditions'], sprintf("MastTicket.unit_price >= %s", $unitPriceFrom));
            } else {
                array_push($search['conditions'], ['MastTicket.unit_price' => null]);
            }
        }
        //Search by unit_price_to
        else if(strlen($unitPriceTo) > 0){
            if(is_numeric($unitPriceTo)){
                array_push($search['conditions'], sprintf("MastTicket.unit_price <= %s", $unitPriceTo));
            } else {
                array_push($search['conditions'], ['MastTicket.unit_price' => null]);
            }
        }
        //Search by both number_from & number_to
        if(strlen($numberFrom) > 0 && strlen($numberTo) > 0){
            if(is_numeric($numberFrom) && is_numeric($numberTo)){
                array_push($search['conditions'], sprintf("MastTicket.number BETWEEN %s AND %s", $numberFrom, $numberTo));
            } else {
                array_push($search['conditions'], ['MastTicket.number' => null]);
            }
        }
        //Search by number_from
        else if(strlen($numberFrom) > 0){
            if(is_numeric($numberFrom)){
                array_push($search['conditions'], sprintf("MastTicket.number >= %s", $numberFrom));
            } else {
                array_push($search['conditions'], ['MastTicket.number' => null]);
            }
        }
        //Search by number_to
        else if(strlen($numberTo) > 0){
            if(is_numeric($numberTo)){
                array_push($search['conditions'], sprintf("MastTicket.number <= %s", $numberTo));
            } else {
                array_push($search['conditions'], ['MastTicket.number' => null]);
            }
        }
        //Search by time_search(start_time & end_time)
        if (!empty($timeSearch)) {
            $systemTime = "'" . date('Y/m/d H:i:s') . "'";
            $search['conditions']['OR'] = [];
            // 未販売
            if (in_array(ValueUtil::get('mast_ticket.time_search_val')['unsold'], $timeSearch)) {
                array_push($search['conditions']['OR'], [
                    "DATE_FORMAT(MastTicket.start_time, '%Y/%m/%d %H:%i:%s') > ".$systemTime
                ]);
            }
            // 販売中
            if (in_array(ValueUtil::get('mast_ticket.time_search_val')['start_time'], $timeSearch)) {
                array_push($search['conditions']['OR'], [
                    "DATE_FORMAT(MastTicket.start_time, '%Y/%m/%d %H:%i:%s') <= ".$systemTime,
                    "DATE_FORMAT(MastTicket.end_time, '%Y/%m/%d %H:%i:%s') >= ".$systemTime
                ]);
            }
            // 販売終了
            if (in_array(ValueUtil::get('mast_ticket.time_search_val')['end_time'], $timeSearch)) {
                array_push($search['conditions']['OR'], [
                    "DATE_FORMAT(MastTicket.end_time, '%Y/%m/%d %H:%i:%s') < ".$systemTime
                ]);
            }
        }
        //Just get records which not delete
        $delFlg = ValueUtil::get('common.del_flg_val');
        $delVal = isset($delFlg['undeleted']) ? $delFlg['undeleted'] : 0;
        $ticketTypeVal = ValueUtil::get('mast_ticket.ticket_type_val');
        $query = $this->find('all', $search)
            ->where([
                'MastTicket.ticket_type' => $ticketTypeVal['single_ticket'],
                'MastTicket.del_flg' => $delVal,
                'MastTicket.deleted_at IS NULL'
            ])
            ->orderDesc('MastTicket.created_at');
        return $query;
    }

    /**
     * Get mast_ticket by id
     *
     * @param $id
     * @return array|\Cake\Datasource\EntityInterface|null
     */
    public function getMastTicketById($id, $single_ticket = false) {
        //Just get records which not delete
        $delFlg = ValueUtil::get('common.del_flg_val');
        $delVal = isset($delFlg['undeleted']) ? $delFlg['undeleted'] : 0;
        $ticket_type = ValueUtil::get('mast_ticket.ticket_type_val');
        $query = $this->find()
            ->where([
                'MastTicket.id' => $id,
                'MastTicket.del_flg' => $delVal,
                'MastTicket.deleted_at IS NULL'
            ]);
        // Just get record which single ticket (ticket_type = 0)
        if($single_ticket) {
            $query->andWhere(['MastTicket.ticket_type' => $ticket_type['single_ticket']]);
        }
        return $query->first();
    }

    /**
     * Get mast_ticket by questionnaireId
     *
     * @param $id
     * @return array|\Cake\Datasource\EntityInterface|null|object
     */
    public function getMastTicketByQuestionnaireId($questionnaireId, $options = null) {
        try {
            $query = $this->find()
                ->where([
                    'MastTicket.questionnaire_id' => $questionnaireId,
                    'MastTicket.del_flg' => ValueUtil::get('common.del_flg_val')['undeleted'], //Just get records which not delete
                    'MastTicket.deleted_at IS NULL'
                ]);
            // sort ASC by screen A009 & A010
            if(isset($options['screen']) && $options['screen'] == 'a009') {
                $query->orderAsc('MastTicket.created_at');
            } else {
                $query->orderDesc('MastTicket.created_at');
            }
            return $query;
        } catch (\Exception $e) {
            return null;
        }
    }
}
