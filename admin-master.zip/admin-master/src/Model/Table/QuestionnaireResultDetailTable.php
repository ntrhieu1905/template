<?php
namespace App\Model\Table;

use App\Libs\ValueUtil;
use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * QuestionnaireResultDetail Model
 *
 * @property \App\Model\Table\QuestionnaireResultTable&\Cake\ORM\Association\BelongsTo $QuestionnaireResult
 * @property \App\Model\Table\QuestionnaireDetailTable&\Cake\ORM\Association\BelongsTo $QuestionnaireDetail
 *
 * @method \App\Model\Entity\QuestionnaireResultDetail get($primaryKey, $options = [])
 * @method \App\Model\Entity\QuestionnaireResultDetail newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\QuestionnaireResultDetail[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\QuestionnaireResultDetail|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\QuestionnaireResultDetail saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\QuestionnaireResultDetail patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\QuestionnaireResultDetail[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\QuestionnaireResultDetail findOrCreate($search, callable $callback = null, $options = [])
 */
class QuestionnaireResultDetailTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('questionnaire_result_detail');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->belongsTo('QuestionnaireResult', [
            'foreignKey' => 'questionnaire_result_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('QuestionnaireDetail', [
            'foreignKey' => 'questionnaire_detail_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('Order', [
            'foreignKey' => 'order_id'
        ]);
        $this->addBehavior('UpdateSync');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->allowEmptyString('id', null, 'create');

        $validator
            ->allowEmptyString('sort');

        $validator
            ->scalar('label_name')
            ->maxLength('label_name', 100)
            ->allowEmptyString('label_name');

        $validator
            ->integer('input_type')
            ->requirePresence('input_type', 'create')
            ->notEmptyString('input_type');

        $validator
            ->scalar('answer')
            ->allowEmptyString('answer');

        $validator
            ->notEmptyString('del_flg');

        $validator
            ->allowEmptyString('created_by');

        $validator
            ->dateTime('created_at')
            ->allowEmptyDateTime('created_at');

        $validator
            ->allowEmptyString('updated_by');

        $validator
            ->dateTime('updated_at')
            ->allowEmptyDateTime('updated_at');

        $validator
            ->allowEmptyString('deleted_by');

        $validator
            ->dateTime('deleted_at')
            ->allowEmptyDateTime('deleted_at');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['questionnaire_result_id'], 'QuestionnaireResult'));
        $rules->add($rules->existsIn(['questionnaire_detail_id'], 'QuestionnaireDetail'));

        return $rules;
    }

    /**
     * get count questionnaire_result_detail by questionnaire_detail
     *
     * @param $questionnaireDetail
     */
    public function getCountByQuestionnaireDetail($questionnaireDetailId) {
        try {
            $result = $this->find()
                ->where(['questionnaire_detail_id' => $questionnaireDetailId])
                ->andWhere(['del_flg' => ValueUtil::constToValue('common.deleted_flg.NOT_DELETED')])
                ->andWhere(['deleted_at IS NULL'])
                ->count();

            return $result;
        } catch (\Exception $e) {
            return null;
        }
    }
}
