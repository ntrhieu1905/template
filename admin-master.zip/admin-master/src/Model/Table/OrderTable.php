<?php
namespace App\Model\Table;

use App\Libs\ConfigUtil;
use App\Libs\ValueUtil;
use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;
use Cake\ORM\TableRegistry;

/**
 * Order Model
 *
 * @property \App\Model\Table\FanTable&\Cake\ORM\Association\BelongsTo $Fan
 * @property \App\Model\Table\OrderItemsTable&\Cake\ORM\Association\HasMany $OrderItems
 *
 * @method \App\Model\Entity\Order get($primaryKey, $options = [])
 * @method \App\Model\Entity\Order newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Order[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Order|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Order saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Order patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Order[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Order findOrCreate($search, callable $callback = null, $options = [])
 */
class OrderTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('order');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');
        $this->belongsTo('Fan', [
            'foreignKey' => 'fan_id',
            'joinType' => 'INNER',
            'conditions' => [
                'Fan.del_flg' => ValueUtil::constToValue('common.deleted_flg.NOT_DELETED'),
                'Fan.deleted_at IS NULL'
            ],
        ]);
        $this->hasMany('OrderItems', [
            'foreignKey' => 'order_id'
        ]);
        $this->belongsTo('CreatedStaff', [
            'className' => 'Staff',
            'foreignKey' => 'created_by',
        ]);
        $this->belongsTo('UpdatedStaff', [
            'className' => 'Staff',
            'foreignKey' => 'updated_by'
        ]);
        $this->belongsTo('DeletedStaff', [
            'className' => 'Staff',
            'foreignKey' => 'deleted_by'
        ]);
        $this->belongsTo('Questionnaire', [
            'foreignKey' => 'questionnaire_id',
            'conditions' => [
                'Questionnaire.del_flg' => ValueUtil::constToValue('common.deleted_flg.NOT_DELETED'),
                'Questionnaire.deleted_at IS NULL'
            ],
        ]);
        $this->hasMany('QuestionnaireResultDetail', [
            'foreignKey' => 'order_id',
            'conditions' => [
                'QuestionnaireResultDetail.del_flg' => ValueUtil::constToValue('common.deleted_flg.NOT_DELETED'),
                'QuestionnaireResultDetail.deleted_at IS NULL'
            ],
        ]);
        //Add behavior
        $this->addBehavior('UpdateSync');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->allowEmptyString('id', null, 'create');

        $validator
            ->dateTime('order_date')
            ->allowEmptyDateTime('order_date');

        $validator
            ->integer('total_no_tax')
            ->allowEmptyString('total_no_tax');

        $validator
            ->integer('tax')
            ->allowEmptyString('tax');

        $validator
            ->integer('total_amount')
            ->allowEmptyString('total_amount');

        $validator
            ->allowEmptyString('payment_method');

        $validator
            ->scalar('credit_token')
            ->maxLength('credit_token', 255)
            ->allowEmptyString('credit_token');

        $validator
            ->allowEmptyString('winning_flg');

        $validator
            ->dateTime('receive_plan_date')
            ->allowEmptyDateTime('receive_plan_date');

        $validator
            ->allowEmptyDate('receive_date')
            ->add('receive_date', 'date', [
                'rule' => 'date',
                'message' => ConfigUtil::getMessage("ECL010", ["入金日"])
            ]);

        $validator
            ->allowEmptyString('memo', ConfigUtil::getMessage("ECL001", ["メモ"]))
            ->add('memo', 'max-length', [
                'rule' => function ($value, $context) {
                    $len = mb_strlen($value);
                    if($len > 255) {
                        return ConfigUtil::getMessage("ECL002", ["メモ", 255, $len]);
                    }
                    return true;
                }
            ]);

        $validator
            ->scalar('user_name')
            ->maxLength('user_name', 50)
            ->allowEmptyString('user_name');

        $validator
            ->integer('mobile')
            ->allowEmptyString('mobile');

        $validator
            ->integer('tel')
            ->allowEmptyString('tel');

        $validator
            ->integer('zip')
            ->allowEmptyString('zip');

        $validator
            ->allowEmptyString('prefecture');

        $validator
            ->scalar('city')
            ->maxLength('city', 50)
            ->allowEmptyString('city');

        $validator
            ->scalar('address1')
            ->maxLength('address1', 50)
            ->allowEmptyString('address1');

        $validator
            ->scalar('address2')
            ->maxLength('address2', 50)
            ->allowEmptyString('address2');

        $validator
            ->notEmptyString('del_flg');

        $validator
            ->allowEmptyString('created_by');

        $validator
            ->dateTime('created_at')
            ->allowEmptyDateTime('created_at');

        $validator
            ->allowEmptyString('updated_by');

        $validator
            ->dateTime('updated_at')
            ->allowEmptyDateTime('updated_at');

        $validator
            ->allowEmptyString('deleted_by');

        $validator
            ->dateTime('deleted_at')
            ->allowEmptyDateTime('deleted_at');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['fan_id'], 'Fan'));

        return $rules;
    }

    /**
     * Search order
     *
     * @param array $params
     * @param bool $csv_flg
     * @param array $options
     * @return array|Query|null
     */
    public function search($params = [], $csv_flg = false, $options = [])
    {
        try {
            //Get params
            $ticketName = isset($params['ticket_name']) ? $params['ticket_name'] : '';
            $category = isset($params['category']) ? $params['category'] : '';
            $area = isset($params['area']) ? $params['area'] : '';
            $orderDateFrom = isset($params['order_date_from']) ? $params['order_date_from'] : '';
            $orderDateTo = isset($params['order_date_to']) ? $params['order_date_to'] : '';
            $userKana = isset($params['user_kana']) ? $params['user_kana'] : '';
            $search['conditions'] = [];
            if (count($params) > 0) {
                //Search by ticket name
                if (strlen($ticketName) > 0) {
                    array_push($search['conditions'], ['MastTicket.ticket_name LIKE ' => '%' . $ticketName . '%']);
                }
                //Search by category
                if (!empty($category)) {
                    if (is_string($category) && strpos($category, ',') !== false) {
                        $category = explode(',', $category);
                    }
                    if (is_array($category)) {
                        array_push($search['conditions'], ['MastTicket.category IN' => $category]);
                    } else {
                        array_push($search['conditions'], ['MastTicket.category' => $category]);
                    }
                }
                //Search by area
                if (!empty($area)) {
                    if (is_string($area) && strpos($area, ',') !== false) {
                        $area = explode(',', $area);
                    }
                    if (is_array($area)) {
                        array_push($search['conditions'], ['MastTicket.area IN' => $area]);
                    } else {
                        array_push($search['conditions'], ['MastTicket.area' => $area]);
                    }
                }
                //Search by both order_date_from & order_date_to
                if (strlen($orderDateFrom) > 0 && strlen($orderDateTo) > 0) {
                    array_push($search['conditions'],
                        [
                            ["DATE_FORMAT(Order.order_date, '%Y/%m/%d') >= '" . $orderDateFrom . "'"],
                            ["DATE_FORMAT(Order.order_date, '%Y/%m/%d') <= '" . $orderDateTo . "'"]
                        ]
                    );
                }
                //Search by order_date_from
                else if (strlen($orderDateFrom) > 0) {
                    array_push($search['conditions'],
                        ["DATE_FORMAT(Order.order_date, '%Y/%m/%d') >= '" .$orderDateFrom . "'"]
                    );
                }
                //Search by order_date_to
                else if (strlen($orderDateTo) > 0) {
                    array_push($search['conditions'],
                        ["DATE_FORMAT(Order.order_date, '%Y/%m/%d') <= '" .$orderDateTo . "'"]
                    );
                }
                //Search by user kana
                if (strlen($userKana) > 0) {
                    array_push($search['conditions'], ['Fan.user_kana LIKE ' => $userKana . '%']);
                }
            }
            //Just get records which not delete
            $delFlg = ValueUtil::get('common.del_flg_val');
            $delFlgVal = isset($delFlg['undeleted']) ? $delFlg['undeleted'] : 0;
            if(!$csv_flg) {
                $query = $this->find('all', $search)
                    ->join([
                        'table' => 'order_items',
                        'alias' => 'OrderItems',
                        'conditions' => 'OrderItems.order_id = Order.id'
                    ])
                    ->join([
                        'table' => 'mast_ticket',
                        'alias' => 'MastTicket',
                        'conditions' => 'MastTicket.id = OrderItems.ticket_id'
                    ])
                    ->join([
                        'table' => 'fan',
                        'alias' => 'Fan',
                        'conditions' => 'Fan.id = Order.fan_id'
                    ])
                    ->where([
                        'Order.del_flg' => $delFlgVal,
                        'OrderItems.del_flg' => $delFlgVal,
                        'MastTicket.del_flg' => $delFlgVal,
                        'Fan.del_flg' => $delFlgVal,
                        'Order.deleted_at IS NULL',
                        'OrderItems.deleted_at IS NULL',
                        'MastTicket.deleted_at IS NULL',
                        'Fan.deleted_at IS NULL'
                    ])
                    ->select($this)
                    ->select([
                        'fan_user_name' => 'Fan.user_name',
                        'ticket_name' => 'group_concat(MastTicket.ticket_name)',
                        'category' => 'group_concat(MastTicket.category)',
                        'area' => 'group_concat(MastTicket.area)',
                    ])
                    ->group('Order.id')
                    ->orderDesc('Order.order_date')
                ;
                // set condition Order.questionnaire_id != null if search in screen A0131
                if(isset($options['screenA0131'])) {
                    $query->andWhere([
                        'Order.questionnaire_id IS NOT NULL'
                    ]);
                }
                return $query;
            }
            $query = $this->find('all', $search)
                ->join([
                    'table' => 'order_items',
                    'alias' => 'OrderItems',
                    'conditions' => 'OrderItems.order_id = Order.id'
                ])
                ->join([
                    'table' => 'mast_ticket',
                    'alias' => 'MastTicket',
                    'conditions' => 'MastTicket.id = OrderItems.ticket_id'
                ])
                ->join([
                    'table' => 'fan',
                    'alias' => 'Fan',
                    'conditions' => 'Fan.id = Order.fan_id'
                ])
                ->where([
                    'Order.del_flg' => $delFlgVal,
                    'OrderItems.del_flg' => $delFlgVal,
                    'MastTicket.del_flg' => $delFlgVal,
                    'Fan.del_flg' => $delFlgVal,
                    'Order.deleted_at IS NULL',
                    'OrderItems.deleted_at IS NULL',
                    'MastTicket.deleted_at IS NULL',
                    'Fan.deleted_at IS NULL'
                ])
                ->contain([
                    'CreatedStaff' => [
                        'fields' => [
                            'user_name'
                        ]
                    ],
                    'UpdatedStaff' => [
                        'fields' => [
                            'user_name'
                        ]
                    ],
                    'DeletedStaff' => [
                        'fields' => [
                            'user_name'
                        ]
                    ]
                ])
                ->select($this)
                ->select([
                    'fan_user_name' => 'Fan.user_name',
                    'fan_user_kana' => 'Fan.user_kana',
                    'ori_id' => 'OrderItems.id',
                    'ori_ticket_id' => 'OrderItems.ticket_id',
                    'mas_ticket_name' => 'MastTicket.ticket_name',
                    'mas_unit_price' => 'MastTicket.unit_price',
                    'mas_category' => 'MastTicket.category',
                    'mas_area' => 'MastTicket.area',
                    'ori_order_number' => 'OrderItems.order_number',
                    'ori_total_no_tax' => 'OrderItems.total_no_tax',
                ])
                ->orderDesc('Order.order_date')
            ;
            // set condition Order.questionnaire_id != null if search in screen A0131
            if(isset($options['screenA0131'])) {
                $query->andWhere([
                    'Order.questionnaire_id IS NOT NULL'
                ]);
            }
            return $query;
        } catch (\Exception $e) {
            return null;
        }
    }

    /**
     * get data Order
     *
     * @param $id
     * @return \App\Model\Entity\Order|bool
     */
    public function getOrderById($id = null) {
        try {
            // Get value del_flg field
            $delVal = ValueUtil::constToValue('common.deleted_flg.NOT_DELETED');
            $result = $this->find()
                ->where([
                    'Order.id' => $id,
                    'Order.del_flg' => $delVal,
                    'Order.deleted_at IS NULL'
                ])
                ->contain([
                    'Fan' => [
                        'fields' => [
                            'Fan.user_name',
                            'Fan.user_kana'
                        ],
                        'conditions' => [
                            'Fan.del_flg' => $delVal,
                            'Fan.deleted_at IS NULL'
                        ],
                    ],
                    'OrderItems' => [
                        'fields' => [
                            'OrderItems.id',
                            'OrderItems.ticket_id',
                            'OrderItems.order_id',
                            'OrderItems.order_number',
                            'OrderItems.total_no_tax'
                        ],
                        'conditions' => [
                            'OrderItems.del_flg' => $delVal,
                            'OrderItems.deleted_at IS NULL'
                        ],
                        'MastTicket' => [
                            'fields' => [
                                'MastTicket.id',
                                'MastTicket.questionnaire_id',
                                'MastTicket.ticket_name',
                                'MastTicket.category',
                                'MastTicket.area'
                            ],
                            'conditions' => [
                                'MastTicket.del_flg' => $delVal,
                                'MastTicket.deleted_at IS NULL'
                            ],
                        ]
                    ]
                ]);
            return $result->first();
        } catch (\Exception $e) {
            return null;
        }
    }

    /**
     *  Search a011
     *
     * @param $params
     * @return Query
     */
    public function searchA011($params, $questionnaireId) {
        $email = isset($params['email']) ? $params['email'] : '';
        $userKana = isset($params['user_kana']) ? $params['user_kana'] : '';
        $birthdayFrom = isset($params['birthday_from']) ? $params['birthday_from'] : '';
        $birthdayTo = isset($params['birthday_to']) ? $params['birthday_to'] : '';
        $sex = isset($params['sex']) ? $params['sex'] : '';
        $area = isset($params['area']) ? $params['area'] : '';
        $jobType = isset($params['job_type']) ? $params['job_type'] : '';
        $totalAmount = !empty($params['total_amount']) ? $params['total_amount'] : [];
        //Just get records which not delete
        $delFlg = ValueUtil::get('common.del_flg_val');
        $delVal = isset($delFlg['undeleted']) ? $delFlg['undeleted'] : 0;
        $query = $this->find()
            ->where(['1=1'])
            ->contain([
                'Fan',
                'Questionnaire',
                'QuestionnaireResultDetail'
            ]);
        //Search by email
        if(strlen($email) > 0){
            $query = $query->andWhere(['Fan.email LIKE' => $email.'%']);
        }
        //Search by user_kana
        if(strlen($userKana) > 0){
            $query = $query->andWhere(['Fan.user_kana LIKE' => mb_convert_kana($userKana).'%']);
        }
        //Search by birthday
        $conditions_date = [];
        if(strlen($birthdayFrom) > 0){
            $conditions_date['AND'][] = [new QueryExpression("DATE_FORMAT(Fan.birthday, '%Y') >= '$birthdayFrom'")];
        }
        if(strlen($birthdayTo) > 0){
            $conditions_date['AND'][] = [new QueryExpression("DATE_FORMAT(Fan.birthday, '%Y') <= '$birthdayTo'")];
        }
        $query->andWhere($conditions_date);
        //Search by sex
        if(!empty($sex)){
            if(is_string($sex) && strpos($sex, ',') !== false){
                $sex = explode(',', $sex);
            }
            if(is_array($sex)){
                $query = $query->andWhere(['Fan.sex IN' => $sex]);
            } else {
                $query = $query->andWhere(['Fan.sex' => $sex]);
            }
        }
        //Search by area
        if(!empty($area)){
            if(is_string($area) && strpos($area, ',') !== false){
                $area = explode(',', $area);
            }
            if(is_array($area)){
                $query = $query->andWhere(['Fan.area IN' => $area]);
            } else {
                $query = $query->andWhere(['Fan.area' => $area]);
            }
        }
        //Search by job_type
        if(!empty($jobType)){
            if(is_string($jobType) && strpos($jobType, ',') !== false){
                $jobType = explode(',', $jobType);
            }
            if(is_array($jobType)){
                $query = $query->andWhere(['Fan.job_type IN' => $jobType]);
            } else {
                $query = $query->andWhere(['Fan.job_type' => $jobType]);
            }
        }
        //Search by total_amount
        if(!empty($totalAmount)) {
            $conditions_or = [];
            // 未販売
            if (in_array(ValueUtil::get('order.total_amount_val')['purchased'], $totalAmount)) {
                $conditions_or['OR'][] = ["Order.total_amount IS NOT NULL"];
            }
            // 販売中
            if (in_array(ValueUtil::get('order.total_amount_val')['not_purchased'], $totalAmount)) {
                $conditions_or['OR'][] = ["Order.total_amount IS NULL"];
            }
            $query = $query->andWhere($conditions_or);
        }
        $query = $query->andWhere([
            'Order.questionnaire_id' => $questionnaireId,
            'Order.del_flg' => $delVal,
            'Order.deleted_at IS NULL',
        ])
            ->orderDesc('Order.created_at');
        return $query;
    }

    /**
     * get data with conditions
     * @param null $id
     * @return array|\Cake\Datasource\EntityInterface|null
     */
    public function getByIdAndWinner($id = null)
    {
        try {
            $result = $this->find()
                ->where([
                    'questionnaire_id' => $id,
                    'winning_flg' => 1
                ])
                ->order(['created_at'  => 'DESC'])
                ->all();
            return $result;
        } catch (\Exception $ex) {
            return null;
        }
    }
}
