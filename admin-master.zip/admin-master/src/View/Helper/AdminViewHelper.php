<?php
/**
 * Created by PhpStorm.
 * User: leminhtoan
 * Date: 3/13/17
 * Time: 18:47
 */

namespace App\View\Helper;


use App\Libs\ConfigUtil;
use App\Libs\DateUtil;
use App\Libs\ValueUtil;
use Cake\View\Helper;

class AdminViewHelper extends Helper
{
    public $helpers = ['Html', 'Url', 'Form', 'Paginator'];

    /**
     * Create a group menu in side bar
     *
     * @param $menu
     * @return string
     */
    public function createMenu($menu) {
        $html = "<div class='panel panel-default'>";
        foreach($menu as $group){
            $html .= $this->createMenuGroup($group);
        }
        $html .= "</div>";
        return $html;
    }

    /**
     * Create group menu in side bar
     *
     * @param $group
     * @return string
     */
    public function createMenuGroup($group) {
        $html = "<div class='panel-heading-2'>".
                        "<h4 class='panel-title'>".
                            $group['groupName'] .
                        "</h4>".
                    "</div>".
                 "<div class='list-menu'>";
        foreach($group['pages'] as $page){
            // Create url link
            $url = '';
            if(isset($page['controller'])){
                $url = $this->Url->build(['controller' => $page['controller'], 'action' => $page['action'], '']);
            }elseif(isset($page['url'])){
                $url = $this->Url->build($page['url'], true);
            }
            $target = '';
            if(isset($page['target']) && $page['target'] == "_blank"){
                $target = "target = '_blank'";
            }
            // Create HTML
            $html .= '<div class="list-group">' .
                        "<a href='{$url}' class='list-group-item' $target>" .
                            "<span class='bb-list-icon {$page['icon']}'></span>" .
                            "{$page['title']}<br>" .
                            "<span>{$page['extra']}</span>" .
                        '</a>' .
                     '</div>';
        }
        $html .= "</div>";
        return $html;
    }

    /**
     * Create paginate menu
     * @param $option
     * @return string
     */
    public function paginateMenuAndResult($option = array()) {
        $show_count = isset($option['showCount']) ? $option['showCount'] : true;
        $resultName = isset($option['resultName']) ? $option['resultName'] : '検索結果';
        if($show_count){
            $pageParams = $this->Paginator->params();
            $html = '<div class="col-xs-6 col-sm-6 col-md-6">' .
                $resultName . '：' . number_format($pageParams['count']) . '件中 ' .
                number_format($pageParams['start']) . '-' . number_format($pageParams['end']). '件' .
                '</div>' .
                '<div class="col-xs-6 col-sm-6 col-md-6">' .
                $this->paginateMenu($option) .
                '</div>';
        } else {
            $html = '<div class="col-xs-12">' .
                $this->paginateMenu($option) .
                '</div>';
        }
        return $html;
    }

    /**
     * Create paginate menu
     * @param $option
     * @return string
     */
    public function paginateMenu($option = array()) {
        $paginateMenu = ConfigUtil::get('paginate_menu');
        $selectValues = array_combine($paginateMenu, $paginateMenu);
        $formOption = isset($option['form'])? $option['form'] : '';
        $html = '<div class="paginate-menu float-right" '. $formOption . '>' .
                    '<div class="input-group">
                        <span class="input-group-text bb-addon" id="sizing-addon2">表示件数</span>' .
                            $this->Form->select('limit', $selectValues, [
                                'class'=>'form-control br0 paginate_menu',
                                'value'=> $this->Paginator->param('perPage'),
                                'data-form' => $formOption
                            ]) .
                     '</div>' .
                 '</div>';
        return $html;
    }

    /**
     * Change value to text
     * @param $key, $value
     * @return $result
     */
    public function valueToText($key = '', $value = '') {
        if(empty($key) || (empty($value) && strlen($value) == 0)){
            return null;
        }
        $result = ValueUtil::valueToText($key, $value);
        return $result;
    }

    public function formatDate($data){
    	return $data->format('Y/m/d');
    }

    public function formatDateTime($data){
        return $data->format('Y/m/d H:i');
    }

    public function convertTextToDatetime($str){
		$year = substr($str,0,4);
		$month = substr($str, 4,2);
		$day = substr($str, 6,2);
		$completeDay =  $year.'/'.$month.'/'.$day;
		if(!strtotime($completeDay)){
			$completeDay = "";
		}
		return $completeDay;
	}


	public function fileUrl($fileName1){
		return urldecode($this->Url->build(['controller' => 'Common', 'action' => 'getimage',$fileName1]));
	}

	public function showFile($fileImage1, $fileName1){
		$ext = pathinfo($fileImage1);
		if(in_array($ext['extension'], ["pdf", "png", "jpg", "jpeg"])){
			echo urldecode($this->Html->link(
				isset($fileImage1) ? h($fileName1) : '',
				'javascript:void(0)',
				[
					'data-toggle' => 'modal',
					'data-backdrop' => 'static',
					'data-keyboard' => 'false',
					'data-target' => "#file_modal"
				]
			));
		}else{
			echo $fileName1;
		}
	}

    /**
     * show date/datetime in japanese format
     *
     * @param $dateObj
     * @param bool $hasTime
     * @param bool $hasSecond
     * @param bool $lineBreak
     * @return string
     */
    public static function showJapaneseDate($dateObj, $hasTime = false, $hasSecond = false, $lineBreak = false) {
        $result = DateUtil::getJapaneseDate($dateObj, $hasTime, $hasSecond, $lineBreak);
        return $result;
    }

    /**
     * load css, script and plugin of wysiwyg editor
     */
    public function loadPluginSummernoteEditor() {
        echo $this->Html->css([
            'summernote/summernote-lite',
            'summernote-editor'
        ]);
        echo $this->Html->script([
            'summernote/summernote-lite',
            'summernote-editor',
        ]);
    }
}
