<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * TicketManager Model
 *
 * @property \App\Model\Table\FanTable&\Cake\ORM\Association\BelongsTo $Fan
 * @property \App\Model\Table\MastTicketTable&\Cake\ORM\Association\BelongsTo $MastTicket
 * @property \App\Model\Table\OrderItemsTable&\Cake\ORM\Association\BelongsTo $OrderItems
 *
 * @method \App\Model\Entity\TicketManager get($primaryKey, $options = [])
 * @method \App\Model\Entity\TicketManager newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\TicketManager[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\TicketManager|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\TicketManager saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\TicketManager patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\TicketManager[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\TicketManager findOrCreate($search, callable $callback = null, $options = [])
 */
class TicketManagerTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('ticket_manager');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->belongsTo('Fan', [
            'foreignKey' => 'fan_id',
        ]);
        $this->belongsTo('MastTicket', [
            'foreignKey' => 'ticket_id',
        ]);
        $this->belongsTo('OrderItems', [
            'foreignKey' => 'order_id',
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->allowEmptyString('id', null, 'create');

        $validator
            ->notEmptyString('used_ticket');

        $validator
            ->allowEmptyString('created_by');

        $validator
            ->dateTime('created_at')
            ->allowEmptyDateTime('created_at');

        $validator
            ->allowEmptyString('updated_by');

        $validator
            ->dateTime('updated_at')
            ->allowEmptyDateTime('updated_at');

        $validator
            ->allowEmptyString('deleted_by');

        $validator
            ->dateTime('deleted_at')
            ->allowEmptyDateTime('deleted_at');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['fan_id'], 'Fan'));
        $rules->add($rules->existsIn(['ticket_id'], 'MastTicket'));
        $rules->add($rules->existsIn(['order_items_id'], 'OrderItems'));

        return $rules;
    }
}
