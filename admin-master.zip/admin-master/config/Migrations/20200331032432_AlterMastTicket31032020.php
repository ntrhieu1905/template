<?php
use Migrations\AbstractMigration;

class AlterMastTicket31032020 extends AbstractMigration
{
    /**
     * Change Method.
     *
     * More information on this method is available here:
     * https://book.cakephp.org/phinx/0/en/migrations.html#the-change-method
     * @return void
     */
    public function change()
    {
        $table = $this->table('mast_ticket');
        $table
            ->addColumn('shipping_cost', 'biginteger', [
                'default' => 0,
                'null'    => false,
                'limit'   => 10,
                'after'   => 'exp_to'
            ])
            ->addColumn('free_shipping', 'biginteger', [
                'default' => 0,
                'null'    => false,
                'limit'   => 10,
                'after'   => 'shipping_cost'
            ])
            ->update();
    }
}
