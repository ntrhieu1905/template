<?php
namespace App\Model\Table;

use App\Libs\ValueUtil;
use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * MastQuestionnaireParts Model
 *
 * @method \App\Model\Entity\MastQuestionnairePart get($primaryKey, $options = [])
 * @method \App\Model\Entity\MastQuestionnairePart newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\MastQuestionnairePart[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\MastQuestionnairePart|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\MastQuestionnairePart saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\MastQuestionnairePart patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\MastQuestionnairePart[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\MastQuestionnairePart findOrCreate($search, callable $callback = null, $options = [])
 */
class MastQuestionnairePartsTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('mast_questionnaire_parts');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->hasMany('QuestionnaireDetail', [
            'foreignKey' => 'mast_questionnaire_parts_id',
        ]);
        $this->hasMany('TokutabiDetail', [
            'foreignKey' => 'mast_questionnaire_parts_id',
        ]);
        $this->addBehavior('UpdateSync');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->allowEmptyString('id', null, 'create');

        $validator
            ->integer('input_type')
            ->requirePresence('input_type', 'create')
            ->notEmptyString('input_type');

        $validator
            ->allowEmptyString('sort');

        $validator
            ->scalar('label_name')
            ->maxLength('label_name', 100)
            ->allowEmptyString('label_name');

        $validator
            ->scalar('input_format')
            ->allowEmptyString('input_format');

        $validator
            ->allowEmptyString('mandatory_flag');

        $validator
            ->notEmptyString('del_flg');

        $validator
            ->allowEmptyString('created_by');

        $validator
            ->dateTime('created_at')
            ->allowEmptyDateTime('created_at');

        $validator
            ->allowEmptyString('updated_by');

        $validator
            ->dateTime('updated_at')
            ->allowEmptyDateTime('updated_at');

        $validator
            ->allowEmptyString('deleted_by');

        $validator
            ->dateTime('deleted_at')
            ->allowEmptyDateTime('deleted_at');

        return $validator;
    }

    /**
     * A009 get all mast_questionnaire_parts
     *
     * @param null $questionnaireId
     * @return array
     */
    public function getDataMastQuestionnaireParts($questionnaireId = null) {
        $query = $this->find();
        if (!empty($questionnaireId)) {
            $query->contain(['QuestionnaireDetail' => [
                'fields' => ['mast_questionnaire_parts_id'],
                'conditions' => [
                    'QuestionnaireDetail.questionnaire_id' => $questionnaireId,
                    'QuestionnaireDetail.input_type IN' => ValueUtil::get('tok.ONLY_ONE'),
                    'QuestionnaireDetail.del_flg' => ValueUtil::constToValue('common.deleted_flg.NOT_DELETED'),
                    'QuestionnaireDetail.deleted_at IS NULL',
                ]
            ]]);
        }
        $query->where(['MastQuestionnaireParts.del_flg' => 0])
                      ->orderAsc('MastQuestionnaireParts.sort')
                      ->enableHydration(FALSE);

        return $query->toArray();
    }

    /**
     *  get MastQuestionnaireParts data by id
     *
     * @param null $id
     * @return array|\Cake\Datasource\EntityInterface|null
     */
    public function getMastQuestionnairePartsById($id = null) {
        try {
            $result = $this->find()->where(['id' => $id])->first();

            return $result;
        } catch (\Exception $e) {
            return null;
        }
    }

    /**
     * A022 get all mast_questionnaire_parts connect table TokutabiDetail
     *
     * @param null $idTokutabi
     * @return array
     */
    public function getDataMastQuestionnairePartsTokutabiDetail($idTokutabi = null) {
        $query = $this->find();
        // if id tokutabi !empty
        if (!empty($idTokutabi)) {
            $query->contain(['TokutabiDetail' => [
                'fields' => ['mast_questionnaire_parts_id'],
                'conditions' => [
                    'TokutabiDetail.tokutabi_id' => $idTokutabi,
                    'TokutabiDetail.input_type IN' => ValueUtil::get('tok.ONLY_ONE'),
                    'TokutabiDetail.del_flg' => ValueUtil::constToValue('common.deleted_flg.NOT_DELETED'),
                    'TokutabiDetail.deleted_at IS NULL',
                ]
            ]]);
        }
        $query->where(['MastQuestionnaireParts.del_flg' => ValueUtil::constToValue('common.deleted_flg.NOT_DELETED')])
            ->andWhere(['MastQuestionnaireParts.deleted_at IS NULL'])
            ->orderAsc('MastQuestionnaireParts.sort')
            ->enableHydration(FALSE);
        return $query->toArray();
    }
}
