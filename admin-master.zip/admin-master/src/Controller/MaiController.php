<?php
/**
 * Created by PhpStorm.
 * User: dat.tnt
 * Date: 2019/10/23
 * Time: 12:24
 */
namespace App\Controller;

use App\Libs\ConfigUtil;
use App\Libs\DateUtil;
use App\Libs\EmailUtil;
use App\Libs\ExportDataUtil;
use App\Libs\ValueUtil;
use Cake\Event\Event;

/**
 * mail_history content controller
 */
class MaiController extends AppAdminController
{
    /**
     * Override beforeFilter callback
     *
     * @return \Cake\Network\Response|null|void
     */
    public function beforeFilter(Event $event) {
        parent::beforeFilter($event);
        //Load common model
        $this->loadModel('MailHistory');
        $this->loadModel('Order');
    }

    /**
     * A018 メール一覧
     * A018
     */
    public function a018() {
        //Get login user data
        $session = $this->getRequest()->getSession();
        //Check searching data session
        $params = [];
        if ($session->check('Mai.a018')) {// when have session
            $params = $session->read('Mai.a018');
            $this->set([
                'searchData' => $params,
            ]);
        }
        // Process after submit form
        if ($this->getRequest()->is('post')) {
            $searchData = $this->getRequest()->getData();
            //Write session
            $session->delete('Mai.a018');
            $session->write('Mai.a018',  $searchData);
            //Reload page
            return $this->redirect(['action' => 'a018']);
        }
        // Get records from database then paginate result
        $result = $this->MailHistory->search($params);
        $mails = $this->paginate($result, ['limit' => ConfigUtil::get('paginate.ten_pages')]);
        //Show list evaluation
        $this->set(compact('mails'));
        $this->set('_serialize', ['mails']);
    }

    /**
     * A020 メール作成
     * A020
     */
    public function a020($params = []) {
        $session = $this->getRequest()->getSession();
        $fanCsv = [];
        if($session->check('Fan.a005')) { // session from A005
            $dataSession = $session->read('Fan.a005');
            $screen_flg = 'a005';
            // get title for field send target
            $sendTarget = $this->getTextSendTargetFan($dataSession);
            // get fans
            $fans = $this->Fan->search($dataSession)->toArray();
            foreach ($fans as $fan) {
                $fanCsv[] = $fan;
            }
            $this->set(compact('sendTarget', 'screen_flg'));
        } elseif($session->check('Que.a011')) { //session from A011
            // get questionnaire_result by questionnaire_id
            $dataSession = $session->read('Que.a011');
            $screen_flg = 'a011';
            // case session[id] null
            if ($dataSession['questionnaire_id'] == null) {
                return $this->redirect(['controller' => 'Top', 'action' => 'error']);
            }
            // get title for field send target
            $sendTarget = $this->getTextSendTargetWinner($dataSession['questionnaire_id']);
            $orders = $this->Order->getByIdAndWinner($dataSession['questionnaire_id']);
            // get fan by id
            $fanIdArr = [];
            $orderIdArr = [];
            $questionnaire_id = null;
            foreach ($orders as $result) {
                $fanIdArr[] = $result->fan_id;
                $orderIdArr[] = $result->id;
                $questionnaire_id = $result->questionnaire_id;
            }
            $fanCsv = $this->Fan->getFansByIds($fanIdArr, $orderIdArr);
            $questionnaire = $this->Questionnaire->getQuestionnaireById($questionnaire_id);
            $paymentFlag = $questionnaire['payment_flag'];
            $questTitle = $questionnaire['title'];
            $fanCsv['questionnaire'] = $questionnaire;
            $fanCsv['url_temp'] = $this->getUrlTemplate(null, 'fan/fan/f005/XXXXXXXXXX');;
            $fanCsv['url_event'] = $this->getUrlTemplate(null, 'fan/fan/f005/');;
            $this->set(compact('sendTarget', 'screen_flg', 'paymentFlag', 'questTitle'));
        } else {
            return $this->redirect(['controller' => 'Top', 'action' => 'error']);
        }
        $tableMaiHistory = 'mail_history';
        if ($this->getRequest()->is(['post', 'put', 'patch'])) {
            $params = $this->getRequest()->getData();
            $now = strtotime('now');
            // check validate send_time
            if (strtotime($params['send_time']) < $now || (strtotime($params['send_time']) > ($now + ConfigUtil::get('time_send_mail')))) {
                return $this->Flash->error(ConfigUtil::getMessage('ECL058'));
            }
            $data = $this->formatDataHistory($params);
            //save mail history data
            $queryComponent = $this->loadComponent('Query');
            $lastRecord = $this->MailHistory->getLastRecordMailHistory();
            // new id record of mail history
            $newId = $lastRecord->id + 1;
            //csv and get file name to save in table
            $filePath = $this->handleCsvMailHistory($fanCsv, $newId);
            if (!$filePath) {
                return $this->redirect(['controller' => 'Top', 'action' => 'error']);
            }
            if (!empty($filePath)) {
                $data['send_to_file'] = $filePath;
                // save data mail history
                $mailHistory = $queryComponent->saveTable($tableMaiHistory, $data);
                // check when save data not success
                if(is_bool($mailHistory)) {
                    return $this->Flash->error(ConfigUtil::getMessage('CREATE_FAILURE'));
                }
                if (empty($mailHistory->getErrors())) {
                    $this->Flash->success(ConfigUtil::getMessage('CREATE_SUCCESS'));
                    // handle send mail
                    $emailUtil = new EmailUtil();
                    $emailUtil->sendMail($fanCsv, $params, strtotime($params['send_time']));
                    // redirect to A018 after finish process
                    return $this->redirect(['controller' => 'Mai', 'action' => 'a018']);
                }
                $this->showErrors($mailHistory->getErrors());
            }
        }
    }

    /**
     * export csv in a018 screen
     * @param null $id
     * @return \Cake\Http\Response|null
     */
    public function exportCsv($id = null) {
        //Check valid Id
        if (empty($id) || !is_numeric($id)) {
            return $this->redirect(['controller' => 'Top', 'action' => 'error']);
        }
        //get data of mail
        $mail = $this->MailHistory->getMailById($id)->toArray();
        //get path file
        $file = !empty($mail['send_to_file']) ? $mail['send_to_file'] : '';
        if (empty($file)) {
            //case filed send_to_file is null
            $this->Flash->error(ConfigUtil::getMessage('ECL026'));
            return $this->redirect($this->referer());
        }
        $file = ConfigUtil::get('AWS3_URL'). $file;
        // execute download csv
        $exportData = new ExportDataUtil();
        // Csv file name
        $fileName = 'A018_'. DateUtil::getFileNameByCurrentTime(). '.csv';
        if (!$exportData->downloadCSVFromAWS3($file, $fileName)) {
            //path file not exist
            $this->Flash->error(ConfigUtil::getMessage('ECL026'));
            return $this->redirect($this->referer());
        }
    }

    /**
     * A019メール表示
     * @param null $id
     * @return \Cake\Http\Response|null
     */
    public function a019($id = null) {
        //Check valid Id
        if (empty($id) || !is_numeric($id)) {
            return $this->redirect(['controller' => 'Top', 'action' => 'error']);
        }
        //get data of mail history
        $mailHistory = $this->MailHistory->getMailById($id);
        if (empty($mailHistory)) {
            return $this->redirect(['controller' => 'Top', 'action' => 'error']);
        }
        //Show list evaluation
        $this->set(compact('mailHistory'));
    }

    /**
     * get template for 件名, 本文 on a020 screen
     * @return \Cake\Http\Response
     */
    public function getTemplate() {
        if($this->getRequest()->is(['ajax'])){
            $data = $this->getRequest()->getData();
            if ($data['option'] != "A005" & $data['option'] != "A011") {
                $result = json_encode(['success' => false, 'message' => 'ID not found']);
                $this->response->withType('json');
                $this->response->getBody()->write($result);
                return $this->response;
            }
            $option = strtolower($data['option']);
            $subject_path = APP. 'Template/Email/Text/' .$option.'_sub.txt';
            $content_path = APP. 'Template/Email/Text/' .$option.'_content.txt';
            if($option = 'a011') {
                if($data['paymentFlag'] == ValueUtil::get('questionnaire.payment_flag_val')['no_payment']) {
                    $content_path = APP. 'Template/Email/Text/' .$option.'_1_content.txt';
                } elseif ($data['paymentFlag'] == ValueUtil::get('questionnaire.payment_flag_val')['settle_after_application'] ||
                    $data['paymentFlag'] == ValueUtil::get('questionnaire.payment_flag_val')['settle_after_winning']) {
                    $content_path = APP. 'Template/Email/Text/' .$option.'_2_content.txt';
                }
            }
            $subject = file_get_contents($subject_path);
            $subject = str_replace('questionnaire_title', $data['questTitle'], $subject);
            $content = file_get_contents($content_path);
            $uri = $this->getUrlTemplate(null, 'fan/fan/f005/XXXXXXXXXX');
            $content = str_replace('url_event_detail', $uri, $content);
            $result = json_encode([
                'success' => true,
                'subject' => $subject,
                'content' => $content,
                'subject_path' => $subject_path,
                'content_path' => $content_path,
            ]);
            $this->response->withType('json');
            $this->response->getBody()->write($result);
            return $this->response;
        }
    }

    /**
     * format data before save to MailHistory table
     * @param array $params
     * @return array
     */
    public function formatDataHistory(array $params) {
        $template = $params['mail_template'];
        if (!empty($template)) {
            $params['mail_template'] = ValueUtil::get('mail.'.$template);
        }
        $params['mail_from'] = ConfigUtil::get('from_mail');
        $params['del_flg'] = ValueUtil::constToValue('common.deleted_flg.NOT_DELETED');
        return $params;
    }

    /**
     * create csv and get link to download csv
     * @param array $fanCsv
     * @return string
     * @throws \Exception
     */
    public function handleCsvMailHistory(array $fanCsv, $id) {
        // get header mail history
        $header = ValueUtil::get('mail.header_csv');
        $list = [];
        $list[] = $header;
        foreach ($fanCsv as $fan) {
            $arrData = [];
            foreach ($header as $colName => $colTitle) {
                $arrData[$colName] = !empty($fan[$colName]) ? $fan[$colName] : '';
            }
            $list[] = $arrData;
        }
        // Csv file name
        $fileName = date('YmdHis') . '.csv';
        // execute get path csv
        $exportData = new ExportDataUtil();
        $filePath = $exportData->getFilePath($list, $fileName);
        $fileComponent = $this->loadComponent('FileAwsS3');
        $resData = $fileComponent->uploadFileToS3($filePath, 'mail_history', $id, null, 'csv');
        if (empty($resData->data->file_path[0])) {
            return false;
        }
        return $resData->data->file_path[0];
    }

    /**
     * export csv when click button CSV on screen A020
     */
    public function exportCsvHistory() {
        $session = $this->getRequest()->getSession();
        if($session->check('Fan.a005')) { // session from A005
            $params = $session->read('Fan.a005');
            $params['birthday_from'] = isset($params['birthday_from_csv']) ? $params['birthday_from_csv'] : '';
            $params['birthday_to'] = isset($params['birthday_to_csv']) ? $params['birthday_to_csv'] : '';
            // todo export csv of fan base on condition search
            $this->exportCsvFanByConditionSearch($params);
        } elseif ($session->check('Que.a011')) {
            $data = $session->read('Que.a011');
            $orders = $this->Order->getByIdAndWinner($data['questionnaire_id']);
            if (empty($orders)) {
                return $this->redirect(['controller' => 'Top', 'action' => 'error']);
            }
            // get fan by id
            $fanIdArr = [];
            foreach ($orders as $result) {
                $fanIdArr[] = $result->fan_id;
            }
            $fanCsv = $this->Fan->getFansByIds($fanIdArr);
            // export csv winner
            $this->exportCsvWinner($fanCsv);
        } else {
            return $this->redirect(['controller' => 'Top', 'action' => 'error']);
        }
    }

    /**
     * export csv of winner
     * @param array $fanCsv
     */
    public function exportCsvWinner(array $fanCsv) {
        // get header mail history
        $header = ValueUtil::get('mail.header_csv');
        $list = [];
        $list[] = $header;
        foreach ($fanCsv as $fan) {
            $arrData = [];
            foreach ($header as $colName => $colTitle) {
                $arrData[$colName] = !empty($fan[$colName]) ? $fan[$colName] : '';
            }
            $list[] = $arrData;
        }
        // Csv file name
        $fileName = 'A020_' . DateUtil::getFileNameByCurrentTime() . '.csv';
        // execute get path csv
        $exportData = new ExportDataUtil();
        $exportData->exportCSV($list, $fileName);
    }

    /**
     * export csv with conditions from a005 screen
     * @param array $params
     */
    public function exportCsvFanByConditionSearch(array $params) {
        //Get records from database then paginate result
        $fans = $this->Fan->search($params)->toArray();
        // get header
        $header = ValueUtil::get('mail.header_csv');
        $list = [];
        $list[] = $header;
        foreach ($fans as $fan) {
            $arrData = [];
            foreach ($header as $colName => $colTitle) {
                $arrData[$colName] = !empty($fan[$colName]) ? $fan[$colName] : '';
            }
            $list[] = $arrData;
        }
        // Csv file name
        $fileName = 'A020_' . DateUtil::getFileNameByCurrentTime() . '.csv';
        // execute get path csv
        $exportData = new ExportDataUtil();
        $exportData->exportCSV($list, $fileName);
    }

    /**
     * get title for 送信対象 if redirect from a005
     * @param array $dataSession
     * @return string
     */
    public function getTextSendTargetFan(array $dataSession) {
        $text = [];
        if (!empty($dataSession['id'])) {
            array_push($text, $dataSession['id']);
        }
        if (!empty($dataSession['user_kana'])) {
            array_push($text, $dataSession['user_kana']);
        }
        if (!empty($dataSession['birthday_from']) && !empty($dataSession['birthday_to'])) {
            array_push($text, $dataSession['birthday_from'].'〜'.$dataSession['birthday_to']);
        }
        if (!empty($dataSession['birthday_from']) && empty($dataSession['birthday_to'])) {
            array_push($text, $dataSession['birthday_from'].'〜');
        }
        if (empty($dataSession['birthday_from']) && !empty($dataSession['birthday_to'])) {
            array_push($text, '〜'.$dataSession['birthday_to']);
        }
        if (!empty($dataSession['sex'])) {
            $arr_sex = $this->processCheckbox($dataSession['sex'], 'sex');
            if (!empty($arr_sex)) {
                $text = array_merge($text, $arr_sex);
            }
        }
        if (!empty($dataSession['email_address'])) {
            array_push($text, $dataSession['email_address']);
        }
        if (!empty($dataSession['area'])) {
            $area = $this->processCheckbox($dataSession['area'], 'area');
            if (!empty($area)) {
                $text = array_merge($text, $area);
            }
        }
        if (!empty($dataSession['sns_relation'])) {
            $snsRelation = $this->processCheckbox($dataSession['sns_relation'], 'sns_relation');
            if (!empty($snsRelation)) {
                $text = array_merge($text, $snsRelation);
            }
        }
        if (!empty($dataSession['tel_phone'])) {
            array_push($text, $dataSession['tel_phone']);
        }
        if (!empty($dataSession['city'])) {
            array_push($text, $dataSession['city']);
        }
        if (!empty($dataSession['job_type'])) {
            $jobType = $this->processCheckbox($dataSession['job_type'], 'job_type');
            if (!empty($jobType)) {
                $text = array_merge($text, $jobType);
            }
        }
        if (!empty($dataSession['working_area'])) {
            $workingArea = $this->processCheckbox($dataSession['working_area'], 'working_area');
            if (!empty($workingArea)) {
                $text = array_merge($text, $workingArea);
            }
        }
        if (!empty($dataSession['used_sns'])) {
            $usedSns = $this->processCheckbox($dataSession['used_sns'], 'used_sns');
            if (!empty($usedSns)) {
                $text = array_merge($text, $usedSns);
            }
        }
        if (!empty($dataSession['interest'])) {
            $interest = $this->processCheckbox($dataSession['interest'], 'interest');
            if (!empty($interest)) {
                $text = array_merge($text, $interest);
            }
        }
        if (!empty($dataSession['bukatsu_join'][0])) {
            $bukatsuJoin = $this->processCheckbox($dataSession['bukatsu_join'], 'bukatsu_join');
            if (!empty($bukatsuJoin)) {
                $text = array_merge($text, $bukatsuJoin);
            }
        }
        if (!empty($dataSession['black_flg'])) {
            $blackFlg = $this->processCheckbox($dataSession['black_flg'], 'black_flg');
            if (!empty($blackFlg)) {
                $text = array_merge($text, $blackFlg);
            }
        }
        $textTarget = implode('、', $text);
        return ValueUtil::get('mail.title_for_fans') .'　'.$textTarget;
    }

    /**
     * merge checkbox from value to text
     * @param array $data
     * @param $nameCheckbox
     * @return array
     */
    public function processCheckbox(array $data, $nameCheckbox) {
        $checkbox = \App\Libs\ValueUtil::get('fan.'.$nameCheckbox);
        $joinCheckbox = [];
        foreach ($data as $value) {
            $joinCheckbox[] = $checkbox[$value];
        }
        return $joinCheckbox;
    }

    /**
     * get title for 送信対象 if redirect from a011
     * @param $questionnaireId
     * @return mixed
     */
    public function getTextSendTargetWinner($questionnaireId) {
        $questionnaire = $this->Questionnaire->getQuestionnaireById($questionnaireId);
        return $questionnaire->title. ' ' . ValueUtil::get('mail.title_for_winner');
    }
}
