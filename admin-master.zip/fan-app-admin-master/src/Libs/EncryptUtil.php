<?php
/**
 * Created by PhpStorm.
 * User: dat.tnt
 * Date: 07/10/2019
 * Time: 10:12 AM
 */
namespace App\Libs;

use Cake\Utility\Security;

class EncryptUtil
{
    /**
     * Encrypt string use AES 256
     *
     * @param string $str
     * @return string
     */
    public static function encryptAes256($str) {
        //Get constant value
        $key_len = ConfigUtil::get('aes_256_key');
        $method = ConfigUtil::get('method_aes_256');
        $hashMethod = ConfigUtil::get('method_hash');
        //Encrypt string
        $key = hash($hashMethod, $key_len, true);
        $iv = base64_decode(ConfigUtil::get('aes_256_iv'));
        $ciphertext = openssl_encrypt($str, $method, $key, OPENSSL_RAW_DATA, $iv);
        return base64_encode($ciphertext);
    }

    /**
     * Decrypt string use AES 256
     *
     * @param string $str
     * @return string
     */
    public static function decryptAes256($str) {
        //Get constant value
        $decrypt_str = base64_decode($str);
        $key_len = ConfigUtil::get('aes_256_key');
        $method = ConfigUtil::get('method_aes_256');
        $hashMethod = ConfigUtil::get('method_hash');
        $iv = base64_decode(ConfigUtil::get('aes_256_iv'));
        //Parse key to decrypt
        $key = hash($hashMethod, $key_len, true);
        return openssl_decrypt($decrypt_str, $method, $key, OPENSSL_RAW_DATA, $iv);
    }

    /**
     * Encrypt string use SHA-256
     *
     * @param string $str
     * @return string
     */
    public static function encryptSha256($str) {
        $hashMethod = ConfigUtil::get('method_hash');
        return hash($hashMethod, $str, false);
    }

    /**
     * Check string is same as sha-256 hashed string
     *
     * @param string $str
     * @param string $hashedStr
     * @return bool
     */
    public static function checkSha256($str, $hashedStr) {
        return self::encryptSha256($str) === $hashedStr;
    }
    
    /**
     * Encrypt syain password by des-cbc algorithm
     *
     * @param string $password
     * @return string
     */
    public static function encryptSyainPassword($password){
        $iv = hex2bin(ConfigUtil::get('des_iv'));
        $encryptKey = ConfigUtil::get('des_key');
        $length = ConfigUtil::get('des_length');
        $method = ConfigUtil::get('method_des');
        //Check length
        if($length > mb_strwidth($password)){
            $padPassword = $password . str_repeat(' ', $length - mb_strwidth($password));
        } else {
            $padPassword = mb_strimwidth($password, 0, $length);
        }
        //Encrypt a string
        $encrypt = openssl_encrypt($padPassword, $method, $encryptKey, OPENSSL_RAW_DATA, $iv);
        $hexPass = bin2hex($encrypt);
        //Retrun new password
        return $hexPass;
    }
}