$(function(){
    switcherLoader();

    // Datepicker initialize
    $('.datetime').datepicker().on('change', function() {
        $(this).valid();
    });

    // datepicker
    $('.datepicker').datepicker({
        showButtonPanel: false,
    }).on('change', function() {
        $(this).valid();
    });

    // Boostrap datepicker
    $('.date-month').datepicker({
        autoclose: true,
        viewMode: 'months',
        minViewMode: 'months',
        format: 'yyyy/mm',
        language: 'ja',
        forceParse: false
    }).on('change', function() {
        $(this).valid();
    });

    // Datepicker set year range 128 last years to current year
    $('.datetime-birthday').datepicker({
        changeYear: true,
        yearRange: "1900:+0",
        dateFormat: "yy/mm/dd",
        defaultDate: '1990/01/01'
    });

    $('.datetime-birthday').datepicker().on('change', function() {
        $(this).valid();
    });

    // Datetime picker
    $('.datetime-picker, [data-type="datetime"]').each(function () {
        var $this = $(this);
        var name = $this.attr('name'),
            val = $this.val(),
            datetime = '';
        // Check valid datetime type
        if( moment(val, 'YYYY-MM-DD hh:mm:ss').isValid() || moment(val, 'YYYY-MM-DD hh:mm').isValid() || moment(val, 'YYYY-MM-DD').isValid()){
            datetime = moment(val, 'YYYY-MM-DD hh:mm:ss');
        }
        // Create date item
        var $dateItem =  $('<input class="form-control datepicker-item" placeholder="YYYY/MM/DD" autocomplete="off">').attr('name', $this.attr('name')+ '_show')
            .val(datetime ? datetime.format('YYYY/MM/DD') : '')
            .datepicker();
        // Create time item
        var $timeItem = $('<input class="datepicker-hhmm form-control timepicker-item" placeholder="00:00" autocomplete="off">')
            .val(datetime ? datetime.format('HH:mm') : '');

        $this.hide();
        $this.before($('<div class="datetime-container"></div>').append($dateItem).append($timeItem));
    });

    // Datetime Hour Minute
    $('.date-hour-minute, [data-type="datetime"]').each(function () {
        var $this = $(this);
        var name = $this.attr('name'),
            val = $this.val(),
            datetime = '';
        // Check valid datetime type
        if( moment(val, 'YYYY-MM-DD hh:mm:ss').isValid() || moment(val, 'YYYY-MM-DD hh:mm').isValid() || moment(val, 'YYYY-MM-DD').isValid()){
            datetime = moment(val, 'YYYY-MM-DD hh:mm:ss');
        }
        // Create date item
        var $dateItem =  $('<input class="form-control date-hour-minute-item">')
            .val(datetime ? datetime.format('YYYY/MM/DD') : '')
            .datepicker();
        // Create array hours and minutes
        var $hours = [];
        var $minutes = [];
        for(var $i = 0; $i < 60; $i++) {
            $i = $i <= 0 || $i <= 9 ? `0` + $i : $i;
            $i <= 23 ? $hours.push($i) : '';
            $minutes.push($i);
        }
        // Create hour item
        var $hourItem = document.createElement('select');
        $($hourItem).addClass('datepicker-hhmm form-control hour-item');
        $hours.map($hour => {
            var $elementOption = document.createElement('option');
            $($elementOption).val($hour).text($hour);
            $($hourItem).append($elementOption);
        });

        // Create minute item
        var $minuteItem = document.createElement('select');
        $($minuteItem).addClass('datepicker-hhmm form-control minute-item');
        $minutes.map($minute => {
            var $elementOption = document.createElement('option');
            $($elementOption).val($minute).text($minute);
            $($minuteItem).append($elementOption);
        });
        var $textHour = '<span class="span-pad">時</span>';
        var $textMinute = '<span class="span-pad">分</span>';
        //Selected value
        $($hourItem).val(datetime ? datetime.format('HH') : '00');
        $($minuteItem).val(datetime ? datetime.format('mm') : '00');
        $this.hide();
        $this.before($('<div class="datetime-container"></div>').append($dateItem).append($hourItem).append($textHour).append($minuteItem).append($textMinute));
    });

    //Call funtion update value for datepicker, timepicker
    $(document.body).on('change', '.datepicker-item, .timepicker-item', function () {
        updateDatetimePicker($(this).closest('.datetime-container'));
    });
    //Call function update value for dateHourMinute
    $(document.body).on('change', '.date-hour-minute-item, .hour-item, .minute-item', function () {
        updateDateHourMinute($(this).closest('.datetime-container'));
    });
    $('.date-hour-minute-item').focusout(function () {
        updateDateHourMinute($(this).closest('.datetime-container'));
    });

    // Check track change form
    $('form.track-change').trackChanges();
    // Prevent double submit
    $('form:not(.allow-double-submit)').preventDoubleSubmission();

    // Form back button event
    $('.form-back-btn').on('click', function(e) {
        var $this = $(this);
        var $form = $this.closest('form.track-change');
        if($form.length && $form.isChanged()) {
            if (!confirm('入力内容は破棄されますがよろしいですか。')) {
                // Stop the link
                e.preventDefault();
            }
        }
    });

    // Event confirm before leaving a form
    // Input in form class frm-before-reload
    var formModified = 0;
    $('.frm-before-reload').on('change', function() {
        formModified = 1;
        $('.btn-return').on('click', function() {
           if(confirm('入力内容は破棄されますがよろしいですか。')) {
               $(window).off('beforeunload');
               return true;
           } else {
               return false;
           }
        });
    });

    $(window).on('beforeunload', function(e) {
        if(formModified) {
            return '入力内容は破棄されますがよろしいですか。';
        }
    });

    $('.frm-before-reload').on('submit', function() {
        $(window).off('beforeunload');
        return true;
    });

    // One-time click link
    $('.click-once').on('click', function(e) {
        e.preventDefault();
        if($(this).attr('disabled') == 'disabled'){
            return false;
        } else {
            window.location.href = $(this).attr('href');
        }

        var that = this;
        setTimeout(function() {
            $(that).attr("disabled", true);
        }, 0);
        setTimeout(function() {
            $(that).attr("disabled", false);
        }, 2500);
    });

    // Remove parameter "page" when search button click
    $('.btn-clear-page').on('click', function() {
        var $form = $(this).closest('form');
        if($form.length){
            var url = new Url($form.attr('action'));
            delete url.query.page;    // Remove page parameter
            $form.attr('action', url.toString());  // Set to
        }
    });

    //Reset form, call ajax to clear session
    $('.reset-search').click(function () {
        //Reset input
        $(this).closest('form').trigger("reset");
        $(this).closest('form').find('input:text, input[type="number"], input:password, input:file, textarea').val('');
        $(this).closest('form').find('input:radio, input:checkbox').removeAttr('checked').removeAttr('selected');
        $(this).closest('form').find('select').not('#sLength').each(function() {
            var optVal = $(this).find('option:first').val();
            $(this).val(optVal);
            $(this).trigger('change');
        });
        //Reset validate
        $('form').valid();
        //Call ajax
        $.ajax({
            method: "POST",
            url: $(this).data('url'),
            data: {
              'controller' : $(this).data('controller'),
              'action' : $(this).data('action')
            },
            dataType: "json",
            success: function(data) {
            }
        });
    });

    // Change paginate menu
    $('.paginate_menu').on('change', function(){
        var limit = $(this).val();
        var url = new Url(window.location.href);
        delete url.query.page;    // Remove page parameter
        url.query.limit = limit;  // Set limit
        // Submit form
        var formSelector = $(this).data('form');
        var $form = $('form.search-by-post');
        // If pagination tag has form-data value, then use that form selector
        if(formSelector){
            $form = $(formSelector);
        }
        if($form.length){
            $form.attr('action', url);
            $form.submit();
        }else{
            window.location.href = url.toString();
        }
    });

    // Change paginate page
    $('.pagination li a').on('click', function (e) {
        var $this  = $(this);
        var href = $this.attr('href');         // Get current href attribute
        if(href){
            var url = new Url(href);
            // Get limit
            var limit = $('.paginate_menu').val();
            if(limit){
                url.query.limit = limit;
            }

            var formSelector = $this.closest('.pagination').data('form');
            var $form = $('form.search-by-post');
            // If pagination tag has form-data value, then use that form selector
            if(formSelector){
                $form = $(formSelector);
            }
            if($form.length){
                $form.attr('action', url.toString());
                $form.submit();
                e.preventDefault();
            }else{
                window.location.href = url.toString();
                e.preventDefault();
            }
        }
    });

    // Prefecture and city
    var $prefectureSelect = $('.prefecture');
    var $citySelect = $('.city');
    if($prefectureSelect.length && $citySelect.length){
        var prefectureCity = $('#prefecture_city').data('storage');
        // Prefecture on change event
        $prefectureSelect.on('change', function () {
            // Clear all city options
            $citySelect.find('option').not(':first').remove();
            var prefecture = $prefectureSelect.val();
            // Re-add city options
            if(prefecture){
                $.each(prefectureCity[prefecture], function(key, value) {
                    $citySelect.append($("<option></option>")
                        .attr("value",key)
                        .text(value));
                });
            }
        });
    }

    /**
     * Common 全チェック入/解除のチェックボックス
     */
    $('[name="chk-all"]').on('click', function() {
        var target = $(this).attr('target');
        var check = $(this).prop('checked');

        $("input["+ target +"]:visible").each(function() {
            $(this).prop('checked', check);
        });
    });

    /**
     * Change sort
     * @author son.PH
     */
    $('.sb-sort .desc, .sb-sort .asc, .sb-sort .sorting').on('click', function() {
        var hash = $(this).closest('.sb-sort').data('hash') !== undefined? $(this).closest('.sb-sort').data('hash'): '';
        var newLink = window.location.origin + window.location.pathname + '?';
        var params = getAllUrlParams();
        var orderType = 'ASC';
        if ($(this).hasClass('desc')) {
            orderType = 'ASC';
        } else if ($(this).hasClass('asc')) {
            orderType = 'DESC';
        }
        params.push(['order_type', orderType]);
        params.push(['order_by', $(this).data('column-name')]);
        var query = [];
        for(var x in params) {
            query.push(params[x][0] + '=' + params[x][1]);
        }
        newLink = newLink + query.join('&') + hash;
        window.location.href = newLink;
    });

    //Automatically fill in the address after changing the zip code
    $('#zip').change(function() {
        var zipcode = $('#zip').val();
        getAddressByZipcode(zipcode, 'city', 'prefecture', 'address1');
        $('#city').removeClass('error-message');
        $('#city-error').remove();
        $('#prefecture').removeClass('error-message');
        $('#prefecture-error').remove();
        $('#address1').removeClass('error-message');
        $('#address1-error').remove();
    });

    // submit-a-form-on-enter-key-press
    document.onkeydown = function(evt) {
        var keyCode = evt ? (evt.which ? evt.which : evt.keyCode) : evt.keyCode;
        var formSearch = $('form').find('[name*="Search"]');
        var formModal = $('form').find('[name*="modalSubmit"]');
        if(keyCode == 13 && $('.modal').hasClass('show') && formModal.is(":visible")) {
            $(formSearch).submit(function(e){
                e.preventDefault();
            });
            return evt.target.tagName=='TEXTAREA';
        } else if(keyCode == 13 && formSearch.is(":visible")){
            formSearch.click();
            return false;
        } else {
            return;
        }
    };

    // button upload file
    $('.btn-file').click(function() {
        $(this).closest('.file-area').find('.file_error').first().html('').removeClass('hasFileError');
        $(this).closest('.file-area').find('.file-img').first().click();
    });

    $('.file-img').change(function() {
        //Remove error from server
        $(this).find('.error-message').first().addClass('d-none');
        //Run jquery validation for this file
        var checked = $(this).valid();
        if(checked && $(this).val()){
            $(this).closest('.file-area').find('.show-file').first().html(this.value.replace(/.*[\/\\]/, ''));
            $(this).closest('.file-area').find('.show-file').first().removeClass('d-none');
            // $(this).closest('.file-area').find('.temp-file').first().addClass('d-none');
        } else {
            $(this).closest('.file-area').find('.show-file').first().addClass('d-none');
            // $(this).closest('.file-area').find('.temp-file').first().removeClass('d-none');
        }
    });

    //remove autofill user and pass
    $('.autofill').focus(function () {
       $(this).removeAttr('readonly');
    });

    //block +,-,e in input type number (0 for null values, 48-57 for 0-9 numbers)
    var inputNumber = $('input[type="number"]');
    for (var i = 0 ; i < inputNumber.length; i++) {
        inputNumber[i].addEventListener("keypress", function(evt) {
            if (evt.which !== 0 && evt.which < 48 || evt.which > 57) {
                evt.preventDefault();
            }
        });
    }
});

/**
 * Returns an Object of all url parameters
 * @return {[Object]} [Key Value pairs form URL]
 */
function getAllUrlParams() {
    var keyPairs = [],
        params = window.location.search.substring(1).split('&');
    for(var i = 0; i < params.length; i++){
        var p = decodeURI(params[i]).split('=');
        keyPairs.push(p);
    }
    return keyPairs;
}

/**
 * Get address by zipcode
 * @param string zipcode
 * @param string addressId
 * @return boolean
 */
function getAddressByZipcode(zipcode, city, prefecture, address1) {
    if(zipcode){
        $.ajax({
            method: 'GET',
            url: $('#zip_code_url').val(),
            data: {zip_code: zipcode},
            success: function (result){
                result = JSON.parse(result);
                if(!jQuery.isEmptyObject(result)){
                    $('#' + city).val(result['city']);
                    $('#' + prefecture).val(result['prefecture']);
                    $('#' + address1).val(result['address']);
                } else {
                    $('#' + city).val('');
                    $('#' + prefecture).val('');
                    $('#' + address1).val('');
                }
            }
        });
        return true;
    }
    return false;
}

/**
 * Find and add change event for all switcher and targets
 * Run when document ready
 * @param container
 */
function switcherLoader(container) {
    if (!container) {
        container = 'body';
    }
    $('.switcher', container).each(function() {
        if($(this).is('select') || $(this).is('input:hidden')){
            switcher(this);
            $(this).change(function() { switcher(this); });

        } else if($(this).find('input:checkbox').length) {
            var classAll = 'show-' + $(this).attr('id');
            switchToHide('[class*="' + classAll + '-"]');
            $(this).find('input:checkbox').each(function() {
                switcher(this);
                $(this).change(function() { switcher(this); });
            });
        } else if($(this).is('input:checkbox')) {
            switcher(this);
            $(this).change(function() {
                if(!$(this).hasClass('item-readonly')){
                    switcher(this);
                }
            });
        } else if ($(this).find('input:radio').length) {
            var checkedFlag = false;
            $(this).find('input:radio').each(function() {
                $(this).change(function() { switcher(this); });
                if($(this).is(':checked')){
                    checkedFlag = true;
                    switcher(this);
                }
            });
            if(!checkedFlag){
                switcher($(this).find('input:radio:first'));
            }
        } else if($(this).find('input:checkbox').length) {
            $(this).find('input:checkbox').each(function() {
                switcher(this);
                $(this).change(function() { switcher(this); });
            });
        }
    });
}

/**
 * Switch target objects when original object's value changed
 * @param obj
 * @returns {boolean}
 */
function switcher(obj) {
    var classAll = $(obj).attr('id');
    var value = $(obj).val();
    var checked = true;
    var itemClass = '';
    if ($(obj).is('input:checkbox')) {
        if(!$(obj).hasClass('switcher')){
            classAll = $(obj).parent('.switcher').attr('id');
        } else {
            classAll = $(obj).attr('id');
        }
        itemClass = classAll + '-' + $(obj).val();
        if($(obj).is(':checked')){
            switchToShow('.show-' + itemClass);
            switchToHide('.hide-' + itemClass);
        } else {
            switchToHide('.show-' + itemClass);
            switchToShow('.hide-' + itemClass);
        }
        return true;
    } else if($(obj).is('input:radio')) {
        classAll = $(obj).closest('.switcher').attr('id');
        if (!$(obj).is(':checked')){
           checked = false;
        }
    }
    itemClass = classAll + '-' + $(obj).val();
    switchToHide('[class*="show-' + classAll + '-"]');
    switchToShow('[class*="hide-' + classAll + '-"]');
    if(checked){
        switchToShow('.show-' + itemClass);
        switchToHide('.hide-' + itemClass);
    }
}

/**
 * Hide an Object
 * @param objects
 */
function switchToHide(objects) {
    $(objects).hide();
    $.each($(objects), function() {
        if($(this).is('input, select, textarea')){
            $(this).attr('disabled', 'disabled');
        } else {
            $('input, select, textarea', $(this)).attr('disabled', 'disabled');
        }
    });
}

/**
 * Show an object
 * @param objects
 */
function switchToShow(objects) {
    $(objects).show();
    $.each($(objects), function() {
        if($(this).is(':visible')){
            if ($(this).is('input, select, textarea')) {
                $(this).removeAttr('disabled');
            } else {
                $('input, select, textarea', $(this)).removeAttr('disabled');
            }
        }
    });
}

/**
 * Open a new window
 * @param url
 * @param targetWidth
 * @param targetHeight
 */
function openNewWindow(url, targetWidth, targetHeight) {
    var width = targetWidth ? targetWidth : "auto";
    var height = targetHeight ? targetHeight : "auto";
    window.open(url, "_blank", "height = " + height + ", width = " + width + "");
}

/**
 * Update datetime picker value
 * @param $container
 */
function updateDatetimePicker($container) {
    var date = $container.find('.datepicker-item').val();
    var time = $container.find('.timepicker-item').val();
    var newVal = time ? date + ' ' + time : date;
    $container.siblings('.datetime-picker, [data-type="datetime"]').val(newVal).valid();
}

/**
 * Update date hour minute value
 * @param $container
 */
function updateDateHourMinute($container) {
    var date = $container.find('.date-hour-minute-item').val();
    var hour = $container.find('.hour-item').val();
    var minute = $container.find('.minute-item').val();
    // var newVal = hour || minute ? date + ' ' + (hour ? hour : '00') + ':' + (minute ? minute : '00') : date;
    var newVal = date ? date + ' ' + (hour ? hour : '00') + ':' + (minute ? minute : '00') : '';
    $container.siblings('.date-hour-minute, [data-type="datetime"]').val(newVal).valid();
}

/**
 * Print (for all Chrome, Firefox, IE)
 */
function print() {
    if(!document.execCommand('print', false, null)){
        window.print();
    }
}

/**
 * Check value is empty or not
 * @param string val
 * @returns boolean
 */
function isEmpty(val) {
    return (val === undefined || val == null || val.length <= 0) ? true : false;
}

/**
 * Scroll to element area
 * @param string id element id
 */
function scrollToElement(id) {
    $('html, body').animate({
        scrollTop: $('#' + id).offset().top
    }, 500);
}

//表示件数
function commonLengthMenu() {
    return '<div class="input-group">'+
        '<span class="input-group-text bb-addon">表示件数</span>'+
        '<select id="sLength" class="form-control br0 paginate_menu">'+
        '<option value="10">10</option>'+
        '<option value="50">50</option>'+
        '<option value="100">100</option>'+
        '</select>'+
        '</div>';
}

/**
 * Get binary file type from file input
 *
 * @param file File input
 * @param callback File type callback
 */
function getBinaryFileType(file, callback) {
    const filereader = new FileReader();
    filereader.onloadend = function(evt) {
        if(evt.target.readyState === FileReader.DONE){
            const uint = new Uint8Array(evt.target.result);
            let bytes = [];
            uint.forEach((byte) => {
                bytes.push(byte.toString(16))
            });
            const hex = bytes.join('').toUpperCase();

            return callback(getMimeType(hex));
        }
    };
    const blob = file.slice(0, 4);
    filereader.readAsArrayBuffer(blob);
}

/**
 * Get MIME type from file hex signature
 *
 * @param signature
 * @returns {string}
 */
function getMimeType(signature) {
    switch (signature) {
        case '89504E47':
            return 'image/png';
        case '47494638':
            return 'image/gif';
        case '25504446':
            return 'application/pdf';
        case 'FFD8FFDB':
        case 'FFD8FFE0':
            return 'image/jpeg';
        case 'FFD8FFE1':
        case 'FFD8FFE8':
            return 'image/jpg';
        case '504B0304':
            return 'application/zip';
        case '4A777744':
            return 'jww';
        case '202030D':
            return 'dxf';
        case '504B34':
        case 'D0CF11E0':
            return 'office';
        default:
            return 'Unknown';
    }
}

function showLoading() {
    $('.ajax-loading-div').css('display', 'block');
}

function hideLoading() {
    $('.ajax-loading-div').css('display', 'none');
}

//get exact length with '\n'
function customGetLengthArea(value) {
    // Look for any "\n" occurences
    var matches = String(value).match(/\n/g);
    // Duplicate count for break line (for matching with PHP)
    var addLength = matches ? (matches.length) : 0;
    var len = String(value).length - addLength;
    return len + addLength;
}

// check maxlength characters
function checkMaxLength(contents) {
    // if data empty
    if (contents === '') {
        return 0;
    }
    contents = contents.replace(/\uFEFF/g, '');
    var enter = contents.match(/<\/p>/g);
    countEnter = enter === null ? 0 : enter.length - 1;
    // get space
    var space = contents.match(/(&nbsp;?( |))/g);
    // count space
    var countSpace = 0;
    if (space !== null) {
        space.forEach(function (index) {
            if (index.length === 6) {
                countSpace += 1;
            } else {
                countSpace += 2;
            }
        });
    }
    // Handle count ordered list and unordered list
    // Get li tag in ul tag
    var ulTag = contents.match(/<ul[^>]*?>([\s\S]*?)<\/ul>/g);
    // Get li tag in ol tag
    var olTag = contents.match(/<ol[^>]*?>([\s\S]*?)<\/ol>/g);
    var liTag = null;
    var countLiTag = 0;
    // Count li tag in ul tag
    if (ulTag !== null) {
        ulTag.forEach(function (value) {
            liTag = value === null ? null : value.match(/<li>/g);
            countLiTag += liTag === null ? 0 : liTag.length; // Ex: "." is 1 character
        });
    }
    // Count li tag in ol tag
    if (olTag !== null) {
        olTag.forEach(function (value) {
            liTag = value === null ? null : value.match(/<li>/g);
            countLiTag += liTag === null ? 0 : liTag.length*2; // Ex: "1." is 2 character
        });
    }
    //Handle count tag of styles
    var styleArr = [
        '<blockquote[^>]*?>([\\s\\S]*?)<\/blockquote>', '<pre[^>]*?>([\\s\\S]*?)<\/pre>', '<h1[^>]*?>([\\s\\S]*?)<\/h1>',
        '<h2[^>]*?>([\\s\\S]*?)<\/h2>', '<h3[^>]*?>([\\s\\S]*?)<\/h3>', '<h4[^>]*?>([\\s\\S]*?)<\/h4>',
        '<h5[^>]*?>([\\s\\S]*?)<\/h5>', '<h6[^>]*?>([\\s\\S]*?)<\/h6>'
    ];
    styleArr.forEach(function (value) {
        var rgxp = new RegExp(value, 'g');
        var styleTag = contents.match(rgxp);
        if (styleTag !== null) {
            styleTag.forEach(function (value) {
                var pTag = value.match(/<\/p>/g);
                countEnter += (pTag === null) ? 1 : 0;
            });
        }
    });
    //Handle count enter in table
    var tdTag = contents.match(/<td[^>]*?>([\s\S]*?)<\/td>/g);
    if (tdTag !== null) {
        tdTag.forEach(function (value) {
            var pTag = value.match(/<\/p>/g);
            if (pTag !== null) {
                countEnter--;
            }
        });
    }
    var htmlAndSpace = contents.match(/<.+?>|(&nbsp;?( |))/g);
    // if html and space have
    if (htmlAndSpace !== null) {
        return contents.length - htmlAndSpace.join('').length + countEnter + countSpace + countLiTag;
    }
    return contents.length + countSpace;
}
