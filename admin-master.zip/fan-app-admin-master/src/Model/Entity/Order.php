<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Order Entity
 *
 * @property int $id
 * @property int $questionnaire_id
 * @property int $fan_id
 * @property \Cake\I18n\FrozenTime|null $order_date
 * @property int|null $total_no_tax
 * @property int|null $tax
 * @property int|null $shopping_cost
 * @property int|null $total_amount
 * @property int|null $payment_method
 * @property string|null $credit_token
 * @property \Cake\I18n\FrozenTime|null $receive_plan_date
 * @property \Cake\I18n\FrozenDate|null $receive_date
 * @property string|null $memo
 * @property string|null $user_name
 * @property int|null $mobile
 * @property int|null $tel
 * @property int|null $zip
 * @property int|null $prefecture
 * @property string|null $city
 * @property string|null $address1
 * @property string|null $address2
 * @property string|null $remarks
 * @property int $del_flg
 * @property int|null $created_by
 * @property \Cake\I18n\FrozenTime|null $created_at
 * @property int|null $updated_by
 * @property \Cake\I18n\FrozenTime|null $updated_at
 * @property int|null $deleted_by
 * @property \Cake\I18n\FrozenTime|null $deleted_at
 *
 * @property \App\Model\Entity\Fan $fan
 * @property \App\Model\Entity\OrderItem[] $order_items
 */
class Order extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'id' => false,
        '*' => true
    ];
}
