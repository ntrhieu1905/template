<?php
use Migrations\AbstractMigration;
use Phinx\Db\Adapter\MysqlAdapter;

class AlterMastTicket10042020 extends AbstractMigration
{
    /**
     * Change Method.
     *
     * More information on this method is available here:
     * https://book.cakephp.org/phinx/0/en/migrations.html#the-change-method
     * @return void
     */
    public function change()
    {
        $table = $this->table('mast_ticket');
        $table
            ->changeColumn('category', 'integer', [
                'default' => null,
                'null'    => true,
                'limit' => MysqlAdapter::INT_SMALL,
            ])
            ->changeColumn('area', 'integer', [
                'default' => null,
                'null'    => true,
                'limit' => MysqlAdapter::INT_TINY,
            ])
            ->update();
    }
}
