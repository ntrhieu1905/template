$(document).ready(function() {
    var winning_flg_val = {
        'lost': 0,
        'winning': 1
    }
    //Process save winning_flg when change checked
    $('[name*="winning_flg_"]').each(function() {
        $(this).on('change', function() {
            var isChecked = $(this).is(':checked');
            var winningFlg = 0;
            var questionnaireResultId = $(this).val();
            if(isChecked) { //checked
                winningFlg = winning_flg_val['winning'];
            } else { //un-checked
                winningFlg = winning_flg_val['lost'];
            }
            //Call ajax update
            $.ajax({
                url: $('#que_a011_url').val(),
                method: 'post',
                data: {
                    id: questionnaireResultId,
                    winning_flg: winningFlg
                },
                cache: false,
                dataType: 'json',
                success: function(res) {
                    if(res.code == 200){
                        window.location.reload(true);
                    }
                }
            });
        });
    });

    $("#frmA011").validate({
        submitHandler: function(form) {
            if($(form).hasClass('export-all')){
                form.submit();
                $('#csv-export-all').removeClass('export-all');
            } else if($(form).hasClass('export-condition')){
                form.submit();
                $('#csv-export-condition').removeClass('export-condition');
            } else {
                form.submit();
            }
        }
    });
    //Focus button export
    $('#csv-export-all').on('click', function() {
        $('#winning-flg').val('');
        $('#frmA011').addClass('export-all');
    });
    //Focus button export
    $('#csv-export-condition').on('click', function() {
        $('#winning-flg').val(winning_flg_val['winning']);
        $('#frmA011').addClass('export-condition');
    });

    //Jquery validate
    $('#popup-frmA011').validate({
        rules: {
            receive_date: {
                date: true
            },
            memo: {
                maxlength: 255
            }
        },
        messages: {
            receive_date: {
                date: function(params, input) {
                    return $.validator.messages.date('入金日');
                },
            },
            memo: {
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength(['メモ', params, $(input).val().length]);
                }
            }
        },
        submitHandler: function(form) {
            $('#popup-updateA011').attr('disabled', true);
            form.submit();
            //Clear form A011 after submit
            $('#popup-frmA011').each(function(){
                $(this).find(':input').val('');
            });
        }
    });

    //Pass value in modal
    $('#Que-a011').on('show.bs.modal', function(e) {
        $('#popup-frmA011').validate().resetForm();
        $('#quest-result-id').val($(e.relatedTarget).data('id'));
        $('#receive-date').val($(e.relatedTarget).data('receive_date'));
        $('#memo').val($(e.relatedTarget).data('memo'));
    });
    $('#Que-a011').on('hidden.bs.modal', function(e) {
        $(this).find('#receive-date').removeClass('error-message');
        $(this).find('#receive-date-error').remove();
        $(this).find('#memo').removeClass('error-message');
        $(this).find('#memo-error').remove();
        //Process css focus
        $(this).parent().find('#popup-'+$(this).find('#quest-result-id').val()).css({
            'background': '#3b99fc',
            'color': '#fff',
            'border': '1px solid #3b99fc'
        });
    });
});
