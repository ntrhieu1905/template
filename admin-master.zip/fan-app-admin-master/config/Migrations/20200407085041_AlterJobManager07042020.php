<?php
use Migrations\AbstractMigration;
use Phinx\Db\Adapter\MysqlAdapter;

class AlterJobManager07042020 extends AbstractMigration
{
    /**
     * Change Method.
     *
     * More information on this method is available here:
     * https://book.cakephp.org/phinx/0/en/migrations.html#the-change-method
     * @return void
     */
    public function change()
    {
        $table = $this->table('job_manager');
        $table
            ->changeColumn('job_type', 'integer', [
                'default' => null,
                'null'    => true,
                'limit'   => MysqlAdapter::INT_TINY
            ])
            ->changeColumn('job_status', 'integer', [
                'default' => null,
                'null'    => true,
                'limit'   => MysqlAdapter::INT_TINY
            ])
            ->changeColumn('job_name', 'string', [
                'default' => null,
                'null'    => true,
                'limit'   => 255
            ])
            ->update();
    }
}
