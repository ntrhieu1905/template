<?php
use Migrations\AbstractMigration;

class AlterQuestionnaire01042020 extends AbstractMigration
{
    /**
     * Change Method.
     *
     * More information on this method is available here:
     * https://book.cakephp.org/phinx/0/en/migrations.html#the-change-method
     * @return void
     */
    public function change()
    {
        $table = $this->table('questionnaire');
        $table->update();
        $this->execute('ALTER TABLE `questionnaire` MODIFY `shipping_cost` BIGINT(10) NOT NULL DEFAULT 0');
        $this->execute('ALTER TABLE `questionnaire` MODIFY `free_shipping` BIGINT(10) NOT NULL DEFAULT 0');
    }
}
