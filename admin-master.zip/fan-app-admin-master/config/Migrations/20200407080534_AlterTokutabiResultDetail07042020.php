<?php
use Migrations\AbstractMigration;

class AlterTokutabiResultDetail07042020 extends AbstractMigration
{
    /**
     * Change Method.
     *
     * More information on this method is available here:
     * https://book.cakephp.org/phinx/0/en/migrations.html#the-change-method
     * @return void
     */
    public function change()
    {
        $table = $this->table('tokutabi_result_detail');
        $table
            ->dropForeignKey('tokutabi_id', 'tokutabi_result_detail_ibfk_1')
            ->removeColumn('tokutabi_id')
            ->addColumn('tokutabi_result_id', 'biginteger', [
                'default' => null,
                'null' => true,
                'after'   => 'id'
            ])
            ->addForeignKey('tokutabi_result_id', 'tokutabi_result', 'id')
            ->update();
    }
}
