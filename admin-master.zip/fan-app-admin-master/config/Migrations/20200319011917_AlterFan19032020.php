<?php
use Migrations\AbstractMigration;
use Phinx\Db\Adapter\MysqlAdapter;

class AlterFan19032020 extends AbstractMigration
{
    /**
     * Change Method.
     *
     * More information on this method is available here:
     * https://book.cakephp.org/phinx/0/en/migrations.html#the-change-method
     * @return void
     */
    public function change()
    {
        $table = $this->table('fan');
        $table
            ->addColumn('auto_login', 'integer', [
                'default' => 0,
                'null' => false,
                'limit' => MysqlAdapter::INT_TINY,
                'after' => 'memo',
            ])
            ->update();
    }
}
