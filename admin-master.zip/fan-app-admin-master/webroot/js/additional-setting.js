/**
 * Created by dat.tnt on 04/10/2019.
 */

// Form track changes
$.fn.extend({
    trackChanges: function() {
        $(this).data('serialize', $(this).serialize());
    },
    isChanged: function() {
        return $(this).serialize() != $(this).data('serialize');
    },
    preventDoubleSubmission: function () {
        $(this).on('submit', function (e) {
            var $form = $(this);

            if ($form.data('submitted') === true) {
                // Previously submitted - don't submit again
                e.preventDefault();
            } else {
                // Mark it so that the next submit can be ignored
                // ADDED requirement that form be valid
                if($form.valid()) {
                    $form.data('submitted', true);
                }
            }
        });
        // Keep chainability
        return this;
    }
});

// Change timepicker default options
if($.fn.timepicker) {
    $.extend($.fn.timepicker.defaults,{
        showMeridian: false,
        defaultTime: false
    });
}

// Change validator messages method
$.extend(jQuery.validator, {
    messages: {
        required: $.validator.format("{0}は必須項目です。"),
        email: $.validator.format("メールアドレスを正しく入力してください。"),
        url: $.validator.format("URLを正しく入力してください。"),
        date: $.validator.format("{0}は日付を正しく入力してください。"),
        datetime: $.validator.format("{0}は日時を正しく入力してください。"),
        date_time: $.validator.format("{0}は日時を正しく入力してください。"),
        number: $.validator.format("{0}は半角数字で入力してください。"),
        digits: $.validator.format("半角数字で入力してください"),
        equalTo: $.validator.format("確認用の{0}が間違っています。"),
        equalToExt: $.validator.format("確認用の{1}が間違っています。"),
        maxlength: $.validator.format("{0}は「{1}」文字以下で入力してください。（現在{2}文字）"),
        maxLengthEditor: $.validator.format("{0}は「{1}」文字以下で入力してください。（現在{2}文字）"),
        minlength: $.validator.format("{0}は「{1}」文字以上で入力してください。（現在{2}文字）"),
        rangelength: $.validator.format("{0}桁以上、{1}桁以下で入力してください。"),
        passwordrange: $.validator.format("半角英数字記号で8～20文字で入力してください。"),
        passwordRule: $.validator.format("{0}は英字（大文字・小文字）・数字の3種類の文字種を全て使用してください。"),
        admin_passwordrange: $.validator.format("半角英数字記号で8～25文字で入力してください。"),
        passwordsameTouserid: $.validator.format("パスワードには会員IDと同じ値は使用できません。"),
        passwordisAlphanum: $.validator.format("パスワードには半角数字のみ、または半角英字のみの値は使用できません。"),
        passwordInvalid: $.validator.format("半角英字および以下の文字以外はご使用いただけません。(「#」、「$」、「%」、「(」、「)」、「*」、「+」、「-」、「.」、「/」、「:」、「;」、「?」、「@」、「[」、「]」、「_ 」、「{」、「}」、「~」)"),
        phone: $.validator.format("電話番号を正しく入力してください。"),
        latin: $.validator.format("半角英数で入力してください。"),
        character_invalid: $.validator.format("以下の文字はご使用いただけません。(「#」、「$」、「%」、「(」、「)」、「*」、「+」、「-」、「.」、「/」、「:」、「;」、「?」、「@」、「[」、「]」、「_ 」、「{」、「}」、「~」)"),
        extension: $.validator.format("ファイル形式が誤っています。{0}を選択してください。"),
        filesize: $.validator.format("ファイルのサイズ制限{0}MBを超えています。"),
        workingAreaRequired: $.validator.format("{0}は必須項目です。(主な活動エリアを先に選択してください)"),
        futureDate: $.validator.format("未来日を入力してください。"),
        screen_range: $.validator.format("半角英数字記号で6～75文字で入力してください。"),
        mail_valid: $.validator.format("メールアドレスを正しく入力してください。"),
        check2Byte: $.validator.format("全角で入力してください。"),
        fixedFileSize: $.validator.format("ファイルのサイズ制限10MBを超えています。"),
        checkKanji: $.validator.format("全角で入力してください。"),
        checkCharacterlatin: $.validator.format("{0}半角英数で入力してください。"),
        checkAlphabet: $.validator.format("半角英字で入力してください。"),
        checkKatakana: $.validator.format("{0}は全角カタカナで入力してください。"),
        check2ByteHfS: $.validator.format("全角で入力してください。"),
        checkNumeric: $.validator.format("{0}は半角数字で入力してください。"),
        checkKatakana1Byte2Byte: $.validator.format("﻿カナ、「）」「（」「.」「-」「/」、全角スペースで入力してください。"),
        checkValidEmailRFC: $.validator.format("メールアドレスを正しく入力してください。"),
        mail_valid_RFC: $.validator.format("メールアドレスを正しく入力してください。<br/>『.』が連続して使われている、＠の直前に『.』が入っているなど、使用できないメールアドレスがございます。別のメールアドレスをご利用ください。"),
        rangeEmail: $.validator.format("メールアドレスとは半角英数で入力してください。"),
        greaterThanDate: $.validator.format("{0}は{1}以降の日時を選択してください。"),
        greaterThanDateUpgrade: $.validator.format("{0}は{1}以降の日時を選択してください。"),
        greaterThanDateNormal: $.validator.format("{0}は{1}以降の日時を選択してください。"),
        lesserThanDateNormal: $.validator.format("{0}は{1}以降の日時を選択してください。"),
        lessThanDate: $.validator.format("{0}は{1}以降の日時を選択してください。"),
        checkTel: $.validator.format("{0}は電話(FAX)番号を正しく入力してください。"),
        checkPostCode: $.validator.format("{0}は半角数字で入力してください。"),
        checkFormatPostCode: $.validator.format("{0}は郵便番号を正しく入力してください。"),
        checkKatakana2ByteAndCharacter: $.validator.format("{0}は全角カナまたは\"・\"で入力してください。"),
        passwordEqualTo: $.validator.format("パスワードと確認用パスワードが一致しません。"),
        check1ByteSpecialChars: $.validator.format("{0}では半角英字および以下の文字以外はご使用いただけません。(「#」、「$」、「%」、「(」、「)」、「*」、「+」、「-」、「.」、「/」、「:」、「;」、「?」、「@」、「[」、「]」、「_ 」、「{」、「}」、「~」)。"),
        checkData: $.validator.format("ポート数の合計が一致しませんでした。(合計ポート数:{0} 戸数:{1})"),
        check1Byte: $.validator.format("{0}は半角数字で入力してください。"),
        checkKatakana2Byte: $.validator.format("{0}は全角カナまたは\"・\"で入力してください。"),
        digitsCustom: $.validator.format("{0}は半角数字で入力してください。"),
        date_month: $.validator.format("{0}は年月を正しく入力してください。"),
        existDataInTable: $.validator.format("選択された工事番号はすでに登録されています。"),
        greaterThanDateSendTime: $.validator.format("配信予定日時は現在時刻から７２時間後までしか設定できません。"),
        checkExistsEmail: $.validator.format("{0}が既に登録済みです。"),
        limitCorrectly: $.validator.format("購入上限値，下限値を正しく入力してください"),
    }
});

$.validator.setDefaults({
    errorClass: 'error-message',
    errorElement: 'div',
    // add default behaviour for on focus out
    onfocusout: function(element) {
        this.element(element);
    }
});
//=================================================//
// Override check length method for compatibility with PHP
$.validator.methods.minlength = function(value, element, param) {
    var length = $.isArray( value ) ? value.length : customGetLengthArea( value, element );
    return this.optional( element ) || length >= param;
};

$.validator.methods.maxlength = function(value, element, param) {
    var length = $.isArray( value ) ? value.length : customGetLengthArea( value, element );
    return this.optional( element ) || length <= param;
};

$.validator.methods.maxLengthEditor = function(value, element, param) {
    var length = $.isArray( value ) ? value.length : checkMaxLength( value, element );
    return this.optional( element ) || length <= param;
};

function customGetLength(value, element) {
    if(element){
        switch ( element.nodeName.toLowerCase() ) {
            case "select":
                return $( "option:selected", element ).length;
            case "input":
                if ( checkable( element ) ) {
                    return this.findByName( element.name ).filter( ":checked" ).length;
                }
        }
    }
    // Look for any "\n" occurences
    var matches = value.match(/\n/g);
    // Duplicate count for break line (for matching with PHP)
    var addLength = matches ? matches.length : 0;
    return value.length + addLength;
}

function checkable(element) {
    return (/radio|checkbox/i).test(element.type);
}
//=================================================//

var lastLimit = new Date('2200/12/31');
var firstLimit = new Date('1700/01/01');
$.validator.methods.date = function(value, element, param) {
    var inputDate = new Date(value);
    return  value=='' || moment(value, 'YYYY/MM/DD', true).isValid() && ((firstLimit <= inputDate) && (inputDate <= lastLimit));
};

$.validator.addMethod("datetime", function(value, element, params) {
    var inputDate = new Date(value);
    return  value=='' || (moment(value, 'YYYY/MM/DD H:mm:ss',true).isValid() && ((firstLimit <= inputDate) && (inputDate <= lastLimit))) || (moment(value, 'YYYY/MM/DD H:mm',true).isValid() && ((firstLimit <= inputDate) && (inputDate <= lastLimit))) || (moment(value, 'YYYY/MM/DD',true).isValid() && ((firstLimit <= inputDate) && (inputDate <= lastLimit)));
});

$.validator.addMethod("date_time", function(value, element, params) {
    return  value=='' || moment(value, 'YYYY/MM/DD H:mm:ss',true).isValid() || moment(value, 'YYYY/MM/DD H:mm',true).isValid();
});

$.validator.addMethod("date_month", function(value, element, params) {
    return  value=='' || moment(value, 'YYYY/MM',true).isValid() || moment(value, 'YYYY/MM',true).isValid();
});

$.validator.addMethod( "passwordrange", function(value, element, params) {
    return this.optional(element) || /^[0-9a-zA-Z\#\$\%\(\)\*\+\-\.\/\:\;\?\@\[\]\_\{\}\~]{8,20}$/i.test(value);
});

$.validator.addMethod( "admin_passwordrange", function(value, element, params) {
    return this.optional(element) || /^[0-9a-zA-Z\#\$\%\(\)\*\+\-\.\/\:\;\?\@\[\]\_\{\}\~]{8,25}$/i.test(value);
});

$.validator.addMethod( "screen_range", function(value, element, params) {
    return this.optional(element) || /^[0-9a-zA-Z\#\$\%\(\)\*\+\-\.\/\:\;\?\@\[\]\_\{\}\~]{6,75}$/i.test(value);
});

$.validator.addMethod("latin", function(value, element) {
    return this.optional(element) || /^[a-zA-Z0-9~`!@#$%^&*()-_=+<>?,./:;"'{}]*$/.test(value);
});

$.validator.addMethod("mail_valid", function(value, element, dependent) {
    if(($(dependent).val() !='' && value == '') || ($(dependent).val() =='' && value != '')) {
        return false;
    }
    var email = $(dependent).val().concat('@');
    email = email.concat(value);
    return this.optional(element) || /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/i.test(email);
});

$.validator.addMethod("character_invalid", function(value, element) {
    return this.optional(element) || /^[a-zA-Z0-9`!^&=<>,"']*$/.test(value);
});

$.validator.addMethod("passwordsameTouserid", function(value, element, params) {
    // bind to the blur event of the target in order to revalidate whenever the target field is updated
    // TODO find a way to bind the event just once, avoiding the unbind-rebind overhead
    var target = $(params);
    if(this.settings.onfocusout){
        target.unbind(".validate-equalTo").bind("blur.validate-equalTo", function() {
            $(element).valid();
        });
    }
    return !(value === target.val());
});

$.validator.addMethod( "passwordisAlphanum", function(value, element, params) {
    if ( this.optional(element) ) {
        return "dependency-mismatch";
    }
    // accept only spaces, digits and dashes
    return !(/^[0-9]*$/.test(value) || /^[a-zA-Z]*$/.test(value));
});

$.validator.addMethod( "passwordInvalid", function(value, element, params) {
    return this.optional(element) || /^[a-zA-Z0-9~#$%\*+\-_\[\]\\.;/{}\\:\()?@]*$/.test(value);
});

//custom validation method for file size
$.validator.addMethod("filesize", function(value, element, param) {
    return this.optional(element) || (element.files[0].size <= param *1024*1024);
});

$.validator.addMethod("fixedFileSize", function(value, element, param) {
    return value ? (this.optional(element) || (element.files[0].size <= 10 *1024*1024)) : true;
});

$.validator.addMethod("check2Byte", function(value, element) {
    //return ! value.match(/^[^\u3000-\u303f\u3040-\u309f\u30a0-\u30ff\uff00-\uff9f\u4e00-\u9faf\u3400-\u4dbf]+$/);
    if (value.length > 0)
        return((value.match(/^[^\x01-\x7E\xA1-\xDF]+$/)) ? ((value.match(/^[ｱ-ﾝﾞﾟｧ-ｫｬ-ｮｰ｡｢｣､]+$/)) ? false : true) : false);
    else
        return true;
});

$.validator.addMethod("check2ByteHfS", function(value, element) {
    for(var i=0; i<value.length; i++) {
        var unicode = value.charCodeAt(i);
        if(unicode>=0xff61 && unicode<=0xff9f){ //hankaku kana
            return false;
        } else if ((unicode >= 0x4e00 && unicode <= 0x9fcf) || // CJK統合漢字
            (unicode >= 0x3400 && unicode <= 0x4dbf) || // CJK統合漢字拡張A
            (unicode >= 0x20000 && unicode <= 0x2a6df) || // CJK統合漢字拡張B
            (unicode >= 0xf900 && unicode <= 0xfadf) || // CJK互換漢字
            (unicode >= 0x2f800 && unicode <= 0x2fa1f)||
            (unicode >=0x30a0 && unicode<=0x30ff) ||  //check kana 2 byte.
            (unicode>=0x3040 && unicode<=0x309f) || //check hiragana 2 byte.
            (unicode ==0x0020) || //space 1 byte
            (unicode ==0x3000) || //space 2 byte
            (unicode>=0xff00 && unicode<=0xfff0) //alphabet 2 byte
        ){

        } else {
            return false;
        }
    }
    return true;
});

$.validator.addMethod("rangeEmail", function(value, element, param) {
    //!#$%&'*+-/=?^_`{|}~.
    return this.optional(element) || /^[0-9a-zA-Z\#\!\$\%\(\)\*\+\-\.\/\:\;\?\'\=\`\|\&\@\^\[\]\_\{\}\~]{6,75}$/i.test(value);
});

$.validator.addMethod("checkKanji", function(value, element) {
    for(var i=0; i<value.length; i++) {
        var unicode = value.charCodeAt(i);
        if ((unicode >= 0x4e00 && unicode <= 0x9fcf) || // CJK統合漢字
            (unicode >= 0x3400 && unicode <= 0x4dbf) || // CJK統合漢字拡張A
            (unicode >= 0x20000 && unicode <= 0x2a6df) || // CJK統合漢字拡張B
            (unicode >= 0xf900 && unicode <= 0xfadf) || // CJK互換漢字
            (unicode >= 0x2f800 && unicode <= 0x2fa1f)||
            (unicode >=0x30a0 && unicode<=0x30ff) ||  //check kana 2 byte.
            (unicode>=0x3040 && unicode<=0x309f) //check hiragana 2 byte.
        ){

        } else {
            return false;
        }
    }
    return true;
});

$.validator.addMethod("checkKatakana", function(value, element) {
    for(var i=0; i<value.length; i++) {
        var unicode = value.charCodeAt(i);
        if ((unicode>=0x30a0 && unicode<=0x30ff) ||
            (unicode ==0x0020) || //space 1 byte
            (unicode ==0x3000)
        ){

        } else {
            return false;
        }
    }
    return true;
});

$.validator.addMethod("checkKatakana1Byte2Byte", function(value, element) {
    var result = true;
    if(value.length > 0){
        result = value.match(/^[\uFF65-\uFF9F\u30A0-\u30FF.\)\(\/\-\　]+$/) ? true : false;
    }
    return result;
});

$.validator.addMethod("checkKatakana2ByteAndCharacter", function(value, element) {
    var result = true;
    if(value.length > 0){
        result = value.match(/^[\u30A0-\u30FF]+$/) ? true : false;
    }
    return result;
});

$.validator.addMethod("checkCharacterlatin", function(value, element) {
    return this.optional(element) || /^[a-zA-Z0-9]*$/.test(value);
});

$.validator.addMethod("checkAlphabet", function(value, element) {
    return this.optional(element) || /^[a-zA-Z]*$/.test(value);
});

$.validator.addMethod("checkNumeric", function(value, element) {
    return this.optional(element) || /^[0-9]*$/.test(value);
});

$.validator.addMethod('digitsCustom', function(value, element) {
    return this.optional(element) || /^[0-9-]*$/.test(value);
});

$.validator.addMethod('checkSumPort', function(value, element, params) {
    var kosu = 0;
    var portCount = 0;
    var free_n = 0;
    var paid_n = 0;
    var owner_n = 0;
    var free_h = 0;
    var paid_h = 0;
    var owner_h = 0;
    var free_s = 0;
    var paid_s = 0;
    var owner_s = 0;
    var free_o = 0;
    var paid_o = 0;
    var owner_o = 0;
    if($('#kosu').val()){
        kosu = parseInt($('#kosu').val());
    }
    if($('#port-count').val()){
        portCount = parseInt($('#port-count').val());
    }
    if($('#free-port-count-n').val()) {
        free_n = parseInt($('#free-port-count-n').val());
    }
    if($('#free-port-count-h').val()) {
        free_h = parseInt($('#free-port-count-h').val());
    }
    if($('#free-port-count-s').val()) {
        free_s = parseInt($('#free-port-count-s').val());
    }
    if($('#free-port-count-o').val()) {
        free_o = parseInt($('#free-port-count-o').val());
    }
    if($('#paid-port-count-n').val()) {
        paid_n = parseInt($('#paid-port-count-n').val());
    }
    if($('#paid-port-count-h').val()) {
        paid_h = parseInt($('#paid-port-count-h').val());
    }
    if($('#paid-port-count-s').val()) {
        paid_s = parseInt($('#paid-port-count-s').val());
    }
    if($('#paid-port-count-o').val()) {
        paid_o = parseInt($('#paid-port-count-o').val());
    }
    if($('#owner-port-count-n').val()) {
        owner_n = parseInt($('#owner-port-count-n').val());
    }
    if($('#owner-port-count-h').val()) {
        owner_h = parseInt($('#owner-port-count-h').val());
    }
    if($('#owner-port-count-s').val()) {
        owner_s = parseInt($('#owner-port-count-s').val());
    }
    if($('#owner-port-count-o').val()) {
        owner_o = parseInt($('#owner-port-count-o').val());
    }
    if(kosu > 0 || portCount > 0
        || free_n > 0 || free_h > 0 || free_s > 0 || free_o > 0
        || paid_n > 0 || paid_h > 0 || paid_s > 0 || paid_o > 0
        || owner_n > 0 || owner_h > 0 || owner_s > 0 || owner_o > 0
    ){
        var totalPortCount = free_n + free_h + free_s + free_o
                                + paid_n + paid_h + paid_s + paid_o
                                + owner_n + owner_h + owner_s + owner_o;

        if($("#total_port_count").length > 0){
            $("#total_port_count").val(totalPortCount);
        }

        if(portCount === totalPortCount && kosu === totalPortCount){
            return true;
        }
    }else if(kosu === 0 && portCount === 0 && free_n === 0 && free_h === 0 && free_s === 0 && free_o === 0
        && paid_n === 0 && paid_h === 0 && paid_s === 0 && paid_o === 0
        && owner_n === 0 && owner_h === 0 && owner_s === 0 && owner_o === 0){
        return true;
    }else{
        return false;
    }
},function(params, element) {
    var kosu = 0;
    var portCount = 0;
    if($('#kosu').val()){
        kosu = parseInt($('#kosu').val());
    }
    if($('#port-count').val()){
        portCount = parseInt($('#port-count').val());
    }
    if($("#total_port_count").length > 0){
        portCount = $("#total_port_count").val();
    }
    return $.validator.messages.checkData(portCount, kosu);
});

$.validator.addMethod("checkValidEmailRFC", function(value, element) {
    var matchRules = new RegExp(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/);
    var latinRule = /^[a-zA-Z0-9~`!@#$%^&*()-_=+<>?,./:;"'{}]*$/.test(value);
    return this.optional(element) || (matchRules.test(value) && latinRule);
});

$.validator.addMethod("mail_valid_RFC", function(value, element,dependent ) {
    if(($(dependent).val() !='' && value == '')||($(dependent).val() =='' && value != '')){
        return false;
    }
    var email = $(dependent).val().concat('@');
    email = email.concat(value);
    var matchRules = new RegExp(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/);
    var latinRule = /^[a-zA-Z0-9~`!@#$%^&*()-_=+<>?,./:;"'{}]*$/.test(email);
    return this.optional(element) || (matchRules.test(email) && latinRule);
});

$.validator.addMethod("greaterThanDate",
    function(value, element, params) {
        if($(params).val().length > 0 && value.length > 0){
            if (!/Invalid|NaN/.test(new Date(value))) {
                if(new Date(value) <= new Date($(params).val())){
                    if ($(params).hasClass('error-message')) {
                        $(params).removeClass('error-message');
                        $(params).next().remove();
                    }
                }
                return new Date(value) <= new Date($(params).val());
            }

            return isNaN(value) && isNaN($(params).val())
                || (Number(value) > Number($(params).val()));
        } else {
            return true;
        }
});

$.validator.addMethod("greaterThanDateUpgrade",
    function(value, element, params) {
        if($(params).val().length > 0 && value.length > 0){
            if (moment(value, 'YYYY/MM/DD', true).isValid() && moment($(params).val(), 'YYYY/MM/DD', true).isValid()) {
                if(new Date(value) <= new Date($(params).val())){
                    if ($(params).hasClass('error-message')) {
                        $(params).removeClass('error-message');
                        $(params).next().remove();
                    }
                }
                return new Date(value) <= new Date($(params).val());
            }
        }
        return true;
    });

$.validator.addMethod("greaterThanDateNormal", function(value, element) {
    var startDateInput = $("#start-time");
    var formatDate = 'YYYY/MM/DD H:mm';
    if($(element).attr('id') === 'end-time-ticket') {
        startDateInput = $("#start-time-ticket");
    }
    if($(element).attr('name') === 'exp_to') {
        startDateInput = $("#exp_from");
        formatDate = 'YYYY/MM/DD';
    }
    var parentDiv = $(element).parents('div.row'); //closest to parent div
    var startDate = startDateInput.val();
    if (value.length > 0 && startDate.length > 0) {
        if(moment(value, formatDate,true).isValid() && moment(startDate, formatDate,true).isValid()) {
            startDateInput.removeClass('error-message');
            parentDiv.find('div.error-message').remove();
            return new Date(value) >= new Date(startDate);
        }
    }
    return true;
});

$.validator.addMethod("lesserThanDateNormal", function(value, element) {
    var endDateInput = $("#end-time");
    var formatDate = 'YYYY/MM/DD H:mm';
    if($(element).attr('id') === 'start-time-ticket') {
        endDateInput = $("#end-time-ticket");
    }
    if($(element).attr('name') === 'exp_from') {
        endDateInput = $("#exp_to");
        formatDate = 'YYYY/MM/DD';
    }
    var parentDiv = $(element).parents('div.row'); //closest to parent div
    var endDate = endDateInput.val();
    if (value.length > 0 && endDate.length > 0) {
        if (moment(value, formatDate,true).isValid() && moment(endDate, formatDate,true).isValid()) {
            endDateInput.removeClass('error-message');
            parentDiv.find('div.error-message').remove();
            return new Date(value) <= new Date(endDate);
        }
    }
    return true;
});

$.validator.addMethod("lessThanDate",
    function(value, element, params) {
        if($(params).val().length > 0 && value.length > 0){
            if (moment(value, 'YYYY/MM/DD', true).isValid() && moment($(params).val(), 'YYYY/MM/DD', true).isValid()) {
                if(new Date(value) >= new Date($(params).val())){
                    if ($(params).hasClass('error-message')) {
                        $(params).removeClass('error-message');
                        $(params).next().remove();
                    }
                }
                return new Date(value) >= new Date($(params).val());
            }
        }
        return true;
});

$.validator.addMethod("greaterThanDateSendTime", function (value, element) {
    var send_time = value;
    var send_time_date = new Date(send_time);
    var now = new Date();
    if (send_time_date <= now || send_time_date >= now.setDate(now.getDate() + 3)) {
        return false;
    }
    return true;
});

/**
 * jQuery Validation custom rule,
 * check format xxx-xxxx
 */
$.validator.addMethod('checkFormatPostCode', function(value, element) {
    var form      = $(element).form().attr("id");
    var postcode1 = $('#postcode-1').val();
    var postcode2 = $('#postcode-2').val();
    $("#postcode-1").change(function() {
        $("form").validate().element("#postcode-2");
    });
    $("#postcode-2").change(function() {
        $("form").validate().element("#postcode-1");
    });
    if(($(element).attr("id") == "postcode-1") && (postcode1 == '' && postcode2 != '')){
        return false;
    }
    if(($(element).attr("id") == "postcode-2") && (postcode1 != '' && postcode2 == '')){
        return false;
    }
    return true;
});

/**
 * jQuery Validation custom rule,
 * only accept 1 byte for post code
 */
$.validator.addMethod('checkPostCode', function(value, element, param) {
    if(param && !$('form').hasClass('export')){
        return this.optional(element) || /^[0-9]*$/.test(value);
    }
    return true;
});

/**
 * jQuery Validation custom rule,
 * only accept 1 byte for post code
 */
$.validator.addMethod('maxSearchLength', function(value, element, param) {
    if(param && !$('form').hasClass('export')){
        var length = $.isArray( value ) ? value.length : customGetLength( value, element );
        return this.optional(element) || length <= param;
    }
    return true;
});

/**
 * jQuery Validation custom rule,
 * only accept 1 byte and '-' for tel number
 */
$.validator.addMethod('checkTel', function(value, element, param) {
    if(param && !$('#frmDho01').hasClass('export')){
        return this.optional(element) || /^[0-9-]*$/.test(value);
    }
    return true;
});

/**
 * jQuery Validation custom rule,
 * only accept 1 byte and 20 types of character
 */
$.validator.addMethod('check1ByteSpecialChars', function(value, element) {
    return this.optional(element) || /^[a-zA-Z0-9#$%()*+\-./:;?@\[\]_{}~]*$/.test(value);
});

//custom validate.
function isInt(value) {
    return !isNaN(value) && (function(x) { return (x | 0) === x; })(parseFloat(value));
}
$.validator.addMethod('checkMaxlength', function(val, element) {
    return (val.length > 0 && val.length > $(element).data('max-length')) ? false : true;
}, function(params, element) {
    return $.validator.messages.maxlength([$(element).data('name'), $(element).data('max-length'), $(element).val().length]);
});

$.validator.addMethod('checkNumber', function(value, element) {
    return this.optional(element) || /^[0-9]*$/.test(value);
}, function(params, element) {
    return $.validator.messages.check1Byte($(element).data('name'));
});

$.validator.addMethod('checkDecimalFormat', function(val, element) {
    if(val.length === 0)
        return true;
    return !isNaN(val);
}, function(params, element) {
    return $.validator.messages.digits($(element).data('name'));
});

$.validator.addMethod('checkRequired', function(val, element) {
    return !(val === null || val === undefined || val.length === 0);
}, function(params, element) {
    return $.validator.messages.required($(element).data('name'));
});

$.validator.addMethod('workingAreaRequired', function(val, element) {
    return !(val === null || val === undefined || val.length === 0);
});

function checkKatakana2Byte(value, element) {
    var result = true;
    if(value.length > 0){
        result = value.match(/^[・\u30a0-\u30ff　]*$/) ? true : false;
    }
    return result;
}

$.validator.addMethod("checkKatakana2ByteAndCharacter",
    function(value, element) {
        return checkKatakana2Byte(value, element);
    }
);


$.validator.addMethod("checkKatakana2ByteAndCharacterWithMessage",
    function(value, element) {
        return checkKatakana2Byte(value, element);
    },
    function(params, element) {
        return $.validator.messages.checkKatakana2Byte($(element).data('name'));
    }
);

$.validator.addMethod("checkDatetime", function(value, element, params) {
    var inputDate = new Date(value);
    return  value=='' || (moment(value, 'YYYY/MM/DD H:mm:ss',true).isValid() && ((firstLimit <= inputDate) && (inputDate <= lastLimit))) || (moment(value, 'YYYY/MM/DD H:mm',true).isValid() && ((firstLimit <= inputDate) && (inputDate <= lastLimit))) || (moment(value, 'YYYY/MM/DD',true).isValid() && ((firstLimit <= inputDate) && (inputDate <= lastLimit)));
},function(params, element) {
    return $.validator.messages.datetime($(element).data('name'));
});

$.validator.addMethod("checkDatetime2", function(value, element, params) {
    var inputDate = new Date(value);
    return  value=='' || (moment(value, 'YYYY/MM/DD H:mm:ss',true).isValid() && ((firstLimit <= inputDate) && (inputDate <= lastLimit))) || (moment(value, 'YYYY/MM/DD H:mm',true).isValid() && ((firstLimit <= inputDate) && (inputDate <= lastLimit))) || (moment(value, 'YYYY/MM/DD',true).isValid() && ((firstLimit <= inputDate) && (inputDate <= lastLimit)));
},function(params, element) {
    return $.validator.messages.date_time($(element).data('name'));
});

$.validator.addMethod("compareData", function(value, element, params) {
    var kosu = 0;
    var portCount = 0;
    var freePortCountN = 0;
    var paidPortCountN = 0;
    var ownerPortCountN = 0;
    if($('#kosu').val()){
        kosu = parseInt($('#kosu').val());
    }
    if($('#port-count').val()){
        portCount = parseInt($('#port-count').val());
    }
    if($('#free-port-count-n').val()){
        freePortCountN = parseInt($('#free-port-count-n').val());
    }
    if($('#paid-port-count-n').val()){
        paidPortCountN = parseInt($('#paid-port-count-n').val());
    }
    if($('#owner-port-count-n').val()){
        ownerPortCountN = parseInt($('#owner-port-count-n').val());
    }
    if(kosu > 0 || portCount > 0 || freePortCountN > 0 || paidPortCountN > 0 || ownerPortCountN > 0){
        var totalPortCount = freePortCountN + paidPortCountN + ownerPortCountN;
        if(portCount === totalPortCount && kosu === totalPortCount){
            return true;
        }
    }else if(kosu === 0 && portCount === 0 && freePortCountN === 0 && paidPortCountN === 0 && ownerPortCountN === 0){
        return true;
    }else{
        return false;
    }

},function(params, element) {
    return $.validator.messages.checkData($(element).data('name'),$(element).data('compare-name'));
});

$.validator.addMethod("chechExist", function (value, element, params) {
    var construction_no_list = $('[name="construction_no_list"]').val().length !== 0 ? JSON.parse($('[name="construction_no_list"]').val()) : [];
    var list_arr = Object.keys(construction_no_list).map(function (key) { return construction_no_list[key]; });
    var construction_no = $('#construction-no').val();
    var construction_no_old = $('#construction-no-old').val();
    if(jQuery.inArray(construction_no, list_arr) !== -1 && construction_no_old !== construction_no) {
        return false;
    }
    return true;
}, function(params, element) {
    return $.validator.messages.existDataInTable();
});

$.validator.addMethod("passwordRule", function(value, element, params) {
    return this.optional(element) || /^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)[a-zA-Z\d]{9,21}$/.test(value);
});

$.validator.addMethod("checkLimit", function(value, element) {
    var number = $('#number');
    var limit = $(element).val();
    var amount = number.val();
    if (parseInt(limit) > parseInt(amount) || parseInt(limit) < 0) {
        return false;
    }
    return true;
});

$.validator.addMethod("numberCorrectly", function(value, element) {
    var number = parseInt($(element).val()); //get value number input
    var lowerlimit = typeof $(element).data('lower') !== "undefined" ? parseInt($(element).data('lower')) : ""; //get value lower to compare
    var upperlimit = typeof $(element).data('upper') !== "undefined" ? parseInt($(element).data('upper')) : ""; //get value upper to compare
    // var parentDiv = $(element).parents('div.row'); //closest to parent div
    if (number < lowerlimit ||
        number < upperlimit ||
        number <= 0) { // number < lower or upper || <= 0
        $('#upper-limit').valid();
        $('#lower-limit').valid();
        return true;
    }
    if(upperlimit !== "" ) {
        if(lowerlimit <= upperlimit &&
            lowerlimit > 0 &&
            upperlimit > 0
        ) {
            $('#upper-limit').removeClass('error-message');
            $('#lower-limit').removeClass('error-message');
            $('.limit-number').find('div.error-message').remove();
        }
    } else {
        if(lowerlimit > 0 || lowerlimit < number) {
            $('#upper-limit').removeClass('error-message');
            $('#lower-limit').removeClass('error-message');
            $('.limit-number').find('div.error-message').remove();
        }
    }
    return true;
}, function (params, element) {
    return $.validator.messages.limitCorrectly;
});

$.validator.addMethod("limitCorrectly", function(value, element) {
    var number = $('#number');
    var amount = number.val();
    var limit = $(element).val(); //get value lower or upper input
    var dataLimit = $(element).data('limit'); //get value lower or upper to compare
    var parentDiv = $(element).parents('div.row'); //closest to parent div
    if (parseInt(limit) <= 0 || parseInt(limit) > amount) { // lower or upper < 0 || > value of number
        return false;
    }
    var otherLimit = parentDiv.find('input:not(#lower-limit)'); //get input number compare
    if($(element).attr('name') === 'lower_limit') { //input lower_limit
        if (parseInt(limit) > parseInt(dataLimit)) {
            return false;
        }
        if(parseInt(otherLimit.val()) <= amount &&
            parseInt(otherLimit.val()) > 0) { // upper_limit < value of number
            otherLimit.removeClass('error-message'); // remove class error message when validation input return true
            parentDiv.find('div.error-message').remove(); // remove error message when validation input return true
        }
    } else if($(element).attr('name') === 'upper_limit') {
        if (parseInt(limit) < parseInt(dataLimit)) {
            return false;
        }
        otherLimit = parentDiv.find('input:not(#upper-limit)');
        if(parseInt(otherLimit.val()) <= amount &&
            parseInt(otherLimit.val()) > 0) {
            otherLimit.removeClass('error-message');
            parentDiv.find('div.error-message').remove();
        }
    }
    return true;
});

$.validator.addClassRules({
    number: {checkNumber: true},
    decimal: {checkDecimalFormat: true},
    max_length: {checkMaxlength: true},
    required: {checkRequired: true},
    kana: {checkKatakana2ByteAndCharacterWithMessage: true},
    checkSumPort: {checkSumPort: true},
    checkDatetime: {checkDatetime: true},
    checkDatetime2: {checkDatetime2: true},
    compareData: {compareData: true},
    chechExist: {chechExist: true},
});


$(function() {
    $("ul.pagination").find("li.active > a").bind('click', false);
});

$(function() {
    $('.list-group a').bind('click', function (e) {
        var link = $(this).attr('href');
        var pos = $('.bb-sidebar').scrollTop();
        var page = $(document).scrollTop();
        sessionStorage.setItem('sidebarPosition', pos);
        sessionStorage.setItem('pagePosition', page);
    });
});

$(document).ready(function(){
    var sidebarPosition = sessionStorage.getItem('sidebarPosition');
    var page = sessionStorage.getItem('pagePosition');
    if(parseInt(page) > 110){
        $('html, body').scrollTop(110);
    } else {
        $('html, body').scrollTop(page);
    }
    setTimeout(function (){
        $('.bb-sidebar').scrollTop(parseInt(sidebarPosition));
    }, 200);
});

function numberWithCommas(number) {
    var parts = number.toString().split(".");
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    return parts.join(".");
}

