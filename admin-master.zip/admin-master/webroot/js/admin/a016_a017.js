$(document).ready(function() {
    // 価格, 残枚数 not negative
    $('body').on('input', '#unit-price', function () {
        this.value = (this.value < 0) ? Math.abs(this.value) : this.value;
    });
    $('body').on('input', '#number, #lower-limit, #upper-limit', function () {
        this.value = (this.value < 0) ? Math.abs(this.value) : this.value;
    });
    // load summernote
    loadSummernoteEditor('detail-description', 'form-a016-a017');
    $('#mast-ticket-form').validate({
        ignore: "[contenteditable='true'].note-editable",
        rules: {
            ticket_name: {
                required: true,
                maxlength: 50
            },
            list_price: {
                required: true,
                maxlength: 255
            },
            unit_price: {
                required: true,
                checkNumeric: true,
                maxlength: 10
            },
            summary_description: {
                required: true,
                maxlength: 1000
            },
            detail_description: {
                required: true,
                maxLengthEditor: 3000
            },
            image_url1: {
                extension: "jpg|jpeg|png",
                filesize: 4,
                maxlength: 50
            },
            image_url2: {
                extension: "jpg|jpeg|png",
                filesize: 4,
                maxlength: 50
            },
            image_url3: {
                extension: "jpg|jpeg|png",
                filesize: 4,
                maxlength: 50
            },
            category: {
                required: true
            },
            area: {
                required: true
            },
            number: {
                required: true,
                checkNumeric: true,
                maxlength: 5
            },
            start_time: {
                required: true,
                date_time: true,
                lesserThanDateNormal: true
            },
            end_time: {
                required: true,
                date_time: true,
                greaterThanDateNormal: true
            },
            lower_limit: {
                checkNumeric: true,
                maxlength: 5,
                limitCorrectly: true
            },
            upper_limit: {
                checkNumeric: true,
                maxlength: 5,
                limitCorrectly: true
            },
            exp_from: {
                datetime: true,
                lesserThanDateNormal: true
            },
            exp_to: {
                datetime: true,
                greaterThanDateNormal: true
            }
        },
        messages: {
            ticket_name: {
                required: function(params, input) {
                    return $.validator.messages.required('チケット名');
                },
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength(['チケット名', params, $(input).val().length]);
                }
            },
            list_price: {
                required: function(params, input) {
                    return $.validator.messages.required('定価');
                },
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength(['定価', params, $(input).val().length]);
                }
            },
            unit_price: {
                required: function(params, input) {
                    return $.validator.messages.required('価格');
                },
                checkNumeric: function(params, input) {
                    return $.validator.messages.checkNumeric('価格');
                },
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength(['価格', params, $(input).val().length]);
                }
            },
            summary_description: {
                required: function(params, input) {
                    return $.validator.messages.required('概要説明');
                },
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength(['概要説明', params, $(input).val().length]);
                }
            },
            detail_description: {
                required: function(params, input) {
                    return $.validator.messages.required('詳細説明');
                },
                maxLengthEditor: function(params, input) {
                    return $.validator.messages.maxLengthEditor(['詳細説明', params, checkMaxLength($(input).val())]);
                }
            },
            image_url1: {
                extension: function(params, input) {
                    return $.validator.messages.extension('「jpg、jpeg、png」');
                },
                filesize: function(params, input) {
                    return $.validator.messages.filesize(params);
                },
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength(['画像URL1', params, $(input).val().length]);
                }
            },
            image_url2: {
                extension: function(params, input) {
                    return $.validator.messages.extension('「jpg、jpeg、png」');
                },
                filesize: function(params, input) {
                    return $.validator.messages.filesize(params);
                },
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength(['画像URL2', params, $(input).val().length]);
                }
            },
            image_url3: {
                extension: function(params, input) {
                    return $.validator.messages.extension('「jpg、jpeg、png」');
                },
                filesize: function(params, input) {
                    return $.validator.messages.filesize(params);
                },
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength(['画像URL3', params, $(input).val().length]);
                }
            },
            category: {
                required: function(params, input) {
                    return $.validator.messages.required('カテゴリー');
                }
            },
            area: {
                required: function(params, input) {
                    return $.validator.messages.required('エリア');
                }
            },
            number: {
                required: function(params, input) {
                    return $.validator.messages.required('残枚数');
                },
                checkNumeric: function(params, input) {
                    return $.validator.messages.checkNumeric('残枚数');
                },
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength(['残枚数', params, $(input).val().length]);
                }
            },
            start_time: {
                required: function(params, input) {
                    return $.validator.messages.required('販売開始日時');
                },
                date_time: function(params, input) {
                    return $.validator.messages.date_time('販売開始日時');
                },
                lesserThanDateNormal: function(params, input) {
                    return $.validator.messages.lesserThanDateNormal(['販売終了日時', '販売開始日時']);
                }
            },
            end_time: {
                required: function(params, input) {
                    return $.validator.messages.required('販売終了日時');
                },
                date_time: function(params, input) {
                    return $.validator.messages.date_time('販売終了日時');
                },
                greaterThanDateNormal: function(params, input) {
                    return $.validator.messages.greaterThanDateNormal(['販売終了日時', '販売開始日時']);
                }
            },
            lower_limit: {
                checkNumeric: function(params, input) {
                    return $.validator.messages.checkNumeric($(input).data('label'));
                },
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), params, $(input).val().length]);
                },
                limitCorrectly: function(params, input) {
                    return $.validator.messages.limitCorrectly;
                }
            },
            upper_limit: {
                checkNumeric: function(params, input) {
                    return $.validator.messages.checkNumeric($(input).data('label'));
                },
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), params, $(input).val().length]);
                },
                limitCorrectly: function(params, input) {
                    return $.validator.messages.limitCorrectly;
                }
            },
            exp_from: {
                datetime: function(params, input) {
                    return $.validator.messages.datetime($(input).data('label'));
                },
                lesserThanDateNormal: function(params, input) {
                    return $.validator.messages.lesserThanDateNormal(['有効期限(to)', $(input).data('label')]);
                }
            },
            exp_to: {
                datetime: function(params, input) {
                    return $.validator.messages.datetime($(input).data('label'));
                },
                greaterThanDateNormal: function(params, input) {
                    return $.validator.messages.greaterThanDateNormal([$(input).data('label'), '有効期限(from)']);
                }
            }
        },
        errorPlacement: function(error, element) {
            error.appendTo($(element).parent());
        },
        submitHandler: function(form) {
            $('#mas-add-edit').attr('disabled', true);
            form.submit();
            //Clear form A016 after submit
            $('.frmA016').each(function(){
                $(this).find(':input').val('');
            });
        }
    });

    //set data upper_limit to input lower_limit
    $('#number').data('lower', $('#lower-limit').val());
    $('#upper-limit').data('limit', $('#lower-limit').val());
    $('#lower-limit').change(function () {
        $('#upper-limit').data('limit', $('#lower-limit').val());
        $('#number').data('lower', $('#lower-limit').val());
    });
    //set data lower_limit to input upper_limit
    $('#upper-limit').change(function () {
        $('#lower-limit').data('limit', $('#upper-limit').val());
        $('#number').data('upper', $('#upper-limit').val());
    });

    $('#number').change(function () {
        var number = parseInt($(this).val()); //get value number input
        var lowerlimit = typeof $(this).data('lower') !== "undefined" ? parseInt($(this).data('lower')) : ""; //get value lower to compare
        var upperlimit = typeof $(this).data('upper') !== "undefined" ? parseInt($(this).data('upper')) : ""; //get value upper to compare
        // var parentDiv = $(element).parents('div.row'); //closest to parent div
        if (number < lowerlimit ||
            number < upperlimit ||
            number <= 0) { // number < lower or upper || <= 0
            $('#upper-limit').valid();
            $('#lower-limit').valid();
            return;
        }
        if(upperlimit !== "" ) {
            if(lowerlimit <= upperlimit &&
                lowerlimit > 0 &&
                upperlimit > 0
            ) {
                $('#upper-limit').removeClass('error-message');
                $('#lower-limit').removeClass('error-message');
                $('.limit-number').find('div.error-message').remove();
            }
        } else {
            if(lowerlimit > 0 || lowerlimit < number) {
                $('#upper-limit').removeClass('error-message');
                $('#lower-limit').removeClass('error-message');
                $('.limit-number').find('div.error-message').remove();
            }
        }
    })
    // validate required when focus btn file
    $('[id*="btn-file-"]').click(function(event) {
        $(this).focus(function() {
            if($(this).closest('.file-area').find('.file-img').val() == '') {
                $(this).closest('.file-area').find('.old-img').val('');
                $(this).closest('.file-area').find('.show-file').html('');
            }
        });
    });
});
