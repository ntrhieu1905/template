<?php
namespace App\Model\Table;

use App\Libs\ValueUtil;
use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * TokutabiResultDetail Model
 *
 * @property \App\Model\Table\TokutabiTable&\Cake\ORM\Association\BelongsTo $Tokutabi
 * @property \App\Model\Table\TokutabiDetailTable&\Cake\ORM\Association\BelongsTo $TokutabiDetail
 *
 * @method \App\Model\Entity\TokutabiResultDetail get($primaryKey, $options = [])
 * @method \App\Model\Entity\TokutabiResultDetail newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\TokutabiResultDetail[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\TokutabiResultDetail|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\TokutabiResultDetail saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\TokutabiResultDetail patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\TokutabiResultDetail[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\TokutabiResultDetail findOrCreate($search, callable $callback = null, $options = [])
 */
class TokutabiResultDetailTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);
        $this->setTable('tokutabi_result_detail');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');
        $this->belongsTo('TokutabiDetail', [
            'foreignKey' => 'tokutabi_detail_id',
            'joinType' => 'INNER',
        ]);
        $this->belongsTo('TokutabiResult', [
            'foreignKey' => 'tokutabi_result_id',
            'joinType' => 'INNER',
        ]);
        $this->addBehavior('UpdateSync');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->allowEmptyString('id', null, 'create');

        $validator
            ->allowEmptyString('sort');

        $validator
            ->scalar('label_name')
            ->maxLength('label_name', 100)
            ->allowEmptyString('label_name');

        $validator
            ->integer('input_type')
            ->requirePresence('input_type', 'create')
            ->notEmptyString('input_type');

        $validator
            ->scalar('answer')
            ->allowEmptyString('answer');

        $validator
            ->allowEmptyString('created_by');

        $validator
            ->dateTime('created_at')
            ->allowEmptyDateTime('created_at');

        $validator
            ->allowEmptyString('updated_by');

        $validator
            ->dateTime('updated_at')
            ->allowEmptyDateTime('updated_at');

        $validator
            ->allowEmptyString('deleted_by');

        $validator
            ->dateTime('deleted_at')
            ->allowEmptyDateTime('deleted_at');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['tokutabi_result_id'], 'TokutabiResult'));
        $rules->add($rules->existsIn(['tokutabi_detail_id'], 'TokutabiDetail'));

        return $rules;
    }

    /**
     * get count tokutabi_result_detail by tokutabi_detail
     *
     * @param $tokutabiDetailId
     */
    public function getCountByTokutabiResultDetail($tokutabiDetailId) {
        try {
            $result = $this->find()
                ->where(['tokutabi_detail_id' => $tokutabiDetailId])
                ->andWhere(['del_flg' => ValueUtil::constToValue('common.deleted_flg.NOT_DELETED')])
                ->andWhere(['deleted_at IS NULL'])
                ->count();
            return $result;
        } catch (\Exception $e) {
            return null;
        }
    }
}
