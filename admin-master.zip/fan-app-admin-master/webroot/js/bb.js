var bb$ = jQuery;

function scrolledNav() {
    var sidebar = $('.bb-sidebar-wrapper>.bb-sidebar');
    var nav = bb$('.bb-fixed-bottom');
    var navTop = bb$('.bb-header').outerHeight();

    //ナビゲーションの高さ
    var navHeight = nav.outerHeight();
    nav.show().css({ 'bottom': -navHeight + 'px' });
    //ナビゲーションの位置まできたら表示
    var flag = 0;
    bb$(window).scroll(function() {
        var winTop = bb$(this).scrollTop();
        if (winTop >= navTop) {
            if (flag == 0) {
                nav.stop().animate({ 'bottom': '0px' });
                flag = 1;
                sidebar.css({top: '0px'});
            }
        } else if (winTop <= navTop) {
            var top = 100 - winTop;
            sidebar.css({top: top + 'px'});
            if (flag == 1) {
                nav.stop().animate({ 'bottom': -navHeight + 'px' });
                flag = 0;
            }
        }
    });
    bb$(window).scroll();
}

if (Object.keys != null) {
    bb$('body').addClass('unie8');
}

bb$(document).ready(function() {

    //bb$('.panel').height(bb$('.bb-page-content').height());

    scrolledNav();

    // Modal Video Stop
    bb$('.bb-video-modal').on('hidden.bs.modal', function(e) {
        bb$(".bb-video-modal iframe").attr("src", bb$(".bb-video-modal iframe").attr("src"));
    })

    // SideNav Toggle
    bb$(".bb-navbar-toggle").click(function(e) {
        e.preventDefault();
        bb$(".bb-wrapper").toggleClass("toggled");
    });

    // ページ内リンクをスムーズにする
    bb$('.bb-smooth').click(function(e) {
        e.preventDefault();
        var href = bb$(this).attr("href");
        var target = bb$(href == "#" || href == "#top" ? 'html' : href);
        if (target.length > 0) {
            var position = target.offset().top;
            bb$('body,html').animate({ scrollTop: position }, 400, 'swing');
        }
    });

    // 通常カレンダー
    bb$('.bb-calendar').datepicker({
        changeYear: true,
        onSelect: function(dateText) {
            if (bb$(this).hasClass('bb-wareki')) {
                var date = dateText.split('/');
                dateText = convert_wareki_core(date[0]) + "年" + date[1] + "月" + date[2] + "日";
                bb$(this).val(dateText);
            }
        }
    });

    // 特殊カレンダー（免許年月日）
    bb$('.bb-calendar-date').datepicker({
        showOn: "button",
        buttonImage: "assets/img/icon-calendar.png",
        buttonImageOnly: true,
        changeYear: true
        // , yearRange: "-35:+35"
    });

    bb$('.bb-date-input .bb-calendar-date').change(function() {
        var bbDateInput = bb$(this).parents('.bb-date-input');
        bbDateInput.find('.bb-date-input-year').val('');
        bbDateInput.find('.bb-date-input-month').val('');
        bbDateInput.find('.bb-date-input-day').val('');
        var dateText = Date.parse(bb$(this).val());
        if (dateText) {
            var dateObj = new Date();
            dateObj.setTime(dateText);
            if (bbDateInput.find(':radio:checked').val() == 'wareki') {
                var strYear = convert_wareki_core(dateObj.getFullYear());
                if (~strYear.indexOf("平成")) {
                    bbDateInput.find('.bb-date-input-wareki').prop('disabled', false);
                    bbDateInput.find('.bb-date-input-wareki').val("平成");
                    bbDateInput.find('.bb-date-input-year').val(strYear.replace(/平成/g, ""));
                } else if (~strYear.indexOf("昭和")) {
                    bbDateInput.find('.bb-date-input-wareki').prop('disabled', false);
                    bbDateInput.find('.bb-date-input-wareki').val("昭和");
                    bbDateInput.find('.bb-date-input-year').val(strYear.replace(/昭和/g, ""));
                } else if (~strYear.indexOf("大正")) {
                    bbDateInput.find('.bb-date-input-wareki').prop('disabled', false);
                    bbDateInput.find('.bb-date-input-wareki').val("大正");
                    bbDateInput.find('.bb-date-input-year').val(strYear.replace(/大正/g, ""));
                } else if (~strYear.indexOf("明治")) {
                    bbDateInput.find('.bb-date-input-wareki').prop('disabled', false);
                    bbDateInput.find('.bb-date-input-wareki').val("明治");
                    bbDateInput.find('.bb-date-input-year').val(strYear.replace(/明治/g, ""));
                }
            } else {
                bbDateInput.find('.bb-date-input-wareki').prop('disabled', true);
                bbDateInput.find('.bb-date-input-wareki').val("");
                bbDateInput.find('.bb-date-input-year').val(dateObj.getFullYear());
            }
            bbDateInput.find('.bb-date-input-month').val(dateObj.getMonth() + 1);
            bbDateInput.find('.bb-date-input-day').val(dateObj.getDate());
        }
    }).change();

    bb$('.bb-date-input :radio').change(function() {
        bb$(this).parents('.bb-date-input').find('.bb-calendar-date').change();
    });

    bb$('.bb-date-input .bb-date-input-wareki,.bb-date-input .bb-date-input-year,.bb-date-input .bb-date-input-month,.bb-date-input .bb-date-input-day').change(function() {
        var bbDateInput = bb$(this).parents('.bb-date-input');
        var strDate = bbDateInput.find('.bb-date-input-wareki').val() + bbDateInput.find('.bb-date-input-year').val() + "/" + bbDateInput.find('.bb-date-input-month').val() + "/" + bbDateInput.find('.bb-date-input-day').val();
        bbDateInput.find('.bb-calendar-date').val(forceParse(strDate)).change();
    });

    // 全てチェック
    bb$('.bb-all-check').change(function() {
        bb$('.' + this.id).prop('checked', this.checked);
    });

    // 約定報酬額計算区分
    bb$('.bb-sync-form').change(function() {
        bb$('.bb-sync-form-a').prop('disabled', false);
        bb$('.bb-sync-form-b').prop('disabled', false);
        if (bb$(this).prop('checked')) {
            if (bb$(this).hasClass('bb-sync-radio-a')) {
                bb$('.bb-sync-form-b').prop('disabled', true);
            } else {
                bb$('.bb-sync-form-a').prop('disabled', true);
            }
        }
    }).change();

    // サイドバーのクリックエリア
    bb$('.bb-sidebar .panel-heading').css({ cursor: 'pointer' }).click(function(e) {
        if (!e.target.href) {
            if (bb$(this).next('.collapse').length > 0) {
                e.preventDefault();
                bb$(this).find('a.pull-right').click();
            }
        }
    });

    //active menu after clicked
    var screen_arr = [
        'que/', 'res/', 'ord/', 'mas/', 'mai/', 'fan/', 'sta/', 'tok/', 'sur/'
    ];
    $(screen_arr).each(function (idx, val) {
        var pathname   = window.location.pathname;
        if(pathname.indexOf(val) !== -1) {
            if(val === 'que/') {
                $('.list-group:nth-child(1)').children(':first').addClass('active-menu');
            } else if(val === 'res/') {
                $('.list-group:nth-child(3)').children(':first').addClass('active-menu');
            } else if(val === 'ord/') {
                if(pathname.indexOf('ord/a0131') != -1) {
                    //Active menu if access A013_1 page
                    $('.list-group:nth-child(2)').children(':first').addClass('active-menu');
                } else if(pathname.indexOf('ord/a0141') != -1) {
                    //Active menu if access A014_1 page
                    $('.list-group:nth-child(2)').children(':first').addClass('active-menu');
                } else {
                    $('.list-group:nth-child(4)').children(':first').addClass('active-menu');
                }
            } else if(val === 'mas/') {
                $('.list-group:nth-child(5)').children(':first').addClass('active-menu');
            } else if(val === 'mai/') {
                $('.list-group:nth-child(6)').children(':first').addClass('active-menu');
            } else if(val === 'tok/') {
                $('.list-group:nth-child(7)').children(':first').addClass('active-menu');
            } else if(val === 'sur/') {
                $('.list-group:nth-child(8)').children(':first').addClass('active-menu');
            } else if(val === 'fan/') {
                $('.list-group:nth-child(9)').children(':first').addClass('active-menu');
            } else if(val === 'sta/') {
                $('.list-group:nth-child(10)').children(':first').addClass('active-menu');
            }
        }
    })
});


/**
 * End
 * ----------------------------------------------------------------------------
 */
