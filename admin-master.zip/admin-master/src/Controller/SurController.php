<?php
/**
 * Created by PhpStorm.
 * User: dat.tnt
 * Date: 2020/03/25
 * Time: 17:31
 */
namespace App\Controller;

use App\Libs\ConfigUtil;
use App\Libs\EncryptUtil;
use App\Libs\ValueUtil;
use App\Libs\DateUtil;
use App\Libs\ExportDataUtil;
use Cake\Event\Event;
use Cake\Http\Response;
use Cake\ORM\TableRegistry;
use Exception;

/**
 * Survey content controller
 */
class SurController extends AppAdminController
{
    /**
     * Override beforeFilter callback
     *
     * @return \Cake\Network\Response|null|void
     */
    public function beforeFilter(Event $event) {
        parent::beforeFilter($event);
        //Load common model
        $this->loadModel('Staff');
        $this->loadModel('TokutabiResult');
        $this->loadModel('Tokutabi');
    }

    /**
     * A026 アンケート一覧
     * @return Response|null
     */
    public function a026() {
        //Get session
        $session = $this->getRequest()->getSession();
        //Check searching data session
        $params = [];
        if ($session->check('Sur.a026')) {
            //When have session
            $params = $session->read('Sur.a026');
            $this->set([
                'searchData' => $params,
            ]);
        }
        //Process after submit
        if ($this->getRequest()->is(['post'])) {
            //Write data from POST to session
            $session->write('Sur.a026', $this->getRequest()->getData());
            //Reload page
            return $this->redirect(['action' => 'a026']);
        }
        //Get records from database then paginate result
        $result = $this->Tokutabi->searchA026($params);
        $tokutabis = $this->paginate($result, ['limit' => ConfigUtil::get('paginate.ten_pages')]);
        //Show list evaluation
        $this->set(compact('tokutabis'));
        $this->set('baseURL', $this->getUrlTemplate(null, 'fan/tok/f025/'));
    }

    /**
     * A027 アンケート登録
     * @param null $id
     * @return Response|void|null
     * @throws Exception
     */
    public function a027($id = null) {
        // no caching
        header('Cache-Control: no cache');
        // get tokutabi and tokutabi_detail
        if (!empty($id) && is_numeric($id)) {
            // edit screen
            $tokutabi = $this->Tokutabi->getTokutabiById($id);
            if (empty($tokutabi)) {
                return $this->redirect(['controller' => 'Top', 'action' => 'error']);
            }
            // get tokutabi_detail
            $tokutabiDetail = $this->TokutabiDetail->getTokutabiDetail($id);
        } else {
            // register screen
            $tokutabi = $this->Tokutabi->newEntity();
            $tokutabiDetail = [];
        }
        // get mast_questionnaire_parts
        $mastQuestionnaireParts = $this->MastQuestionnaireParts->getDataMastQuestionnairePartsTokutabiDetail($id);
        // submit handling
        if ($this->getRequest()->is(['post', 'patch', 'put'])) {
            // get params
            $data = $this->getRequest()->getData();
            $params = $this->processDataOnA027($data, $id);
            // load component
            $queryComponent = $this->loadComponent('Query');
            //save tokutabi data
            $tokutabi = $queryComponent->saveTable('Tokutabi', $params, $id);
            // check tokutabi save
            if (is_bool($tokutabi)) {
                $this->set(compact('mastQuestionnaireParts', 'tokutabi', 'tokutabiDetail'));
                return $this->Flash->error(ConfigUtil::getMessage('CREATE_FAILURE'));
            }
            // save tokutabi error
            if (empty($tokutabi->getErrors())) {
                $this->set(compact('mastQuestionnaireParts', 'tokutabi', 'tokutabiDetail'));
                $this->Flash->success(ConfigUtil::getMessage('CREATE_SUCCESS'));
                return $this->redirect(['action' => 'a027', $tokutabi['id']]);
            }
            // show error
            $this->showErrors($tokutabi->getErrors());
            //set data to show start_time and end_time
            $this->set(compact('data'));
        }
        $this->set(compact('mastQuestionnaireParts', 'tokutabi', 'tokutabiDetail'));
    }

    /**
     * Preparing data for A027 screen
     * @param $params
     * @param null $id
     * @return mixed
     */
    private function processDataOnA027($params, $id = null)
    {
        $params['hash_url'] = null;
        $params['publish_flag'] = $params['publish_flag'];
        // if choose publish_flag = 限定公開
        if ($params['publish_flag'] === ValueUtil::get('sur.publish_flag_val')['limit_public']) {
            // if empty tokutabi
            if (is_null($id)) {
                //Calculate id value of new record
                $params['id'] = $this->Tokutabi->getLastIdBeforeInsert() + ValueUtil::get('common.increase_one');
                $id = $params['id'];
            }
            //Encrypt id
            $params['hash_url'] = EncryptUtil::encryptAes256($id);
        }
        // set params
        $params['del_flg'] =  ValueUtil::constToValue('common.deleted_flg.NOT_DELETED');
        $params['end_time'] = !empty($params['end_time']) ? $params['end_time'] : null;
        $params['start_time'] = !empty($params['start_time']) ? $params['start_time'] : null;
        $params['survey_type'] = ValueUtil::get('sur.survey_type_val')['question_survey'];
        return $params;
    }

    /**
     * A028 アンケート回答一覧
     * @param $tokutabi_id
     *
     * @return Response|null
     */
    public function a028($tokutabi_id) {
        // check tokutabi
        $tokutabi = $this->checkTokutabi($tokutabi_id, ValueUtil::constToValue('tok.survey_type_val.question_survey'));
        if (!$tokutabi) {
            return $this->redirect(['controller' => 'Top', 'action' => 'error']);
        }
        // Get session
        $session = $this->getRequest()->getSession();
        // Check searching data session
        $params = [];
        if ($session->check('Sur.a028')) {
            $params = $session->read('Sur.a028');
            $this->set([
                'searchData' => $params,
            ]);
        }
        // Process after submit form
        if ($this->getRequest()->is(['post'])) {
            $searchData = $this->getRequest()->getData();
            // Write session
            $session->delete('Sur.a028');
            $session->write('Sur.a028', $searchData);
            return $this->redirect(['action' => 'a028', $tokutabi_id]);
        }
        $result = $this->TokutabiResult->searchA028($params, $tokutabi_id);
        $tokutabis = $this->paginate($result, [
            'limit' => ConfigUtil::get('paginate.ten_pages'),
        ]);
        $this->set(compact(['tokutabis', 'tokutabi_id']));
    }

    /**
     * A028 アンケート回答一覧
     *
     * Update memo1, memo2, memo3 of table tokutabi_result
     */
    public function updatePopupA028() {
        // Process after submit
        if ($this->getRequest()->is(['post'])) {
            // Get data from popup form
            $data = $this->getRequest()->getData();
            // Get tokutabi_result id
            $id = $data['id'];
            // Get tokutbi_id
            $screen_id = $data['screen_id'];
            // Get tokutabi_memo
            $dataMemo['memo1'] = !empty($data['memo1']) ? $data['memo1'] : null;
            $dataMemo['memo2'] = !empty($data['memo2']) ? $data['memo2'] : null;
            $dataMemo['memo3'] = !empty($data['memo3']) ? $data['memo3'] : null;
            // Load component Query
            $this->loadComponent('Query');
            // Get table tokutabi_result
            $table = 'tokutabi_result';
            // Updated
            $result = $this->Query->saveTable($table, $dataMemo, $id);
            // Check when save data not success
            if(is_bool($result)) {
                return $this->Flash->error(ConfigUtil::getMessage('UPDATE_FAILURE'));
            }
            // Show validate error
            if(!empty($result->getErrors())) {
                $this->showErrors($result->getErrors());
            }
            return $this->redirect(['action' => 'a028', $screen_id]);
        }
    }

    /**
     * A028 アンケート回答一覧
     *
     * Export csv
     */
    public function exportCsv() {
        if ($this->getRequest()->is(['post'])) {
            // get params
            $params = $this->getRequest()->getData();
            // check params
            $params['birthday_from'] = isset($params['birthday_from_csv']) ? $params['birthday_from_csv'] : '';
            $params['birthday_to'] = isset($params['birthday_to_csv']) ? $params['birthday_to_csv'] : '';
            // Get records from database then paginate result
            $result = $this->TokutabiResult->searchA028($params, $params['tokutabiId'], true)->toArray();
            $header = ValueUtil::get('tok.header_csv');
            $headerResultDetail = ValueUtil::get('tok_result_detail.header_csv');
            //Set options value
            $options = [
                'input_type' => ValueUtil::get('tok.input_type')
            ];
            $listQuestResult = [];
            $listQuestResult[] = $header;
            // set name parameters follow header csv and check parameters
            foreach ($result as $value) {
                $arrData = [];
                $value['id_fan'] = isset($value['fan']['id']) ? $value['fan']['id'] : '';
                $value['user_name'] = isset($value['fan']['user_name']) ? $value['fan']['user_name'] : '';
                $value['email'] = isset($value['fan']['email']) ? $value['fan']['email'] : '';
                $value['tokutabi_result_id'] = isset($value['id']) ? $value['id'] : '';
                $value['tokutabi_id'] = isset($value['tokutabi_id']) ? $value['tokutabi_id'] : '';
                $value['created_by'] = isset($value['created_by']) ? $this->Staff->getStaffById($value['created_by'])['user_name'] : '';
                $value['created_at'] = isset($value['created_at']) ? DateUtil::getJapaneseDate($value['created_at'], false, true) : '';
                $value['updated_by'] = isset($value['updated_by']) ? $this->Staff->getStaffById($value['updated_by'])['user_name'] : '';
                $value['updated_at'] = isset($value['updated_at']) ? DateUtil::getJapaneseDate($value['updated_at'], false, true) : '';
                $value['deleted_by'] = isset($value['deleted_by']) ? $this->Staff->getStaffById($value['deleted_by'])['user_name'] : '';
                $value['deleted_at'] = isset($value['deleted_at']) ? DateUtil::getJapaneseDate($value['deleted_at'], false, true) : '';
                //add column name to csv
                foreach ($header as $colName => $colTitle) {
                    $arrData[$colName] = !empty($value[$colName]) ? $value[$colName] : '';
                }
                $tmpDataDetail = [];
                // check not empty
                if (!empty($value['tokutabi_result_detail'])) {
                    foreach ($value['tokutabi_result_detail'] as $key => $detail) {
                        // new array follow header csv and check parameters
                        $listDetail = [
                            'tokutabi_result_detail_id' => isset($detail['id']) ? $detail['id'] : '',
                            'tokutabi_detail_id' => isset($detail['tokutabi_detail_id']) ? $detail['tokutabi_detail_id'] : '',
                            'sort' => isset($detail['sort']) ? $detail['sort'] : '',
                            'label_name' => isset($detail['label_name']) ? $detail['label_name'] : '',
                            'input_type' => isset($detail['input_type']) && isset($options['input_type'][$detail['input_type']])
                                ? $options['input_type'][$detail['input_type']] : '',
                            'answer' => isset($detail['answer']) ? $detail['answer'] : '',
                        ];
                        //Set new array tokutabi_result_detail
                        array_push($tmpDataDetail, $listDetail);
                        $listQuestResult[0] = array_merge($listQuestResult[0], [
                            'tokutabi_result_detail_id' . $key => $headerResultDetail['tokutabi_result_detail_id'],
                            'tokutabi_detail_id' . $key => $headerResultDetail['tokutabi_detail_id'],
                            'sort' . $key => $headerResultDetail['sort'],
                            'label_name' . $key => $headerResultDetail['label_name'],
                            'input_type' . $key => $headerResultDetail['input_type'],
                            'answer' . $key => $headerResultDetail['answer'],
                        ]);
                    }
                }
                //Process add tokutabi_result_detail
                foreach ($tmpDataDetail as $key => $dataDetail) {
                    $arrData = array_merge($arrData, [
                        'tokutabi_result_detail_id' . $key => $dataDetail['tokutabi_result_detail_id'],
                        'tokutabi_detail_id' . $key => $dataDetail['tokutabi_detail_id'],
                        'sort' . $key => $dataDetail['sort'],
                        'label_name' . $key => $dataDetail['label_name'],
                        'input_type' . $key => $dataDetail['input_type'],
                        'answer' . $key => $dataDetail['answer'],
                    ]);
                }
                $listQuestResult[] = $arrData;
            }
            // Csv file name
            $fileName = 'A028_' . DateUtil::getFileNameByCurrentTime() . '.csv';
            // excecute export csv
            $exportData = new ExportDataUtil();
            // export csv
            $exportData->exportCSV($listQuestResult, $fileName);
        }
    }

    /**
     * A029 アンケート編集
     *
     * @param null $id
     * @return Response|void|null
     * @throws Exception
     */
    public function a029($id = null) {
        // no caching
        header('Cache-Control: no cache');
        // get tokutabi and tokutabi_detail
        $tokutabi = $this->checkTokutabi($id, ValueUtil::get('sur.survey_type_val')['question_survey']);
        if (!$tokutabi) {
            return $this->redirect(['controller' => 'Top', 'action' => 'error']);
        }
        // get tokutabi_detail
        $tokutabiDetail = $this->TokutabiDetail->getTokutabiDetail($id);
        // get mast_questionnaire_parts
        $mastQuestionnaireParts = $this->MastQuestionnaireParts->getDataMastQuestionnairePartsTokutabiDetail($id);
        // submit handling
        if ($this->getRequest()->is(['post', 'patch', 'put'])) {
            // get params
            $data = $this->getRequest()->getData();
            $params = $this->processDataOnA029($data, $id);
            // load component
            $queryComponent = $this->loadComponent('Query');
            //save tokutabi data
            $tokutabi = $queryComponent->saveTable('Tokutabi', $params, $id);
            // check tokutabi save
            if (is_bool($tokutabi)) {
                $this->set(compact('mastQuestionnaireParts', 'tokutabi', 'tokutabiDetail'));
                return $this->Flash->error(ConfigUtil::getMessage('UPDATE_FAILURE'));
            }
            // save tokutabi error
            if (empty($tokutabi->getErrors())) {
                $this->set(compact('mastQuestionnaireParts', 'tokutabi', 'tokutabiDetail'));
                $this->Flash->success(ConfigUtil::getMessage('UPDATE_SUCCESS'));
                return $this->redirect(['action' => 'a029', $tokutabi['id']]);
            }
            // show error
            $this->showErrors($tokutabi->getErrors());
            $this->set(compact('data'));
        }
        $this->set(compact('mastQuestionnaireParts', 'tokutabi', 'tokutabiDetail'));
    }

    /**
     * Preparing data for A029 screen
     *
     * @param $params
     * @param null $id
     * @return mixed
     */
    private function processDataOnA029($params, $id) {
        $results = [];
        $results['hash_url'] = null;
        // if choose publish_flag = 限定公開
        if ($params['publish_flag'] === ValueUtil::get('sur.publish_flag_val')['limit_public']) {
            if(is_null($id)) {
                //Calculate id value of new record
                $params['id'] = $this->Tokutabi->getLastIdBeforeInsert() + ValueUtil::get('common.increase_one');
                $id = $params['id'];
            }
            //Encrypt id
            $results['hash_url'] = EncryptUtil::encryptAes256($id);
        }
        // set params
        $results['end_time'] = !empty($params['end_time']) ? $params['end_time'] : null;
        $results['start_time'] = !empty($params['start_time']) ? $params['start_time'] : null;
        $results['title'] = $params['title'];
        $results['description'] = $params['description'];
        $results['publish_flag'] = $params['publish_flag'];
        return $results;
    }
}
