<?php
use Migrations\AbstractMigration;
use Phinx\Db\Adapter\MysqlAdapter;

class UpdateMasticketv3 extends AbstractMigration
{
    /**
     * Change Method.
     *
     * More information on this method is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-change-method
     * @return void
     */
    public function change()
    {
        try {
            $table = $this->table('mast_ticket');
            $table
                ->changeColumn('unit_price', 'integer', [
                    'default' => 0,
                    'limit' => MysqlAdapter::INT_BIG,
                    'null' => false
                ]);
            $table->save();
        } catch (\Exception $ex) {
            echo ($ex->getMessage());
        }
    }
}
