$(document).ready(function() {
});

/**
 * Load summernote editor
 * @param editorOptions
 * @param eventOptions
 */
function loadSummernoteEditor(elementById = null, formClass = null) {
    var summernoteElement = $('#' + elementById);
    // default features option
    var optionsDefault = {
        placeholder: null,
        tabsize: 2,
        height: 120,
        codemirror: 'default',
        callbacks: {
            onChange: function (contents, $editable) {
                if (checkMaxLength(contents) === 0) {
                    summernoteElement.val('');
                } else {
                    summernoteElement.val(contents);
                }
                $('.' + formClass).validate().element(summernoteElement);
            },
            onBlur: function (contents, $editable) {
                if (checkMaxLength($('#' + elementById).summernote('code')) === 0) {
                    summernoteElement.val('');
                } else {
                    summernoteElement.val($('#' + elementById).summernote('code'));
                }
                $('.' + formClass).validate().element(summernoteElement);
            }
        }
    };
    // initialize wysiwyg editor
    $('.summernote-editor').summernote(optionsDefault);
}
