<?php
use Migrations\AbstractMigration;

class UpdateOrder extends AbstractMigration
{
    /**
     * Change Method.
     *
     * More information on this method is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-change-method
     * @return void
     */
    public function change()
    {
        try {
            $table = $this->table('order');
            $table
                ->addColumn('fan_id', 'biginteger', [
                    'default' => NULL,
                    'null' => TRUE
                ])
                ->addForeignKey('fan_id', 'fan', 'id')
            ;
            $table->save();
        } catch (\Exception $ex) {
            echo ($ex->getMessage());
        }
    }
}
