$(document).ready(function () {
    //Copy url to clipboard
    $('.btn-copy').click(function () {
        //Create temp DOM with value and copy
        var $temp = $("<input>");
        $("body").append($temp);
        $temp.val($(this).data('hash-url')).select();
        document.execCommand("copy");
        $temp.remove();
    })
    $('.formA026').validate({
        focusInvalid: true,
        rules: {
            'tokutabi_date_create': {
                date: true
            }
        },
        messages: {
            'tokutabi_date_create': {
                date: $.validator.messages.date('作成日')
            }
        },
        submitHandler: function(form) {
            $('#submit-a026-btn').attr('disabled', true);
            form.submit();
        }
    });
});
