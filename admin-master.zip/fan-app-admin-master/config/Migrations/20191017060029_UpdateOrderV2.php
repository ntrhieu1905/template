<?php
use Migrations\AbstractMigration;

class UpdateOrderV2 extends AbstractMigration
{
    /**
     * Change Method.
     *
     * More information on this method is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-change-method
     * @return void
     */
    public function change()
    {
        try {
            $table = $this->table('order');
            $table
                ->changeColumn('tel', 'string', [
                    'default' => null,
                    'limit' => 13,
                    'null' => true,
                ])
                ->changeColumn('mobile', 'string', [
                    'default' => null,
                    'limit' => 13,
                    'null' => true,
                ])
                ->update();
        } catch (\Exception $ex) {
            echo ($ex->getMessage());
        }
    }
}
