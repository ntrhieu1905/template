<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;
use Cake\Database\Expression\QueryExpression;
use App\Libs\ValueUtil;
use App\Libs\ConfigUtil;

/**
 * Fan Model
 *
 * @property \App\Model\Table\CreditCustsTable&\Cake\ORM\Association\BelongsTo $CreditCusts
 * @property \App\Model\Table\CartItemsTable&\Cake\ORM\Association\HasMany $CartItems
 * @property \App\Model\Table\OrderItemsTable&\Cake\ORM\Association\HasMany $OrderItems
 * @property \App\Model\Table\QuestionnaireResultTable&\Cake\ORM\Association\HasMany $QuestionnaireResult
 *
 * @method \App\Model\Entity\Fan get($primaryKey, $options = [])
 * @method \App\Model\Entity\Fan newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Fan[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Fan|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Fan saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Fan patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Fan[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Fan findOrCreate($search, callable $callback = null, $options = [])
 */
class FanTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('fan');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');
        $this->belongsTo('CreatedStaff', [
            'className' => 'Staff',
            'foreignKey' => 'created_by',
        ]);
        $this->belongsTo('UpdatedStaff', [
            'className' => 'Staff',
            'foreignKey' => 'updated_by'
        ]);
        $this->belongsTo('DeletedStaff', [
            'className' => 'Staff',
            'foreignKey' => 'deleted_by'
        ]);
        $this->hasOne('Order', [
            'foreignKey' => 'fan_id'
        ]);
        //Add behavior
        $this->addBehavior('UpdateSync');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->allowEmptyString('id', null, 'create');

        $validator
            ->notEmptyString('user_name_first', ConfigUtil::getMessage("ECL001", ["氏名　姓"]))
            ->add('user_name_first', 'max-length', [
                'rule' => function ($value, $context) {
                    $len = mb_strlen($value);
                    if($len > 24) {
                        return ConfigUtil::getMessage("ECL002", ["氏名　姓", 24, $len]);
                    }
                    return true;
                }]);

        $validator
            ->notEmptyString('user_name_last', ConfigUtil::getMessage("ECL001", ["氏名　名"]))
            ->add('user_name_last', 'max-length', [
                'rule' => function ($value, $context) {
                    $len = mb_strlen($value);
                    if($len > 24) {
                        return ConfigUtil::getMessage("ECL002", ["氏名　名", 24, $len]);
                    }
                    return true;
                }]);

        $validator
            ->notEmptyString('user_kana_first', ConfigUtil::getMessage("ECL001", ["カナ　姓"]))
            ->add('user_kana_first', 'katakana2Byte',[
                'rule' => function ($value, $context){
                    $match = preg_match('/^[\x{30A0}-\x{30FF}\s]*$/u', $value);
                    if($match > 0){
                    } else {
                        return false;
                    }
                    return true;
                },
                'message' => ConfigUtil::getMessage("ECL009", ["カナ　姓"])
            ])
            ->add('user_kana_first', 'max-length', [
                'rule' => function ($value, $context) {
                    $len = mb_strlen($value);
                    if($len > 24) {
                        return ConfigUtil::getMessage("ECL002", ["カナ　姓", 24, $len]);
                    }
                    return true;
                }]);

        $validator
            ->notEmptyString('user_kana_last', ConfigUtil::getMessage("ECL001", ["カナ　名"]))
            ->add('user_kana_last', 'katakana2Byte',[
                'rule' => function ($value, $context){
                    $match = preg_match('/^[\x{30A0}-\x{30FF}\s]*$/u', $value);
                    if($match > 0){
                    } else {
                        return false;
                    }
                    return true;
                },
                'message' => ConfigUtil::getMessage("ECL009", ["カナ　名"])
            ])
            ->add('user_kana_last', 'max-length', [
                'rule' => function ($value, $context) {
                    $len = mb_strlen($value);
                    if($len > 24) {
                        return ConfigUtil::getMessage("ECL002", ["カナ　名", 24, $len]);
                    }
                    return true;
                }]);

        $validator
            ->notEmptyString('birthday', ConfigUtil::getMessage("ECL001", ["生年月日"]))
            ->add('birthday', 'date', [
                'rule' => ['date'],
                'message' => ConfigUtil::getMessage("ECL010", ['生年月日'])

            ]);

        $validator
            ->notEmptyString('sex', ConfigUtil::getMessage("ECL001", ["性別"]));

        $validator
            ->notEmptyString('email', ConfigUtil::getMessage("ECL001", ["メールアドレス"]))
            ->add('email', 'max-length', [
                'rule' => function ($value, $context) {
                    $len = mb_strlen($value);
                    if($len > 255) {
                        return ConfigUtil::getMessage("ECL002", ["メールアドレス", 255, $len]);
                    }
                    return true;
                }])
            ->add('email', 'mail-rule', [
                'rule' => 'email',
                'message' => ConfigUtil::getMessage("ECL007")]);

        $validator
            ->notEmptyString('password', ConfigUtil::getMessage("ECL001", ["パスワード"]))
            ->add('password', 'max-length', [
                'rule' => function ($value, $context) {
                    $len = mb_strlen($value);
                    if($len > 20) {
                        return ConfigUtil::getMessage("ECL002", ["パスワード", 20, $len]);
                    }
                    return true;
                }])
            ->add('password', 'min-length', [
                'rule' => function ($value, $context) {
                    $len = mb_strlen($value);
                    if($len < 10) {
                        return ConfigUtil::getMessage("ECL003", ["パスワード", 10, $len]);
                    }
                    return true;
                }])
            ->add('password', 'pass-rule', [
                'rule' => function ($value, $context) {
                    $regex_character = "/^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)[a-zA-Z\d]{9,21}$/";
                    preg_match($regex_character, $value, $match);
                    if(!$match) {
                        return ConfigUtil::getMessage("ECL050", ["パスワード"]);
                    }
                    return true;
                }]);

        $validator
            ->scalar('access_token')
            ->maxLength('access_token', 255)
            ->allowEmptyString('access_token');

        $validator
            ->dateTime('access_token_expire')
            ->allowEmptyDateTime('access_token_expire');

        $validator
            ->notEmptyString('zip', ConfigUtil::getMessage("ECL001", ["郵便番号"]))
            ->add('zip', 'number', [
                'rule' => function ($value, $context){
                    preg_match("/^[0-9]+$/", $value, $match);
                    if(!$match) {
                        return false;
                    }
                    return true;
                },
                'message' => ConfigUtil::getMessage("ECL004", ["郵便番号"])
            ])
            ->add('zip', 'max-length', [
                'rule' => function ($value, $context) {
                    $len = mb_strlen($value);
                    if($len > 7) {
                        return ConfigUtil::getMessage("ECL002", ["郵便番号", 7, $len]);
                    }
                    return true;
                }]);

        $validator
            ->notEmptyString('prefecture', ConfigUtil::getMessage("ECL001", ["都道府県"]));

        $validator
            ->notEmptyString('city', ConfigUtil::getMessage("ECL001", ["市区郡"]))
            ->add('city', 'max-length', [
                'rule' => function ($value, $context) {
                    $len = mb_strlen($value);
                    if($len > 50) {
                        return ConfigUtil::getMessage("ECL002", ["市区郡", 50, $len]);
                    }
                    return true;
                }]);

        $validator
            ->notEmptyString('address1', ConfigUtil::getMessage("ECL001", ["町名番地"]))
            ->add('address1', 'max-length', [
                'rule' => function ($value, $context) {
                    $len = mb_strlen($value);
                    if($len > 50) {
                        return ConfigUtil::getMessage("ECL002", ["町名番地", 50, $len]);
                    }
                    return true;
                }]);

        $validator
            ->allowEmptyString('address2')
            ->add('address2', 'max-length', [
                'rule' => function ($value, $context) {
                    $len = mb_strlen($value);
                    if($len > 50) {
                        return ConfigUtil::getMessage("ECL002", ["建物名", 50, $len]);
                    }
                    return true;
                }]);

        $validator
            ->scalar('sns_relation')
            ->maxLength('sns_relation', 50)
            ->allowEmptyString('sns_relation');

        $validator
            ->notEmptyString('job_type', ConfigUtil::getMessage("ECL001", ["職種"]));

        $validator
            ->allowEmptyString('job_type_other')
            ->add('job_type_other', 'max-length', [
                'rule' => function ($value, $context) {
                    $len = mb_strlen($value);
                    if($len > 50) {
                        return ConfigUtil::getMessage("ECL002", ["職種その他", 50, $len]);
                    }
                    return true;
                }]);

        $validator
            ->notEmptyString('working_type', ConfigUtil::getMessage("ECL001", ["勤務形態"]));

        $validator
            ->notEmptyString('marriage', ConfigUtil::getMessage("ECL001", ["あなたは結婚していますか?"]));

        $validator
            ->allowEmptyString('working_type_other')
            ->add('working_type_other', 'max-length', [
                'rule' => function ($value, $context) {
                    $len = mb_strlen($value);
                    if($len > 50) {
                        return ConfigUtil::getMessage("ECL002", ["勤務形態その他", 50, $len]);
                    }
                    return true;
                }]);

        $validator
            ->allowEmptyString('tel')
            ->add('tel', 'number', [
                'rule' => function ($value, $context){
                    preg_match("/^[0-9]+$/", $value, $match);
                    if(!$match) {
                        return false;
                    }
                    return true;
                },
                'message' => ConfigUtil::getMessage("ECL004", ["TEL"])
            ])
            ->add('tel', 'max-length', [
                'rule' => function ($value, $context) {
                    $len = mb_strlen($value);
                    if($len > 13) {
                        return ConfigUtil::getMessage("ECL002", ["TEL", 13, $len]);
                    }
                    return true;
                }]);

        $validator
            ->scalar('used_sns')
            ->maxLength('used_sns', 50)
            ->allowEmptyString('used_sns');

        $validator
            ->scalar('interest')
            ->maxLength('interest', 255)
            ->allowEmptyString('interest');

        $validator
            ->allowEmptyString('interest_other')
            ->add('interest_other', 'max-length', [
                'rule' => function ($value, $context) {
                    $len = mb_strlen($value);
                    if($len > 50) {
                        return ConfigUtil::getMessage("ECL002", ["興味その他", 50, $len]);
                    }
                    return true;
                }]);

        $validator
            ->scalar('read')
            ->maxLength('read', 100)
            ->allowEmptyString('read');

        $validator
            ->notEmptyString('working_area', ConfigUtil::getMessage("ECL001_1", ["勤務先エリア"]));

        $validator
            ->allowEmptyString('working_company')
            ->add('working_company', 'max-length', [
                'rule' => function ($value, $context) {
                    $len = mb_strlen($value);
                    if($len > 50) {
                        return ConfigUtil::getMessage("ECL002", ["勤務先(会社名)", 50, $len]);
                    }
                    return true;
                }]);

        $validator
            ->allowEmptyString('line_name')
            ->add('line_name', 'max-length', [
                'rule' => function ($value, $context) {
                    $len = mb_strlen($value);
                    if($len > 50) {
                        return ConfigUtil::getMessage("ECL002", ["LINEお名前", 50, $len]);
                    }
                    return true;
                }]);

        $validator
            ->notEmptyString('area', ConfigUtil::getMessage("ECL001", ["主な活動エリア"]));

        $validator
            ->notEmptyString('mobile', ConfigUtil::getMessage("ECL001", ["携帯番号"]))
            ->add('mobile', 'number', [
                'rule' => function ($value, $context){
                    preg_match("/^[0-9]+$/", $value, $match);
                    if(!$match) {
                        return false;
                    }
                    return true;
                },
                'message' => ConfigUtil::getMessage("ECL004", ["携帯番号"])
            ])
            ->add('mobile', 'max-length', [
                'rule' => function ($value, $context) {
                    $len = mb_strlen($value);
                    if($len > 13) {
                        return ConfigUtil::getMessage("ECL002", ["携帯番号", 13, $len]);
                    }
                    return true;
                }]);

        $validator
            ->scalar('bukatsu')
            ->maxLength('bukatsu', 100)
            ->allowEmptyString('bukatsu');

        $validator
            ->scalar('favorite_area')
            ->maxLength('favorite_area', 255)
            ->allowEmptyString('favorite_area');

        $validator
            ->allowEmptyString('bukatsu_free')
            ->add('bukatsu_free', 'max-length', [
                'rule' => function ($value, $context) {
                    $len = mb_strlen($value);
                    if($len > 255) {
                        return ConfigUtil::getMessage("ECL002", ["他にやってみたい部活や部活動をするならこんなことやってみたいなど、自由にご記入", 255, $len]);
                    }
                    return true;
                }]);

        $validator
            ->dateTime('last_login')
            ->allowEmptyDateTime('last_login');

        $validator
            ->scalar('auth_code')
            ->maxLength('auth_code', 10)
            ->allowEmptyString('auth_code');

        $validator
            ->allowEmptyString('payment_method');

        $validator
            ->notEmptyString('status');

        $validator
            ->notEmptyString('reg_route');

        $validator
            ->allowEmptyString('memo')
            ->add('memo', 'max-length', [
                'rule' => function ($value, $context) {
                    $len = mb_strlen($value);
                    if($len > 255) {
                        return ConfigUtil::getMessage("ECL002", ["備考", 255, $len]);
                    }
                    return true;
                }]);

        $validator
            ->allowEmptyString('company_code')
            ->add('company_code', 'max-length', [
                'rule' => function ($value, $context) {
                    $len = mb_strlen($value);
                    if($len > 50) {
                        return ConfigUtil::getMessage("ECL002", ["勤務先コード", 50, $len]);
                    }
                    return true;
                }]);

        $validator
            ->allowEmptyString('del_flg');

        $validator
            ->allowEmptyString('created_by');

        $validator
            ->dateTime('created_at')
            ->allowEmptyDateTime('created_at');

        $validator
            ->allowEmptyString('updated_by');

        $validator
            ->dateTime('updated_at')
            ->allowEmptyDateTime('updated_at');

        $validator
            ->allowEmptyString('deleted_by');

        $validator
            ->dateTime('deleted_at')
            ->allowEmptyDateTime('deleted_at');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
//        $rules->add($rules->isUnique(['email']));
        return $rules;
    }

    /**
     * Search by conditions
     *
     * @param array $params
     * @return Query
     */
    public function search($params) {
        $query = $this->find();
        // Get value del_flg field
        $delFlg = ValueUtil::get('common.del_flg_val');
        $delVal = isset($delFlg['undeleted']) ? $delFlg['undeleted'] : 0;
        $query->where([
            'Fan.del_flg' => $delVal,
            'Fan.deleted_at IS NULL',
        ]);
        //Get params
        $fan_id = isset($params['id']) ? $params['id'] : '';
        $user_kana = isset($params['user_kana']) ? $params['user_kana'] : '';
        $birthday_from = isset($params['birthday_from']) ? $params['birthday_from'] : '';
        $birthday_to = isset($params['birthday_to']) ? $params['birthday_to'] : '';
        $sex = isset($params['sex']) ? $params['sex'] : '';
        $email_address = isset($params['email_address']) ? $params['email_address'] : '';
        $area = isset($params['area']) ? $params['area'] : '';
        $sns_relation = isset($params['sns_relation']) ? $params['sns_relation'] : '';
        $tel = isset($params['tel_phone']) ? $params['tel_phone'] : '';
        $city = isset($params['city']) ? $params['city'] : '';
        $job_type = isset($params['job_type']) ? $params['job_type'] : '';
        $working_area = isset($params['working_area']) ? $params['working_area'] : '';
        $used_sns = isset($params['used_sns']) ? $params['used_sns'] : '';
        $interest = isset($params['interest']) ? $params['interest'] : '';
        $bukatsu_join = isset($params['bukatsu_join']) ? $params['bukatsu_join'] : '';
        $black_flg = isset($params['black_flg']) ? $params['black_flg'] : '';
        //search by ID
        if(strlen($fan_id) > 0){
            if(is_numeric($fan_id)){
                $query->andWhere(['Fan.id' => $fan_id]);
            } else {
                $query->andWhere(['Fan.id' => null]);
            }
        }
        //search by 氏名（カナ）
        if(strlen($user_kana) > 0){
            $query->andWhere(['Fan.user_kana LIKE'   => mb_convert_kana($user_kana, 'KVa').'%']);
        }
        //search by 生年月日
        $conditions_date = [];
        if(strlen($birthday_from) > 0){
            $conditions_date['AND'][] = [new QueryExpression("DATE_FORMAT(Fan.birthday, '%Y') >= '$birthday_from'")];
        }
        if(strlen($birthday_to) > 0){
            $conditions_date['AND'][] = [new QueryExpression("DATE_FORMAT(Fan.birthday, '%Y') <= '$birthday_to'")];
        }
        $query->andWhere($conditions_date);
        //search by 性別
        if(!empty($sex)){
            $query->andWhere(['Fan.sex IN' => $sex]);
        }
        //search by メールアドレス
        if(strlen($email_address) > 0){
            $query->andWhere(['Fan.email' => $email_address]);
        }
        //search by 活動エリア
        if(!empty($area)){
            $query->andWhere(['Fan.area IN' => $area]);
        }
        //search by ナッセ運営のSNS繋がり
        if(!empty($sns_relation)){
            $conditions_checkbox = [];
            foreach ($sns_relation as $value) {
                $conditions_checkbox['OR'][] = ['FIND_IN_SET('.$value.',Fan.sns_relation)'];
            }
            $query->andWhere($conditions_checkbox);
        }
        //search by TEL
        if(strlen($tel) > 0){
            $query->andWhere(['Fan.tel LIKE'   => '%'.mb_convert_kana($tel, 'KVa').'%']);
        }
        //search by 市区郡
        if(strlen($city) > 0){
            $query->andWhere(['Fan.city LIKE' => mb_convert_kana($city, 'KVa').'%']);
        }
        //search by 職種
        if(!empty($job_type)){
            $query->andWhere(['Fan.job_type IN' => $job_type]);
        }
        //search by 勤務先エリア
        if(!empty($working_area)){
            $query->andWhere(['Fan.working_area IN' => $working_area]);
        }
        //search by よく使っているSNS
        if(!empty($used_sns)){
            $conditions_checkbox = [];
            foreach ($used_sns as $value) {
                $conditions_checkbox['OR'][] = ['FIND_IN_SET('.$value.',Fan.used_sns)'];
            }
            $query->andWhere($conditions_checkbox);
        }
        //search by どんなことに興味ある？
        if(!empty($interest)){
            $conditions_checkbox = [];
            foreach ($interest as $value) {
                $conditions_checkbox['OR'][] = ['FIND_IN_SET('.$value.',Fan.interest)'];
            }
            $query->andWhere($conditions_checkbox);
        }
        //search by 部活に入りますか？
        if(!empty($bukatsu_join)){
            $query->andWhere(['Fan.bukatsu_join IN' => $bukatsu_join]);
        }
        //search by ブラックフラグ？
        if(!empty($black_flg)){
            $query->andWhere(['Fan.black_flg IN' => $black_flg]);
        }
        //contain
        $query->contain([
           'CreatedStaff' => [
               'fields' => [
                   'user_name'
               ]
           ],
            'UpdatedStaff' => [
                'fields' => [
                    'user_name'
                ]
            ],
            'DeletedStaff' => [
                'fields' => [
                    'user_name'
                ]
            ]
        ]);
        //sort follow id
        $query->order(['Fan.created_at' => 'DESC']);
        return $query;
    }

    /**
     * get data Fan
     *
     * @param $id
     * @return \App\Model\Entity\Fan|bool
     */
    public function getFanById($id = null) {
        try {
            // Get value del_flg field
            $delFlg = ValueUtil::get('common.del_flg_val');
            $delVal = isset($delFlg['undeleted']) ? $delFlg['undeleted'] : 0;
            $result = $this->find()
                ->where([
                    'id' => $id,
                    'del_flg' => $delVal,
                    'deleted_at IS NULL'
                ])->first();
            return $result;
        } catch (\Exception $e) {
            return null;
        }
    }

    /**
     * get data Fan
     *
     * @param $ids
     * @param $orderIdArr
     * @return \App\Model\Entity\Fan|bool
     */
    public function getFansByIds($ids = [], $orderIdArr = []) {
        try {
            // Get value del_flg field
            $delFlg = ValueUtil::get('common.del_flg_val');
            $delVal = isset($delFlg['undeleted']) ? $delFlg['undeleted'] : 0;
            $result = $this->find()
                ->where([
                    'Fan.id IN' => $ids,
                    'Fan.del_flg' => $delVal,
                    'Fan.deleted_at IS NULL'
                ]);
            if(!empty($orderIdArr)) {
                $result->contain([
                    'Order' => [
                        'fields' => [
                            'Order.id',
                            'Order.total_amount',
                            'Order.tax',
                            'Order.total_no_tax',
                        ],
                        'conditions' => [
                            'Order.id IN' => $orderIdArr,
                            'Order.del_flg' => $delVal,
                            'Order.deleted_at IS NULL'
                        ],
                    ]
                ]);
            }
            return $result->toArray();
        } catch (\Exception $e) {
            return null;
        }
    }
}
