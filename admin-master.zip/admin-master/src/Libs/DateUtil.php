<?php
/**
 * Created by PhpStorm.
 * User: dat.tnt
 * Date: 07/10/2019
 * Time: 10:12 AM
 */
namespace App\Libs;

class DateUtil
{
    /**
     * Validate date with format
     * @param $strDate
     * @param $format
     * @return bool
     */
    public static function isDateFormatValid($strDate, $format) {
        $dateObj = ValueUtil::strToDate($strDate, $format);
        if ($dateObj != null && ($dateObj instanceof \DateTime)) {
            return true;
        }
        return false;
    }

    /**
     * Validate a string with format
     * @param $dateStr
     * @param $format
     * @return bool
     */
    public static function validateDateTime($dateStr, $format = 'Y/m/d H:i:s')
    {
        $date = \DateTime::createFromFormat($format, $dateStr);
        return $date && ($date->format($format) === $dateStr);
    }

    /**
     * システム年月の次月含み、変更不可期間外の1か月後~3か月後をリスト値とする
     * ２０日以上次の月
     *
     * ex)	利用開始年月: 2017/08/01
     * 変更不可期間: 6カ月
     * システム年月: 2017年08月20日(0カ月)の場合	変更不可
     * システム年月: 2017年09月20日(1か月)の場合	変更不可
     * システム年月: 2017年10月20日(2か月)の場合	変更不可
     * システム年月: 2017年10月21日(3か月)の場合	「再々来月」をリスト値として表示
     * システム年月: 2017年11月20日(3か月)の場合	「再々来月」をリスト値として表示
     * システム年月: 2017年12月20日(4か月)の場合	「再来月」「再々来月」をリスト値として表示
     * システム年月: 2017年12月21日(5か月)の場合	「来月」「再来月」「再々来月」をリスト値として表示
     * システム年月: 2018年01月20日(5か月)の場合	「来月」「再来月」「再々来月」をリスト値として表示
     *
     * @param $startedDate \DateTime 利用開始年月: yyyy/mm/dd
     * @param $unChangeablePeriod int 変更不可期間: xxカ月
     * @param $oFormat
     * @return array
     */
    public static function getAvailableStartMonth($startedDate, $unChangeablePeriod, $oFormat = 'Y年n月') {
        if (!isset($startedDate) || !isset($unChangeablePeriod)) {
            return [];
        }
        $sysDate        = new \DateTime();
        $sysMonth       = $sysDate->format('n');        // 1..12
        $sysDay         = $sysDate->format('j');        // 1..31
        $statedMonth    = $startedDate->format('n');    // 1..12

        $endDate        = clone $startedDate;
        $endDate->add(new \DateInterval("P$unChangeablePeriod"."M"));
        $endMonth       = $statedMonth + $unChangeablePeriod;

        $availableList  = [];
        if ($sysDay > 20) {
            $sysMonth += 1; // treat as next month
        }

        $period = $endMonth - $sysMonth;
        if ($period > 0) {
            $nextOfEndDate = clone $endDate;
            if ($period <= 3) {
                $availableList[]    = $nextOfEndDate->format($oFormat);
            }
            if ($period <= 2) {
                $nextOfEndDate->add(new \DateInterval('P1M'));
                $availableList[]    = $nextOfEndDate->format($oFormat);
            }
            if ($period <= 1) {
                $nextOfEndDate->add(new \DateInterval('P1M'));
                $availableList[]    = $nextOfEndDate->format($oFormat);
            }
        } else {
            $nextOfEndDate          = clone $sysDate;
            $nextOfEndDate->add(new \DateInterval('P1M'));
            $availableList[]        = $nextOfEndDate->format($oFormat);
            $nextOfEndDate->add(new \DateInterval('P1M'));
            $availableList[]        = $nextOfEndDate->format($oFormat);
            $nextOfEndDate->add(new \DateInterval('P1M'));
            $availableList[]        = $nextOfEndDate->format($oFormat);
        }
        return $availableList;
    }

    /**
     * get timestamp
     * @return string
     */
    public static function getTimestamp() {
        $microtime = floatval(substr((string)microtime(), 1, 8));
        $rounded = round($microtime, 3);
        $milisecond = substr((string)$rounded, 2, strlen($rounded));
        return date("YmdHis") . $milisecond;
    }

    /**
     * check type datetime
     * @param $value
     * @return bool
     */
    public static function checkDateTime($value) {
        if (is_null($value)
            || DateUtil::validateDateTime($value, 'Y/m/d') || DateUtil::validateDateTime($value, 'Y/m/d H:m:s')) {
            return true;
        }
        return false;
    }

    /**
     * show Japanese date
     *
     * @param $dateObj
     * @param bool $hasTime
     * @param bool $hasSecond
     * @param bool $lineBreak
     * @return string
     */
    public static function getJapaneseDate($dateObj, $hasTime = false, $hasSecond = false, $lineBreak = false) {
        $result = '';
        if ($dateObj == '' || is_null($dateObj) || !is_object($dateObj)) {
            return $result;
        }
        try {
            if ($hasTime) {
                if ($lineBreak) {
                    $timeFormat = ($hasSecond) ? 'common.time_jp_format' : 'common.time_jp_format_notsecond';
                    $result = $dateObj->format(ValueUtil::get('common.date_jp_format')) . '<br/>' . $dateObj->format(ValueUtil::get($timeFormat));
                } else {
                    $result = $dateObj->format(ValueUtil::get('common.datetime_jp_format'));
                }
            } elseif ($hasSecond) {
                $result = $dateObj->format(ValueUtil::get('common.datetime_second_jp_format'));
            } else {
                $result = $dateObj->format(ValueUtil::get('common.date_jp_format'));
            }
            return $result;
        } catch (\Exception $e) {
            return $result;
        }
    }

    /**
     * get name file by current time
     *
     * @return string
     */
    public static function getFileNameByCurrentTime() {
        $utimestamp = microtime(true);
        $timestamp = floor($utimestamp);
        $milliseconds = round(($utimestamp - $timestamp) * 1000000);
        $targetfile = substr(date(preg_replace('`(?<!\\\\)u`', $milliseconds, 'YmdHis.u'), $timestamp), 0, -3);
        return $targetfile;
    }
}
