<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;
use Cake\Database\Expression\QueryExpression;
use App\Libs\ValueUtil;
use App\Libs\ConfigUtil;

/**
 * QuestionnaireResult Model
 *
 * @property \App\Model\Table\QuestionnaireTable&\Cake\ORM\Association\BelongsTo $Questionnaire
 * @property \App\Model\Table\FanTable&\Cake\ORM\Association\BelongsTo $Fan
 * @property \App\Model\Table\QuestionnaireResultDetailTable&\Cake\ORM\Association\HasMany $QuestionnaireResultDetail
 *
 * @method \App\Model\Entity\QuestionnaireResult get($primaryKey, $options = [])
 * @method \App\Model\Entity\QuestionnaireResult newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\QuestionnaireResult[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\QuestionnaireResult|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\QuestionnaireResult saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\QuestionnaireResult patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\QuestionnaireResult[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\QuestionnaireResult findOrCreate($search, callable $callback = null, $options = [])
 */
class QuestionnaireResultTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config) {
        parent::initialize($config);

        $this->setTable('questionnaire_result');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->belongsTo('Questionnaire', [
            'foreignKey' => 'questionnaire_id'
        ]);
        $this->belongsTo('Fan', [
            'foreignKey' => 'fan_id'
        ]);
        $this->hasMany('QuestionnaireResultDetail', [
            'foreignKey' => 'questionnaire_result_id'
        ]);

        $this->addBehavior('UpdateSync');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator) {
        $validator
            ->allowEmptyString('id', null, 'create');

        $validator
            ->allowEmptyString('payment_method');

        $validator
            ->integer('total_no_tax')
            ->allowEmptyString('total_no_tax');

        $validator
            ->integer('tax')
            ->allowEmptyString('tax');

        $validator
            ->integer('total_amount')
            ->allowEmptyString('total_amount');

        $validator
            ->scalar('credit_token')
            ->maxLength('credit_token', 255)
            ->allowEmptyString('credit_token');

        $validator
            ->allowEmptyString('winning_flg');

        $validator
            ->allowEmptyDate('receive_date')
            ->add('receive_date', 'date', [
                'rule' => 'date',
                'message' => ConfigUtil::getMessage("ECL010", ["入金日"])
            ]);

        $validator
            ->allowEmptyString('memo', ConfigUtil::getMessage("ECL001", ["メモ"]))
            ->add('memo', 'max-length', [
                'rule' => function ($value, $context) {
                    $len = mb_strlen($value);
                    if($len > 255) {
                        return ConfigUtil::getMessage("ECL002", ["メモ", 255, $len]);
                    }
                    return true;
                }
            ]);

        $validator
            ->notEmptyString('del_flg');

        $validator
            ->allowEmptyString('created_by');

        $validator
            ->dateTime('created_at')
            ->allowEmptyDateTime('created_at');

        $validator
            ->allowEmptyString('updated_by');

        $validator
            ->dateTime('updated_at')
            ->allowEmptyDateTime('updated_at');

        $validator
            ->allowEmptyString('deleted_by');

        $validator
            ->dateTime('deleted_at')
            ->allowEmptyDateTime('deleted_at');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['questionnaire_id'], 'Questionnaire'));
        $rules->add($rules->existsIn(['fan_id'], 'Fan'));

        return $rules;
    }

    /**
     * get data with conditions
     * @param null $id
     * @return array|\Cake\Datasource\EntityInterface|null
     */
    public function getByIdAndWinner($id = null)
    {
        try {
            $result = $this->find()
                ->where([
                    'questionnaire_id' => $id,
                    'winning_flg' => 1
                ])
                ->order(['created_at'  => 'DESC'])
                ->all();
            return $result;
        } catch (\Exception $ex) {
            return null;
        }
    }

    /**
     *  Search mast_ticket
     *
     * @param $params
     * @return Query
     */
    public function search($params, $questionnaireId) {
        $email = isset($params['email']) ? $params['email'] : '';
        $userKana = isset($params['user_kana']) ? $params['user_kana'] : '';
        $birthdayFrom = isset($params['birthday_from']) ? $params['birthday_from'] : '';
        $birthdayTo = isset($params['birthday_to']) ? $params['birthday_to'] : '';
        $sex = isset($params['sex']) ? $params['sex'] : '';
        $area = isset($params['area']) ? $params['area'] : '';
        $jobType = isset($params['job_type']) ? $params['job_type'] : '';
        //Just get records which not delete
        $delFlg = ValueUtil::get('common.del_flg_val');
        $delVal = isset($delFlg['undeleted']) ? $delFlg['undeleted'] : 0;
        $query = $this->find()
            ->where(['1=1'])
            ->contain(['Fan', 'Questionnaire', 'QuestionnaireResultDetail']);
        //Search by email
        if(!empty($email)){
            $query = $query->andWhere(['Fan.email LIKE' => $email.'%']);
        }
        //Search by user_kana
        if(!empty($userKana)){
            $query = $query->andWhere(['Fan.user_kana LIKE' => mb_convert_kana($userKana).'%']);
        }
        //Search by birthday
        $conditions_date = [];
        if(strlen($birthdayFrom) > 0){
            $conditions_date['AND'][] = [new QueryExpression("DATE_FORMAT(Fan.birthday, '%Y') >= '$birthdayFrom'")];
        }
        if(strlen($birthdayTo) > 0){
            $conditions_date['AND'][] = [new QueryExpression("DATE_FORMAT(Fan.birthday, '%Y') <= '$birthdayTo'")];
        }
        $query->andWhere($conditions_date);
        //Search by sex
        if(!empty($sex)){
            if(is_string($sex) && strpos($sex, ',') !== false){
                $sex = explode(',', $sex);
            }
            if(is_array($sex)){
                $query = $query->andWhere(['Fan.sex IN' => $sex]);
            } else {
                $query = $query->andWhere(['Fan.sex' => $sex]);
            }
        }
        //Search by area
        if(!empty($area)){
            if(is_string($area) && strpos($area, ',') !== false){
                $area = explode(',', $area);
            }
            if(is_array($area)){
                $query = $query->andWhere(['Fan.area IN' => $area]);
            } else {
                $query = $query->andWhere(['Fan.area' => $area]);
            }
        }
        //Search by job_type
        if(!empty($jobType)){
            if(is_string($jobType) && strpos($jobType, ',') !== false){
                $jobType = explode(',', $jobType);
            }
            if(is_array($jobType)){
                $query = $query->andWhere(['Fan.job_type IN' => $jobType]);
            } else {
                $query = $query->andWhere(['Fan.job_type' => $jobType]);
            }
        }
        $query = $query->andWhere([
            'QuestionnaireResult.questionnaire_id' => $questionnaireId,
            'QuestionnaireResult.del_flg' => $delVal,
            'QuestionnaireResult.deleted_at IS NULL',
            'Fan.del_flg' => $delVal,
            'Fan.deleted_at IS NULL',
        ])
            ->orderDesc('QuestionnaireResult.created_at');
        return $query;
    }
}
