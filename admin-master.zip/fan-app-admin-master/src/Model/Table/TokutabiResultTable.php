<?php
namespace App\Model\Table;

use App\Libs\ConfigUtil;
use App\Libs\ValueUtil;
use Aura\Intl\Exception;
use Cake\Database\Expression\QueryExpression;
use Cake\I18n\Date;
use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;
use function GuzzleHttp\Psr7\str;

/**
 * TokutabiResult Model
 *
 * @property \App\Model\Table\TokutabiTable&\Cake\ORM\Association\BelongsTo $Tokutabi
 * @property \App\Model\Table\FanTable&\Cake\ORM\Association\BelongsTo $Fan
 *
 * @method \App\Model\Entity\TokutabiResult get($primaryKey, $options = [])
 * @method \App\Model\Entity\TokutabiResult newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\TokutabiResult[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\TokutabiResult|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\TokutabiResult saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\TokutabiResult patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\TokutabiResult[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\TokutabiResult findOrCreate($search, callable $callback = null, $options = [])
 */
class TokutabiResultTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('tokutabi_result');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');
        $this->belongsTo('Tokutabi', [
            'foreignKey' => 'tokutabi_id',
        ]);
        $this->belongsTo('Fan', [
            'foreignKey' => 'fan_id',
            'joinType' => 'INNER',
        ]);
        $this->hasMany('TokutabiResultDetail', [
            'foreignKey' => 'tokutabi_result_id',
            'joinType' => 'INNER',
        ]);
        $this->addBehavior('UpdateSync');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->allowEmptyString('id', null, 'create');

        $validator
            ->scalar('memo1')
            ->allowEmptyString('memo1')
            ->add('memo1', 'max-length', [
                'rule' => function ($value, $context) {
                    $len = mb_strlen($value);
                    if($len > 255) {
                        return ConfigUtil::getMessage("ECL002", ["メモ1", 255, $len]);
                    }
                    return true;
                }
            ]);

        $validator
            ->scalar('memo2')
            ->allowEmptyString('memo2')
            ->add('memo2', 'max-length', [
                'rule' => function ($value, $context) {
                    $len = mb_strlen($value);
                    if($len > 255) {
                        return ConfigUtil::getMessage("ECL002", ["メモ2", 255, $len]);
                    }
                    return true;
                }
            ]);

        $validator
            ->scalar('memo3')
            ->allowEmptyString('memo3')
            ->add('memo3', 'max-length', [
                'rule' => function ($value, $context) {
                    $len = mb_strlen($value);
                    if($len > 255) {
                        return ConfigUtil::getMessage("ECL002", ["メモ3", 255, $len]);
                    }
                    return true;
                }
            ]);

        $validator
            ->allowEmptyString('created_by');

        $validator
            ->dateTime('created_at')
            ->allowEmptyDateTime('created_at');

        $validator
            ->allowEmptyString('updated_by');

        $validator
            ->dateTime('updated_at')
            ->allowEmptyDateTime('updated_at');

        $validator
            ->allowEmptyString('deleted_by');

        $validator
            ->dateTime('deleted_at')
            ->allowEmptyDateTime('deleted_at');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['tokutabi_id'], 'Tokutabi'));
        $rules->add($rules->existsIn(['fan_id'], 'Fan'));

        return $rules;
    }

    /**
     * search tokutabi result and export csv
     * @param array $params
     * @param null $tokutabiId
     * @param bool $isExportCsv
     * @return array|Query|null
     */
    public function search($params = [], $tokutabiId = null, $isExportCsv = false) {
        try {
            // check id tokutabi
            if (!is_numeric($tokutabiId)) {
                return null;
            }
            $query = $this->find()
                ->contain([
                    'Fan' => [
                        'conditions' => [
                            'Fan.del_flg' =>ValueUtil::constToValue('common.deleted_flg.NOT_DELETED'),
                            'Fan.deleted_at IS NULL'
                        ]
                    ]
                ]);
            // query when export csv
            if ($isExportCsv) {
                $query ->contain([
                    'TokutabiResultDetail' => [
                        'conditions' => [
                            'TokutabiResultDetail.deleted_at IS NULL',
                            'TokutabiResultDetail.del_flg' => ValueUtil::constToValue('common.deleted_flg.NOT_DELETED')
                        ],
                    ]
                ]);
            }
            $query->where(['TokutabiResult.deleted_at IS NULL'])
                  ->andWhere([ 'TokutabiResult.del_flg' => ValueUtil::constToValue('common.deleted_flg.NOT_DELETED')])
                  ->andWhere(['TokutabiResult.tokutabi_id' => $tokutabiId]);
            if (count($params) > 0) {
                // メールアドレス
                if (strlen($params['email']) > 0) {
                    $email = $params['email'] . '%';
                    $query->andWhere(['Fan.email LIKE ' => $email]);
                }
                // 氏名（カナ）
                if (strlen($params['name_kana']) > 0) {
                    $nameKana = $params['name_kana'] . '%';
                    $query->andWhere(['Fan.user_kana LIKE ' => $nameKana]);
                }
                // 生年月日 from
                if (!empty($params['birthday_from'])) {
                    $query->andWhere("DATE_FORMAT(Fan.birthday, '%Y') >='" . $params['birthday_from']."'");
                }
                // 生年月日 to
                if (!empty($params['birthday_to'])) {
                    $query->andWhere("DATE_FORMAT(Fan.birthday, '%Y') <='" . $params['birthday_to']."'");
                }
                // 性別
                if (!empty($params['sex'])) {
                    $query->andWhere(['Fan.sex IN ' => $params['sex']]);
                }
                // 活動エリア
                if (!empty($params['area_activity'])) {
                    $query->andWhere(['Fan.area IN ' => $params['area_activity']]);
                }
                // 職種
                if (!empty($params['type_job'])) {
                    $query->andWhere(['Fan.job_type IN ' => $params['type_job']]);
                }
            }
            $query->order([
                'TokutabiResult.created_at DESC'
            ]);
            return $query;
        } catch (\Exception $e) {
            return null;
        }
    }

    /**
     * Search by conditions for a028 and export file csv
     *
     * @param array $params, $tokutabi_id
     * @return Query
     */
    public function searchA028($params = [], $tokutabi_id = null, $isExportCsv = false) {
        // Get params
        $email = isset($params['email_address']) ? $params['email_address'] : '';
        $user_kana = isset($params['user_kana']) ? $params['user_kana'] : '';
        $birthday_from = isset($params['birthday_from']) ? $params['birthday_from'] : '';
        $birthday_to = isset($params['birthday_to']) ? $params['birthday_to'] : '';
        $sex = isset($params['sex']) ? $params['sex'] : '';
        $area = isset($params['area']) ? $params['area'] : '';
        $job_type = isset($params['job_type']) ? $params['job_type'] : '';
        // Get record from database
        $query = $this->find('all')->contain(['Fan']);
        // Process when export csv file
        if($isExportCsv) {
            $query->contain([
                'TokutabiResultDetail' => [
                    'conditions' => [
                        'TokutabiResultDetail.deleted_at IS NULL',
                        'TokutabiResultDetail.del_flg' => ValueUtil::constToValue('common.deleted_flg.NOT_DELETED')
                    ],
                ]
            ]);
        }
        $query->where(['TokutabiResult.deleted_at IS NULL'])
            ->andWhere(['TokutabiResult.del_flg' => ValueUtil::constToValue('common.deleted_flg.NOT_DELETED')])
            ->andWhere(['Fan.del_flg' =>ValueUtil::constToValue('common.deleted_flg.NOT_DELETED')])
            ->andWhere(['Fan.deleted_at IS NULL'])
            ->andWhere(['TokutabiResult.tokutabi_id' => $tokutabi_id]);
        // Search by メールアドレス
        if(strlen($email) > 0) {
            $query->andWhere(['Fan.email LIKE' => $email.'%']);
        }
        // Search by 氏名（カナ）
        if(strlen($user_kana) > 0) {
            $query->andWhere(['Fan.user_kana LIKE' => $user_kana.'%']);
        }
        // 生年月日 from
        if (!empty($birthday_from)) {
            $query->andWhere("DATE_FORMAT(Fan.birthday, '%Y') >='" . $birthday_from . "'");
        }
        // 生年月日 to
        if (!empty($birthday_to)) {
            $query->andWhere("DATE_FORMAT(Fan.birthday, '%Y') <='" . $birthday_to . "'");
        }
        // Search by 性別
        if(!empty($sex)) {
            $query->andWhere(['Fan.sex IN' => $sex]);
        }
        // Search by 活動エリア
        if(!empty($area)) {
            $query->andWhere(['Fan.area IN' => $area]);
        }
        // Search by 職種
        if(!empty($job_type)) {
            $query->andWhere(['Fan.job_type IN' => $job_type]);
        }
        // Sort by created_at desc
        $query->order([
            'TokutabiResult.created_at DESC'
        ]);
        return $query;
    }
}
