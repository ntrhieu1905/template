$(document).ready(function() {
    const MAX_FILE_SIZE = 10;
    const ALLOWED_EXT = ['jpg', 'jpeg', 'png', 'cad', 'pdf', 'xls', 'xlsx'];
    var fileMimeType = '';
    var droppedFiles = false;
    //Drag and drop event
    $('.form-drag')
        .on('drag dragover dragend dragstart dragleave dragenter drop', function(e) {
            //Preventing the unwanted behaviours
            e.preventDefault();
            e.stopPropagation();
        })
        .on('dragenter dragover', function() {
            $('.form-drag').addClass('is-dragover');
        })
        .on('dragend dragleave drop', function() {
            $('.form-drag').removeClass('is-dragover');
        })
        .on('drop', function(e) {
            //The files that were dropped
            droppedFiles = e.originalEvent.dataTransfer.files;
            //Show/hide fields
            $('#csv_file_name').text(droppedFiles[0].name);

            $('#error-mess').text('');
            $('.message.success').hide();
            //Validate on drag & drop
            //screen rep01
            if($("#hidden_file_name").length > 0){
                fileMimeType = '';
                $('#error-mess').text('');
                file_validation_rep01();
                $("#hidden_file_name").val(droppedFiles[0].name);
                $('#hidden_file_name-error').remove();
            }else{
                file_validation();
            }
        });

    //On submit event
    $('.form-drag').on('submit', function (e) {
        e.preventDefault();
        //Create hide form data
        var ajaxData = new FormData();
        //Validate file
        if(file_validation()){

            //Disable submit button on process
            $("#btn-submit").attr('disabled', true);
            //Insert dropped file to hide form
            $.each(droppedFiles, function(i, file) {
                ajaxData.append('file', file);
            });
            //Send file using ajax
            $.ajax({
                url: $(this).attr('action'),
                type: $(this).attr('method'),
                data: ajaxData,
                dataType: 'json',
                cache: false,
                contentType: false,
                processData: false,
                success: function(data) {
                    if(data.success){
                        location.reload();
                    } else {
                        //Show error messages
                        $.each(data.errorMsg, function(index, value){
                            $("#error-mess").append(value + '<br><br>');
                        });
                        //Reset upload input
                        droppedFiles = false;
                        $('#csv_file_name').text('');
                        $("#btn-submit").attr('disabled', false);
                    }
                },
            });
        } else {
            e.preventDefault();

            return false;
        }
    });
    //Rep-01 form
    $('.form-rep-drag').on('submit', function (e) {
        e.preventDefault();
        //Disable submit button on process
        $("#btnRep01").attr('disabled', true);
        if(!$(".rep").valid()){
            $("#btnRep01").attr('disabled', false);
            return false;
        }
        //Create hide form data
        var ajaxData = new FormData();
        //Validate file
        if($('#image').hasClass('hide')
            || (!droppedFiles && $('.form-rep-drag').hasClass('not-required'))){//target = 2
            ajaxData.append('target', $('#target').val());
            ajaxData.append('type', $('#type').val());
            if(!$('#add_info1').hasClass('disabled')){
                ajaxData.append('addinfo1', $('#add_info1').val());
            }
            ajaxData.append('file', '');
            $.ajax({
                url: $(this).attr('action'),
                type: $(this).attr('method'),
                data: ajaxData,
                dataType: 'json',
                cache: false,
                contentType: false,
                processData: false,
                success: function(data) {
                    if(data.success){
                        window.location.href = data.redirect;
                    } else {
                        if(data.redirect){
                            window.location = data.redirect;
                        } else {
                            location.reload();
                        }
                    }
                },
            });
        } else if(file_validation_rep01()) {//target = 1, 3
            //Insert dropped file to hide form
            $.each(droppedFiles, function(i, file) {
                ajaxData.append('file', file);
            });
            ajaxData.append('target', $('#target').val());
            ajaxData.append('type', $('#type').val());
            //Send file using ajax
            $.ajax({
                url: $(this).attr('action'),
                type: $(this).attr('method'),
                data: ajaxData,
                dataType: 'json',
                cache: false,
                contentType: false,
                processData: false,
                beforeSend: function() {
                    $("#uploading_img").show();
                    $("#upload_label").hide();
                },
                success: function(data) {
                    $("#uploading_img").hide();
                    $("#upload_label").show();
                    if(data.success){
                        window.location.href = data.redirect;
                    } else {
                        if(data.redirect){
                            window.location = data.redirect;
                        } else {
                            location.reload();
                        }
                    }
                },
            });
        } else {
            e.preventDefault();
            $("#btnRep01").attr('disabled', false);
            return false;
        }
    });

    //Button submit outside of the form
    $('#btn-submit').click(function() {
        $('#error-mess').text('');
        $('.form-drag').submit();
    });

    //Validate upload file
    function file_validation() {
        //Get validate message from PHP: messages.filerequired, messages.filetype, messages.filesize
        var messages = $('#file-validate-mess').data();
        //Check file required
        if(!droppedFiles || droppedFiles.length == 0){
            $('#error-mess').text(messages.filerequired);

            return false;
        }
        //Check file extension
        if(!droppedFiles[0].name.match(new RegExp("\\.(csv)$", "i"))){
            $('#error-mess').text(messages.filetype.replace('<0>', 'CSV'));

            return false;
        }
        //Check file max size
        if(droppedFiles[0].size > MAX_FILE_SIZE*1024*1024){
            $('#error-mess').text(messages.filesize.replace('<0>', MAX_FILE_SIZE + 'MB'));

            return false;
        }

        return true;
    }
    //Validate upload file on screen rep01
    function file_validation_rep01() {
        //Get validate message from PHP: messages.filerequired, messages.filetype, messages.filesize
        var messages = $('#file-validate-mess').data();
        //Check file required
        if((!droppedFiles || droppedFiles.length == 0)){
            $('#error-mess').text(messages.filerequired);
            return false;
        }
        var validImageTypes = ["image/jpg", "image/jpeg", "image/png", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/pdf", "application/octet-stream"];
        var arrName = droppedFiles[0].name.split(".");
        var lowerType = arrName.slice(-1)[0].toLowerCase();

        if (($.inArray(droppedFiles[0].type, validImageTypes) < 0) && lowerType != "jww" && lowerType != "dxf" && lowerType != "xls") {
            $('#error-mess').text(messages.filetype.replace('<0>', ALLOWED_EXT.join(', ')));
            return false;
        }

        //Validate Binary file type
        if(!fileMimeType){
            //Get binary file type from dropped file
            getBinaryFileType(droppedFiles[0], function(fileType) {
                fileMimeType = fileType;
            });
            //Wait until getBinaryFileType complete
            setTimeout(file_validation_rep01, 10);
            return false;
        }
        if(lowerType == 'pdf'){
            if(lowerType == 'pdf' && fileMimeType !== 'application/pdf'){
                $('#error-mess').text(messages.filetype.replace('<0>', ALLOWED_EXT.join(', ')));
                return false;
            }
        }
        if(lowerType == 'jpg' || lowerType == 'jpeg' || lowerType == 'png'){
            let imgType = ["image/jpg", "image/jpeg", "image/png"];
            if($.inArray(fileMimeType, imgType) < 0){
                $('#error-mess').text(messages.filetype.replace('<0>', ALLOWED_EXT.join(', ')));
                return false;
            }
        }
        if(lowerType == 'jww' || lowerType == 'dxf'){
            let cadType = ["jww", "dxf"];
            if($.inArray(fileMimeType, cadType) < 0){
                $('#error-mess').text(messages.filetype.replace('<0>', ALLOWED_EXT.join(', ')));
                return false;
            }
        }
        if(lowerType == "xls" || lowerType == "xlsx"){
            if(fileMimeType !== 'office'){
                $('#error-mess').text(messages.filetype.replace('<0>', ALLOWED_EXT.join(', ')));
                return false;
            }
        }

        //Check file max size
        if(droppedFiles[0].size > MAX_FILE_SIZE*1024*1024){
            $('#error-mess').text(messages.filesize.replace('<0>', MAX_FILE_SIZE + 'MB'));
            return false;
        }

        //check file cad.
        if(lowerType == "jww" || lowerType == "dxf"){
            $("#file_type").val("application/octet-stream");
        }else{
            $("#file_type").val(droppedFiles[0].type);
        }
        $("#file_extension").val(lowerType);
        return true;
    }


    $("#btnRep01").click(function (e) {
        if($('#csv_file_name').html().length > 0 && $('#error-mess').html().length > 0){
            if(!file_validation_rep01()){
                e.preventDefault();
                return false;
            }
        }
    });

});

