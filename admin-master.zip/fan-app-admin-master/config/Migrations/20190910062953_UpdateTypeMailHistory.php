<?php
use Migrations\AbstractMigration;

class UpdateTypeMailHistory extends AbstractMigration
{
    /**
     * Change Method.
     *
     * More information on this method is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-change-method
     * @return void
     */
    public function change()
    {
        try {
            $table = $this->table('mail_history');
            $table->removeColumn('mail_template')
                ->addColumn('mail_template', 'string', [
                    'default' => null,
                    'after' => 'subject',
                    'null' => true,
                    'limit' => 100,
                ])->save();
        } catch (\Exception $ex) {
            echo ($ex->getMessage());
        }
    }
}
