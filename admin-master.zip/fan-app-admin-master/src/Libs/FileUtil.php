<?php
/**
 * Created by PhpStorm.
 * User: dat.tnt
 * Date: 07/10/2019
 * Time: 10:12 AM
 */
namespace App\Libs;

use Cake\Log\Log;

class FileUtil
{
    public  static function checkRemoteFile($url)
    {
        if(!getimagesize($url)){
            return false;
        }
        return true;
    }

    /**
     * To check if remote file is exist
     *
     * @param $url
     * @return bool
     */
    public static function isFileExist($url) {
        $ch = null;
        try {
            $ch = curl_init($url);

            curl_setopt($ch, CURLOPT_NOBODY, true);
            curl_exec($ch);
            $type = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
            if (strpos($type, 'image') !== false || strpos($type, 'pdf') !== false) {
                return true;
            } else {
                return false;
            }
        } catch (\Exception $e) {
            return false;
        } finally {
            if(isset($ch)) {
                curl_close($ch);
            }
        }
    }

    /**
     * To check if remote file is exist
     *
     * @param $url
     * @return bool
     */
    public static function isRemoteFileExist($url) {
        $ch = null;
        try {
            $ch = curl_init($url);

            curl_setopt($ch, CURLOPT_NOBODY, true);
            curl_exec($ch);
            $retCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            if ($retCode != 200) {
                return false;
            } else {
                return true;
            }
        } catch (\Exception $e) {
            return false;
        } finally {
            if(isset($ch)) {
                curl_close($ch);
            }
        }
    }

    public static function writeCSV($url, $content) {
        $file = false;
        try {
            $file = fopen($url, "w");
            if ($file) {
                fwrite($file, $content);
            }
        } catch (\Exception $e) {
            Log::error("writeCSV: ".$e->getMessage());
        } finally {
            if ($file) {
                fclose($file);
            }
        }
    }

    /**
     * Get CSV path that created from batch
     *
     * @param string|int $jobType
     * @param string $fileName
     * @return string|bool
     */
    public static function getCsvPath($jobType, $fileName) {
        try{
            //Format job_type to 0 + number. Ex: 01
            $jobType = str_pad($jobType, 2, '0', STR_PAD_LEFT);
            //Get Year and Month from file_name
            $number = preg_replace('/[^0-9]/', '', $fileName);
            $date = substr($number, 0, 8);
            $date = \DateTime::createFromFormat("!Ymd", $date);
            //File path from job_type, year, month, file_name.
            $filePath = '/' . $jobType . '/' . $date->format('Y/m') . '/' . $fileName;
            //Return file path
            return ConfigUtil::get('CSV_BASE_URL') . $filePath;
        } catch(\Error $e) {
            return false;
        } catch(\Exception $e) {
            return false;
        }
    }
    
    /**
     * Get Excel file path
     *
     * @param string $fileName
     * @return string|bool
     */
    public static function getExcelPath($fileName) {
        try{
            //Get Year and Month from file_name
            $number = preg_replace('/[^0-9]/', '', $fileName);
            $fileDate = substr($number, 0, 8);
            $date = \DateTime::createFromFormat("!Ymd", $fileDate);
            //File path from job_type, year, month, file_name.
            $filePath = '/' . $date->format('Y/m') . '/' . $fileName;
            //Return file path
            return ConfigUtil::get('EXCEL_BASE_URL') . $filePath;
        } catch(\Error $e) {
            return false;
        } catch(\Exception $e) {
            return false;
        }
    }

    /**
     * clone other server 2 this server
     * @param $transaction
     * @param $filePath
     * @return string
     */
    public static function cloneOtherSever2ThisSever($transaction, $filePath) {

        if (empty($filePath)) return '';

        $sourceSever = ConfigUtil::get('source_sever');
        $fileName = $transaction. DS. basename($filePath);

        $ch = curl_init($sourceSever. '/'. $filePath);
        $fp = fopen($fileName, 'wb');
        curl_setopt($ch, CURLOPT_FILE, $fp);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_exec($ch);
        curl_close($ch);
        fclose($fp);

        return $fileName;
    }

    /**
     * @param $fileName
     * @param array $header
     * @return array
     */
    public static function readCSV($fileName, $header = []) {
        $handle = fopen($fileName, "r");

        $fp = tmpfile();
        fwrite($fp, file_get_contents($fileName));
        rewind($fp);

        $result = [];

        @ini_set('memory_limit', '4096M');
        while ($data_file = fgetcsv($fp)) {
            if (!is_array($data_file)) continue;

            foreach ($data_file as $k => $df) {
                mb_convert_encoding($data_file[$k], "SJIS", 'UTF-8, SJIS, SJIS-WIN');
            }
            $info = array_combine($header, $data_file);
            $result[] = $info;
        }

        fclose($handle);
        $titles = array_shift($result);
        return [
            'titles' => $titles,
            'rows' => $result
        ];
    }

    /**
     * export csv
     * @param $header
     * @param $data
     * @param $fileName
     * @param $filePath
     * @return bool
     */
    public static function exportCSV($header, $data, $fileName, $filePath) {
        try {
            array_unshift($data, $header);
            $rowCnt = 0;
            $contents = null;
            // loop over the rows, outputting them
            foreach($data as $index => $rowData){
                foreach($rowData as $prop => &$row){
                    if($index > 0){
                        $row = preg_replace('/"/','""', $row);

                        if (isset($header[$prop]['doublequote']) && $header[$prop]['doublequote'] == 1) {
                            $row = '"' . $row . '"';
                        }
                    } else {
                        $row = $row['header'];
                    }
                }
                //Add line break
                if($rowCnt > 0){
                    $contents .= "\n";
                }

                $contents .= implode(',', $rowData);
                $rowCnt++;
            }

            $filePath = ConfigUtil::get('BATCH_CSV_DIR'). DS. $filePath. DS;
            //Check file exist
            if(!file_exists($filePath)){
                mkdir($filePath, 0777, true);
            }
            //Set file content
            $fullPatchName = $filePath. $fileName;
            $handle = fopen($fullPatchName, 'w+');
            fwrite($handle, $contents);
            fclose($handle);
            file_put_contents($fullPatchName, $contents);

            Log::info("作成したCSV: ". $fullPatchName);
            return $fullPatchName;
        } catch (\Exception $e) {
            return false;
        }
    }
}