<?php
use Migrations\AbstractMigration;

class UpdateQuestionnaire extends AbstractMigration
{
    /**
     * Change Method.
     *
     * More information on this method is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-change-method
     * @return void
     */
    public function change()
    {
        try {
            $table = $this->table('questionnaire');
            $table
                ->changeColumn('start_time', 'datetime', [
                    'null' => true
                ])
                ->changeColumn('end_time', 'datetime', [
                    'null' => true
                ])
                ->changeColumn('payment_flag', 'integer', [
                    'null' => true
                ])
                ->changeColumn('payment_method', 'integer', [
                    'null' => true
                ])
                ->changeColumn('total_no_tax', 'integer', [
                    'null' => true
                ])
                ->changeColumn('tax', 'integer', [
                    'null' => true
                ])
                ->changeColumn('total_amount', 'integer', [
                    'null' => true
                ])
                ->save();
        } catch (\Exception $ex) {
            echo ($ex->getMessage());
        }
    }
}
