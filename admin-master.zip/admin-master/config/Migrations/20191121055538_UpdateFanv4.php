<?php
use Migrations\AbstractMigration;
use Phinx\Db\Adapter\MysqlAdapter;

class UpdateFanv4 extends AbstractMigration
{
    /**
     * Change Method.
     *
     * More information on this method is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-change-method
     * @return void
     */
    public function change()
    {
        try {
            $table = $this->table('fan');
            $table
                ->addColumn('marriage', 'integer', [
                    'default' => NULL,
                    'limit' => MysqlAdapter::INT_SMALL,
                    'null' => TRUE,
                    'after' => 'bukatsu_free'
                ])
                ->save();
        } catch (\Exception $ex) {
            echo ($ex->getMessage());
        }
    }
}
