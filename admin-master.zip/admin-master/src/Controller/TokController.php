<?php
/**
 * Created by PhpStorm.
 * User: vuong.nm
 * Date: 2020/03/23
 * Time: 17:31
 */
namespace App\Controller;

use App\Libs\ConfigUtil;
use App\Libs\DateUtil;
use App\Libs\EncryptUtil;
use App\Libs\ExportDataUtil;
use App\Libs\ValueUtil;
use Cake\Event\Event;
use Cake\Log\Log;
use Cake\ORM\TableRegistry;

/**
 * Tokutabi content controller
 */
class TokController extends AppAdminController
{

    Const MAX_LENGTH_LABEL_NAME = 255;

    /**
     * Override beforeFilter callback
     *
     * @return \Cake\Network\Response|null|void
     */
    public function beforeFilter(Event $event) {
        parent::beforeFilter($event);
        //Load common model
        $this->loadModel('tokutabi');
        $this->loadModel('TokutabiResult');
        $this->loadModel('TokutabiDetail');
        $this->loadModel('TokutabiResultDetail');
    }

    /**
     * A021 とく旅一覧
     * @return \Cake\Http\Response|null
     */
    public function a021() {
        //Get login user data
        $session = $this->getRequest()->getSession();
        //Check searching data session
        $params = [];
        if ($session->check('Tok.a021')) {
            //When have session
            $params = $session->read('Tok.a021');
            $this->set([
                'searchData' => $params,
            ]);
        }
        //Process after submit
        if ($this->getRequest()->is(['post'])) {
            $searchData = $this->getRequest()->getData();
            //Write session
            $session->delete('Tok.a021');
            $session->write('Tok.a021', $searchData);
            //Reload page
            return $this->redirect(['action' => 'a021']);
        }
        //Get records from database then paginate result
        $result = $this->Tokutabi->search($params);
        $tokutabis = $this->paginate($result, ['limit' => ConfigUtil::get('paginate.ten_pages')]);
        //Show list evaluation
        $this->set(compact('tokutabis'));
        $this->set('_serialize', ['tokutabis']);
    }

    /**
     * A022 とく旅登録
     *
     * @param null $id
     * @return \Cake\Http\Response|void|null
     * @throws \Exception
     */
    public function a022($id = null) {
        // no caching
        header('Cache-Control: no cache');
        // handler error and get data
        if (!empty($id) && !is_numeric($id)) {
            return $this->redirect(['controller' => 'Top', 'action' => 'error']);
        } else if (!empty($id) && is_numeric($id)) {
            // edit screen
            $mastQuestionnaireParts = $this->MastQuestionnaireParts->getDataMastQuestionnairePartsTokutabiDetail($id);
            $tokutabi = $this->Tokutabi->getTokutabiById($id);
            if (empty($tokutabi)) {
                return $this->redirect(['controller' => 'Top', 'action' => 'error']);
            }
            $tokutabiDetail = $this->TokutabiDetail->getTokutabiDetail($id);
        } else {
            // register screen
            $tokutabi = $this->Tokutabi->newEntity();
            $tokutabiDetail = [];
        }
        // submit handling
        if ($this->getRequest()->is(['post', 'patch', 'put'])) {
            // get params
            $data = $this->getRequest()->getData();
            $params = $this->processDataOnA022($data, $id);
            // load component
            $queryComponent = $this->loadComponent('Query');
            //save tokutabi data
            $tokutabi = $queryComponent->saveTable('Tokutabi', $params, $id);
            // check tokutabi save
            if (is_bool($tokutabi)) {
                $this->set(compact('mastQuestionnaireParts', 'tokutabi', 'tokutabiDetail'));
                return $this->Flash->error(ConfigUtil::getMessage('CREATE_FAILURE'));
            }
            // save tokutabi error
            if (empty($tokutabi->getErrors())) {
                $this->set(compact('mastQuestionnaireParts', 'tokutabi', 'tokutabiDetail'));
                $this->Flash->success(ConfigUtil::getMessage('CREATE_SUCCESS'));
                return $this->redirect(['action' => 'a022', $tokutabi->id]);
            }
            // show error
            $this->showErrors($tokutabi->getErrors());
            $this->set(compact('data'));
        }
        $this->set(compact('mastQuestionnaireParts', 'tokutabi', 'tokutabiDetail'));
    }

    /**
     * process data before display on a022 screen and on a024 screen
     */
    private function processDataOnA022($params, $id = null)
    {
        // set params
        $params['end_time'] = !empty($params['end_time']) ? $params['end_time'] : null;
        $params['del_flg'] =  ValueUtil::constToValue('common.deleted_flg.NOT_DELETED');
        $params['start_time'] = !empty($params['start_time']) ? $params['start_time'] : null;
        $params['survey_type'] = ValueUtil::get('tok.survey_type');
        $params['publish_flag'] = !is_null($params['publish_flag']) ? $params['publish_flag'] : null;
        return $params;
    }

    /**
     *  A023 とく旅回答一覧
     */
    public function a023($tokutabiId = null) {
        // check id tokutabi and get tokutabi
        $tokutabi = $this->checkTokutabi($tokutabiId, ValueUtil::constToValue('tok.survey_type_val.special_survey'));
        if (!$tokutabi) {
            return $this->redirect(['controller' => 'Top', 'action' => 'error']);
        }
        //Get login user data
        $session = $this->getRequest()->getSession();
        //Check searching data session
        $params = [];
        if ($session->check('Tok.a023')) {
            //When have session
            $params = $session->read('Tok.a023');
            $this->set([
                'searchData' => $params,
            ]);
        }
        //Process after submit
        if ($this->getRequest()->is(['post'])) {
            $searchData = $this->getRequest()->getData();
            //Write session
            $session->delete('Tok.a023');
            $session->write('Tok.a023', $searchData);
            //Reload page
            return $this->redirect(['action' => 'a023', $tokutabi['id']]);
        }
        //Get records from database then paginate result
        $result = $this->TokutabiResult->search($params, $tokutabi['id']);
        $tokutabiResults = $this->paginate($result, ['limit' => ConfigUtil::get('paginate.ten_pages')]);
        //Show list evaluation
        $this->set(compact('tokutabiResults', 'tokutabiId'));
        $this->set('_serialize', ['tokutabiResults']);
    }

    /**
     * A024 とく旅編集
     */
    public function a024($tokutabiId = null) {
        // no caching
        header('Cache-Control: no cache');
        // check id tokutabi and get tokutabi
        $tokutabi = $this->checkTokutabi($tokutabiId, ValueUtil::constToValue('tok.survey_type_val.special_survey'));
        // id tokutabi false
        if (!$tokutabi) {
            return $this->redirect(['controller' => 'Top', 'action' => 'error']);
        }
        // get tokutabi_detail
        $tokutabiDetail = $this->TokutabiDetail->getTokutabiDetail($tokutabiId);
        // get mast_questionnaire_parts
        $mastQuestionnaireParts = $this->MastQuestionnaireParts->getDataMastQuestionnairePartsTokutabiDetail($tokutabiId);
        // submit handling
        if ($this->getRequest()->is(['post', 'patch', 'put'])) {
            // get params
            $data = $this->getRequest()->getData();
            $params = $this->processDataOnA022($data, $tokutabiId);
            // load component
            $queryComponent = $this->loadComponent('Query');
            //save tokutabi data
            $tokutabi = $queryComponent->saveTable('Tokutabi', $params, $tokutabiId);
            // check tokutabi save
            if (is_bool($tokutabi)) {
                $this->set(compact('mastQuestionnaireParts', 'tokutabi', 'tokutabiDetail'));
                return $this->Flash->error(ConfigUtil::getMessage('UPDATE_FAILURE'));
            }
            // save tokutabi error
            if (empty($tokutabi->getErrors())) {
                $this->set(compact('mastQuestionnaireParts', 'tokutabi', 'tokutabiDetail'));
                $this->Flash->success(ConfigUtil::getMessage('UPDATE_SUCCESS'));
                return $this->redirect(['action' => 'a024', $tokutabi->id]);
            }
            // show error
            $this->showErrors($tokutabi->getErrors());
            $this->set(compact('data'));
        }
        $this->set(compact('mastQuestionnaireParts', 'tokutabi', 'tokutabiDetail'));
    }

    /**
     * Update tokutabi_result.momo1 and tokutabi_result.momo2 and tokutabi_result.momo3
     *
     * @return \Cake\Http\Response|null
     * @throws \Exception
     */
    public function updatePopupA023() {
        if ($this->getRequest()->is(['post'])) {
            // get params
            $data = $this->getRequest()->getData();
            // check params
            $id = $data['id'];
            $data['memo1'] = !empty($data['memo1']) ? $data['memo1'] : null;
            $data['memo2'] = !empty($data['memo2']) ? $data['memo2'] : null;
            $data['memo3'] = !empty($data['memo3']) ? $data['memo3'] : null;
            // load Component
            $this->loadComponent('Query');
            // name table
            $tokutabiResultTable = 'tokutabi_result';
            // Updated
            $tokutabiResult = $this->Query->saveTable($tokutabiResultTable, $data, $id);
            if (is_bool($tokutabiResult)) {
                return $this->Flash->error(ConfigUtil::getMessage('UPDATE_FAILURE'));
            }
            //Show validate errors
            if (!empty($tokutabiResult->getErrors())) {
                $this->showErrors($tokutabiResult->getErrors());
            }
            return $this->redirect(['action' => 'a023', $tokutabiResult['tokutabi_id']]);
        }
    }

    /**
     * export Csv
     */
    public function exportCsv() {
        if ($this->getRequest()->is(['post'])) {
            // get params
            $params = $this->getRequest()->getData();
            // check params
            $params['birthday_from'] = isset($params['birthday_from_csv']) ? $params['birthday_from_csv'] : '';
            $params['birthday_to'] = isset($params['birthday_to_csv']) ? $params['birthday_to_csv'] : '';
            // Get records from database then paginate result
            $result = $this->TokutabiResult->search($params, $params['tokutabiId'], true)->toArray();
            // get header
            $header = ValueUtil::get('tok.header_csv');
            $headerResultDetail = ValueUtil::get('tok_result_detail.header_csv');
            //Set options value
            $options = [
                'input_type' => ValueUtil::get('tok.input_type')
            ];
            $listQuestResult = [];
            $listQuestResult[] = $header;
            // set name parameters follow header csv and check parameters
            foreach ($result as $value) {
                $arrData = [];
                $value['id_fan'] = isset($value['fan']['id']) ? $value['fan']['id'] : '';
                $value['user_name'] = isset($value['fan']['user_name']) ? $value['fan']['user_name'] : '';
                $value['email'] = isset($value['fan']['email']) ? $value['fan']['email'] : '';
                $value['tokutabi_result_id'] = isset($value['id']) ? $value['id'] : '';
                $value['tokutabi_id'] = isset($value['tokutabi_id']) ? $value['tokutabi_id'] : '';
                $value['created_by'] = isset($value['created_by']) ? $this->Staff->getStaffById($value['created_by'])['user_name'] : '';
                $value['created_at'] = isset($value['created_at']) ? DateUtil::getJapaneseDate($value['created_at'], false, true) : '';
                $value['updated_by'] = isset($value['updated_by']) ? $this->Staff->getStaffById($value['updated_by'])['user_name'] : '';
                $value['updated_at'] = isset($value['updated_at']) ? DateUtil::getJapaneseDate($value['updated_at'], false, true) : '';
                $value['deleted_by'] = isset($value['deleted_by']) ? $this->Staff->getStaffById($value['deleted_by'])['user_name'] : '';
                $value['deleted_at'] = isset($value['deleted_at']) ? DateUtil::getJapaneseDate($value['deleted_at'], false, true) : '';
                //add column name to csv
                foreach ($header as $colName => $colTitle) {
                    $arrData[$colName] = !empty($value[$colName]) ? $value[$colName] : '';
                }
                $tmpDataDetail = [];
                // check !empty
                if (!empty($value['tokutabi_result_detail'])) {
                    foreach($value['tokutabi_result_detail'] as $key => $detail) {
                        // new array follow header csv and check parameters
                        $listDetail = [
                            'tokutabi_result_detail_id' => isset($detail['id']) ? $detail['id'] : '',
                            'tokutabi_detail_id' => isset($detail['tokutabi_detail_id']) ? $detail['tokutabi_detail_id'] : '',
                            'sort' => isset($detail['sort']) ? $detail['sort'] : '',
                            'label_name' => isset($detail['label_name']) ? $detail['label_name'] : '',
                            'input_type' => isset($detail['input_type']) && isset($options['input_type'][$detail['input_type']]) ? $options['input_type'][$detail['input_type']] : '',
                            'answer' => isset($detail['answer']) ? $detail['answer'] : ''
                        ];
                        //Set new array tokutabi_result_detail
                        array_push($tmpDataDetail, $listDetail);
                        $listQuestResult[0] = array_merge($listQuestResult[0], [
                            'tokutabi_result_detail_id'.$key => $headerResultDetail['tokutabi_result_detail_id'],
                            'tokutabi_detail_id'.$key => $headerResultDetail['tokutabi_detail_id'],
                            'sort'.$key => $headerResultDetail['sort'],
                            'label_name'.$key => $headerResultDetail['label_name'],
                            'input_type'.$key => $headerResultDetail['input_type'],
                            'answer'.$key => $headerResultDetail['answer'],
                        ]);
                    }
                }
                //Process add questionnaire_result_detail
                foreach($tmpDataDetail as $key => $dataDetail) {
                    $arrData = array_merge($arrData, [
                        'tokutabi_result_detail_id'.$key => $dataDetail['tokutabi_result_detail_id'],
                        'tokutabi_detail_id'.$key => $dataDetail['tokutabi_detail_id'],
                        'sort'.$key => $dataDetail['sort'],
                        'label_name'.$key => $dataDetail['label_name'],
                        'input_type'.$key => $dataDetail['input_type'],
                        'answer'.$key => $dataDetail['answer'],
                    ]);
                }
                $listQuestResult[] = $arrData;
            }
            // Csv file name
            $fileName = 'A023_'. DateUtil::getFileNameByCurrentTime() . '.csv';
            // excecute export csv
            $exportData = new ExportDataUtil();
            // export csv
            $exportData->exportCSV($listQuestResult, $fileName);
        }
    }

    /**
     *
     * A022 and A024 イベント編集 - 追加ボタン
     */
    public function createTokutabiDetail($tokutabiId) {
        if ($this->getRequest()->is(['post'])) {
            try {
                // get data
                $data = $this->getRequest()->getData();
                $mastQuestionnaireId = $data['mastQuestionnairePartsId'];
                // get tokutabi by id
                $tokutabi = $this->Tokutabi->getTokutabiById($tokutabiId);
                // get mast_questionnaire by id
                $mastQuestionnaireParts = $this->MastQuestionnaireParts->getMastQuestionnairePartsById($mastQuestionnaireId);
                // check id exists
                if (empty($tokutabi) || empty($mastQuestionnaireParts)) {
                    $this->returnForAjax('error', 'create');
                }
                // check tokutabi.publish_flag = 1:public
                if ($tokutabi->publish_flag == ValueUtil::get('tok.publish_flag_val')['public']) {
                    $this->returnForAjax('error', 'create');
                }
                // check label maxlength
                if (mb_strlen($data['labelName']) > self::MAX_LENGTH_LABEL_NAME) {
                    $this->returnForAjax('error', 'create',
                        ConfigUtil::getMessage('ECL002', [
                            'ラベル名',
                            self::MAX_LENGTH_LABEL_NAME, mb_strlen($data['labelName'])
                        ]));
                }
                // check only one record for input_type from 1 -> 9
                if (in_array($mastQuestionnaireParts->input_type, ValueUtil::get('tok.ONLY_ONE'))) {
                    $countQuestionnaireDetail = $this->TokutabiDetail->countTokutabiDetailByType($tokutabiId, $mastQuestionnaireParts->input_type);
                    if ($countQuestionnaireDetail > 0) {
                        $this->returnForAjax('error', 'create', ConfigUtil::getMessage('ONLY_ONE_RECORD'));
                    }
                }
                // save tokutabi detail
                $params = $this->processDataOnCreateTokutabiDetail($data, $mastQuestionnaireParts, $tokutabi);
                // load component
                $queryComponent = $this->loadComponent('Query');
                // save tokutabi detail
                $tokutabiDetail = $queryComponent->saveTable('TokutabiDetail', $params, null);
                $tokutabiDetail['label_name'] = is_null($tokutabiDetail['label_name']) ? '' : $tokutabiDetail['label_name'];
                if(empty($tokutabiDetail->getErrors())) {
                    // not error
                    $this->returnForAjax('success', 'create', '', $tokutabiDetail);
                }
            } catch (\Exception $e) {
                $this->returnForAjax('error', 'create');
            }
        }
        $this->returnForAjax('error', 'create');
    }

    /**
     * A022 and A024 イベント登録 - 削除ボタン
     */
    public function deleteTokutabiDetail() {
        if ($this->getRequest()->is(['post'])) {
            try {
                // get data
                $data = $this->getRequest()->getData();
                // count id in tokutabi_detail_result
                $getCountByTokutabiDetail = $this->TokutabiResultDetail->getCountByTokutabiResultDetail($data['id']);
                // if tokutabi_result_detail table has least one data, return error message ECL056
                if ($getCountByTokutabiDetail > 0) {
                    $this->returnForAjax('error', 'delete', ConfigUtil::getMessage('ECL056'));
                }
                // get TokutabiDetail
                $tokutabiDetail = $this->TokutabiDetail->getTokutabiDetailByConds($data['id']);
                // add data and send data to screen
                $data = [
                    'mast_questionnaire_id' => $tokutabiDetail['mast_questionnaire_parts_id'],
                    'input_type' => $tokutabiDetail['input_type']
                ];
                // delete tokutabi detail
                if ($this->TokutabiDetail->delete($tokutabiDetail)) {
                    $this->returnForAjax('success', 'delete', '', $data);
                }
            } catch (\Exception $e) {
                $this->returnForAjax('error', 'delete');
            }
        }
        $this->returnForAjax('error', 'delete');
    }

    /**
     * update sort for tokutabi detail screen a022 and a024
     * @return [type] [description]
     */
    public function updateSortTokutabiDetail() {
        try {
            if ($this->getRequest()->is(['post'])) {
                // get params
                $data = $this->getRequest()->getData();
                $tokutabiDetails = $data['detail'];
                // upload column sort TokutabiDetail
                $result = $this->TokutabiDetail->updateArrayTokutabiDetails($tokutabiDetails);
                // if update false
                if ($result) {
                    // update successful
                    $this->returnForAjax('success', 'update');
                }
                // show error
                $this->returnForAjax('error', 'update');
            }
        } catch (\Exception $e) {
            // error rollack transaction
            $this->connection->rollback();
            $this->returnForAjax('error', 'update');
        }
    }

    /**
     * process data on CreateQuestionnaireDetail function
     * @param $params
     * @param $mastQuestionnaireParts
     * @param $tokutabi
     * @return mixed
     */
    private function processDataOnCreateTokutabiDetail($params, $mastQuestionnaireParts, $tokutabi) {
        // 必須フラグ
        $mandatoryFlg = ValueUtil::get('common.is_false');
        // check required
        if ($params['required'] == 'required') {
            $mandatoryFlg = ValueUtil::get('common.is_true');
        }
        // tokutabi_detail.input_format
        $inputFormat = $mastQuestionnaireParts['input_format'];
        if (!empty($params['options'])) {
            // convert data
            $inputFormatObj = json_decode($mastQuestionnaireParts['input_format'], true);
            $inputFormatObj['options'] = explode(',', $params['options']);
            $inputFormat = json_encode($inputFormatObj);
        }
        // get sort value
        $sort = $this->TokutabiDetail->getMaxSortTokutabiDetail($tokutabi['id']);
        // format value
        $params['tokutabi_id']                 = $tokutabi['id'];
        $params['mast_questionnaire_parts_id'] = $mastQuestionnaireParts['id'];
        $params['input_type']                  = $mastQuestionnaireParts['input_type'];
        $params['sort']                        = (int) $sort['maxSort'] + ValueUtil::get('common.increase_one');
        if (in_array($mastQuestionnaireParts->input_type, ValueUtil::get('tok.ONLY_ONE'))) {
            $params['label_name']              = $mastQuestionnaireParts['label_name'];
        } else {
            $params['label_name']              = $params['labelName'];
        }
        $params['label_name'] = ($params['label_name'] == '') ? null : $params['label_name'];
        $params['input_format']                = $inputFormat;
        $params['mandatory_flag']              = $mandatoryFlg;
        $params['del_flg']                     = ValueUtil::get('common.del_flg_val')['undeleted'];
        return $params;
    }
}
