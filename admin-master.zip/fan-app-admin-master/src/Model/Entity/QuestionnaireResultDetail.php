<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * QuestionnaireResultDetail Entity
 *
 * @property int $id
 * @property int $questionnaire_result_id
 * @property int $questionnaire_detail_id
 * @property int|null $sort
 * @property string|null $label_name
 * @property int $input_type
 * @property string|null $answer
 * @property int $del_flg
 * @property int|null $created_by
 * @property \Cake\I18n\FrozenTime|null $created_at
 * @property int|null $updated_by
 * @property \Cake\I18n\FrozenTime|null $updated_at
 * @property int|null $deleted_by
 * @property \Cake\I18n\FrozenTime|null $deleted_at
 *
 * @property \App\Model\Entity\QuestionnaireResult $questionnaire_result
 * @property \App\Model\Entity\QuestionnaireDetail $questionnaire_detail
 */
class QuestionnaireResultDetail extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'questionnaire_result_id' => true,
        'questionnaire_detail_id' => true,
        'sort' => true,
        'label_name' => true,
        'input_type' => true,
        'answer' => true,
        'del_flg' => true,
        'created_by' => true,
        'created_at' => true,
        'updated_by' => true,
        'updated_at' => true,
        'deleted_by' => true,
        'deleted_at' => true,
        'questionnaire_result' => true,
        'questionnaire_detail' => true
    ];
}
