<?php
/**
 * Created by PhpStorm.
 * User: leminhtoan
 * Date: 3/13/17
 * Time: 18:47
 */

namespace App\View\Helper;

use App\Libs\ConfigUtil;
use App\Libs\ValueUtil;
use Cake\View\Helper;
use App\Libs\FileUtil;

class ContentViewHelper extends Helper
{
    /**
     * Convert array to text
     *
     * @param string $text
     * @return bool|string
     * @author sonPH
     */
    public function trimArray($text) {
        $arr_text = explode('<br />', $text);
        $result = array_map('trim', $arr_text);
        $text = implode(PHP_EOL, $result);
        return $text;
    }

    /**
     * Get PDF file
     *
     * @param string $pdf_file
     * @param array $options
     * @return bool|string
     * @author sonPH
     */
    public function getPdfUpload($pdf_file, $options = []) {
        if(!empty($pdf_file)){
            $exists = file_exists('/var/www/html' . $pdf_file);
            if($exists){
                $download = '?download=false';
                if(!empty($options['download'])){
                    $download = '?download=true';
                }
                //Return PDF file
                return ConfigUtil::get('API_FILE_URL') . '/' . base64_encode(ltrim($pdf_file. $download, '/'));
            }
        }

        return false;
    }

    /**
     * Check and get temporary image
     *
     * @param $tmpImg
     * @return string|null
     */
    public function getTmpImg($tmpImg) {
        $image = ConfigUtil::get('API_IMAGE_URL_TMP') . $tmpImg;
        if(empty($image)){
            $image = '';
        }
        return $image;
    }

    /**
     * Get file name from a path
     *
     * @param $filePath
     * @return string|null
     */
    public function getNameFromPath($filePath) {
        if(trim($filePath) == ''){
            return '';
        }
        //Process a path and return file name
        $splitPath = explode('/', $filePath);
        $fileName = end($splitPath);
        return $fileName;
    }

    /**
     * Convert from value into text in view
     *
     * @param $value property value Ex: 1
     * @param $listKey list defined in yml Ex: web.type
     * @return null|string text if exists else blank
     * @author sonPH
     */
    public function valueToText($value, $listKey) {
        //Check params
        if(!isset($value) || !isset($listKey)){
            return NULL;
        }
        //Get list options
        $list = ValueUtil::get($listKey);
        if (empty($list)) {
            $list = ValueUtil::getList($listKey);
        }
        if(is_array($list) && isset($list[$value])){
            return h($list[$value]);
        }
        //Can't get value
        return NULL;
    }

    /**
     * Get value for option
     *
     * @param $key
     * @return $result
     */
    public function getArrayValue($key) {
        //Check params
        if(empty($key)){
            return [];
        }
        //Get list options to array
        $result = ValueUtil::getArrayValue($key);
        return $result;
    }

    /**
     * Get list constant values
     *
     * @param $key
     * @return array|null
     */
    public function getList($key) {
        if (empty($key)) {
            return [];
        }
        $result = ValueUtil::getList($key);
        return $result;
    }

    /**
     * Get value from const (in Yml config file)
     * @param $key
     * @return int|null|string
     */
    public function constToValue($key) {
        return ConfigUtil::getValue($key);
    }

    /**
     * Get value by option
     *
     * @param $key
     * @return array|null
     */
    public function getValueByOption($key) {
        if(empty($key)) {
            return [];
        }
        $result = ValueUtil::get($key);
        return $result;
    }

    /**
     * @param $obj
     * @param $keys
     * @param null $default
     * @return null
     */
    public function fetchObject($obj, $keys, $default = NULL) {
        $keyArr = explode(':', $keys);

        foreach ($keyArr as $keyName) {
            if (!isset($obj->{$keyName})) {
                return $default;
            }
            $obj = $obj->{$keyName};
        }

        return $obj;
    }

    /**
     * @param $array
     * @param $keys
     * @param null $default
     * @return null
     */
    public function fetchArray($array, $keys, $default = NULL) {
        $keyArr = explode(':', $keys);

        foreach ($keyArr as $keyVal) {
            if (!isset($array[$keyVal])) {
                return $default;
            }

            $array = $array[$keyVal];
        }

        return $array;
    }

    /**
     * Get real image
     *
     * @param $filePath ex: ﻿/xxx/xxx/20180405151902Jh1Cmi6qGl.png
     * @return string dumped image or default image path
     * @author sonPH
     * @update tuanDA
     */
    public function getImage($filePath) {
        $image = ConfigUtil::get('API_IMAGE_URL') . $filePath;
        if(empty($image)){
            $image = '';
        }
        return $image;
    }

    /**
     * Get temp image
     *
     * @param string $type for compatible only, don't use
     * @param string $filePath ex: ﻿201804181140006Hur80f7y4.png
     * @return string: dumped image or default image path
     * @author sonPH
     * @update tuanDA
     */
    public function getTmpImage($type = '', $filePath) {
        $image = ConfigUtil::get('API_IMAGE_URL_TMP') . $filePath;
        if(empty($image)){
            $image = '';
        }
        return $image;
    }

    /**
     * Get ordering field and ordering type for data table
     *
     * @param string $columnName
     * @param array $params
     * @return string
     * @author sonPH
     * @since 2018/06/04
     */
    public function getSort($columnName = '', $params = []) {
        $orderBy    = $params['order_by'];
        $orderType  = $params['order_type'];
        return $orderBy == $columnName? ($orderType == 'DESC'? 'desc': 'asc'): 'sorting';
    }

    /**
     * Get CSV path that created from batch
     *
     * @param string|int $jobType
     * @param string $fileName
     * @return bool|string
     */
    public function getCsvPath($jobType, $fileName) {
        return FileUtil::getCsvPath($jobType, $fileName);
    }

    /**
     * Get Excel path to download
     *
     * @param string $fileName
     * @return bool|string
     */
    public function getExcelPath($fileName) {
        return FileUtil::getExcelPath($fileName);
    }

    /**
     * Get message from message_file, params is optional
     *
     * @param string $key
     * @param array $paramArray
     * @return mixed|null
     */
    public function getMessage($key, $paramArray = []) {
        return ConfigUtil::getMessage($key, $paramArray);
    }

    /**
     * Process a text, sanitize line feed \n
     *
     * @param string $text
     * @return string|null
     */
    public function autoText($text) {
        if(empty($text)){
          return "";
        }
        return nl2br(h($text));
    }

    /**
     * Process a date, sanitize line feed \n
     *
     * @param string|object $date
     * @param string $format
     * @return string|object|null
     */
    public function autoDate($date, $format = 'YYYY/MM/dd') {
        //Process when date is empty
        if(empty($date)){
            return "";
        }
        //Process when date is not empty
        if(is_object($date)){
            return h($date->i18nFormat($format));
        } else {
            $originalDate = h($date);
            $newDate = date("Y/m/d", strtotime($originalDate));
            return $newDate;
        }
    }

    /**
     * Format date
     *
     * @param string $date
     * @return string
     */
    public function convertDate($date) {
        if(empty($date)){
            return '';
        }
        //Convert Y-m-d to Y/m/d
        if(strpos($date, '-') !== false){
            $date = str_replace('-', '/', $date);
            return h($date);
        }
        //Convert Y/m/d to Y-m-d
        if(strpos($date, '/') !== false){
            $date = str_replace('/', '-', $date);
            return h($date);
        }
    }

    /**
     * Convert time object to string
     * @param $data
     * @param string $format
     * @return null
     * @author sonPH
     */
    public function formatDateTime($data, $format = 'Y/m/d') {
        if (empty($data) || is_null($data)) {
            return null;
        }
        return $data->format($format);
    }

    /**
     * Format String (YYYY/MM) to Date.YearMonth
     * Ex: 201906 to 2019/06
     *
     * @param $str
     * @return string
     */
    public function formatStringToDate($str) {
        return ValueUtil::formatStringToDate($str);
    }
}
