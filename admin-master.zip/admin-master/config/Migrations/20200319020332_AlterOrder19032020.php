<?php
use Migrations\AbstractMigration;
use Phinx\Db\Adapter\MysqlAdapter;

class AlterOrder19032020 extends AbstractMigration
{
    /**
     * Change Method.
     *
     * More information on this method is available here:
     * https://book.cakephp.org/phinx/0/en/migrations.html#the-change-method
     * @return void
     */
    public function change()
    {
        $table = $this->table('order');
        $table
            ->addColumn('questionnaire_id', 'biginteger', [
                'default' => null,
                'null'    => true,
                'after' => 'id'
            ])
            ->addColumn('winning_flg', 'integer', [
                'default' => null,
                'null' => true,
                'limit' => MysqlAdapter::INT_TINY,
                'after' => 'credit_token',
            ])
            ->addForeignKey('questionnaire_id', 'questionnaire', 'id')
            ->update();
    }
}
