/*
function checkSubmit () {
    var term_of_service = $("input[name='term_of_service']:checked").val();
    var prohibited_matter = $("input[name='prohibited_matter']:checked").val();

    if((term_of_service != undefined && prohibited_matter != undefined)) {
        $("#btnAns02").attr('disabled', false);
    }else{
        $("#btnAns02").attr('disabled', true);
    }
}
 */

/*
$(function() {
    $("input[name='term_of_service']").click(function () {
        checkSubmit();
    });

    $("input[name='prohibited_matter']").click(function () {
        checkSubmit();
    });
});
*/

$(document).ready(function () {
    //checkSubmit();
    $("#ans").validate({
        'rules' : {
            're_content': {
                //required: true,
                maxlength: 2000,
                remote:{
                    url: $('#re_content').data('url'),
                    type: 'post',
                    data: {
                        type: 'words_json',
                        wordsJsonContent: function () {
                            var segmenter = new TinySegmenter();
                            var segs = segmenter.segment($('#re_content').val());
                            return JSON.stringify(segs);
                        }
                    }
                }
            },
            'public_flg': {
                required: true
            }
        },
        'messages' : {
            're_content':{
                required: "本文(管理者編集) は必須項目です",
                maxlength: function (params, input) {
                    return $.validator.format("「{0}」は「{1}」文字以下で入力してください。（現在「{2}」文字）", '本文(管理者編集)', 2000, $(input).val().length)
                }
            },
            'public_flg': {
                required: "公開区分 は必須項目です",
            }
        },
        submitHandler: function(form) { // <- pass 'form' argument in
            $(".btn-submit").attr("disabled", true);
            form.submit(); // <- use 'form' argument here.
        }

    });


});

$("#backAns01").click(function (e) {
    var re_content = $("#re_content").val();
    var old_re_content = $("#old_re_content").val();
    var public_flg = $("#public_flg").val();
    var old_public_flg = $("#old_public_flg").val();
    if(re_content.localeCompare(old_re_content)!= 0 || public_flg.localeCompare(old_public_flg)!=0 )
    {
        if(!confirm('入力内容は破棄されますがよろしいですか。')) {
            // Stop the link
            e.preventDefault();
        }
    }

});