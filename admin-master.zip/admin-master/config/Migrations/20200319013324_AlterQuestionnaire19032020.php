<?php
use Migrations\AbstractMigration;
use Phinx\Db\Adapter\MysqlAdapter;

class AlterQuestionnaire19032020 extends AbstractMigration
{
    /**
     * Change Method.
     *
     * More information on this method is available here:
     * https://book.cakephp.org/phinx/0/en/migrations.html#the-change-method
     * @return void
     */
    public function change()
    {
        $table = $this->table('questionnaire');
        $table
            ->addColumn('image_url1', 'string', [
                'default' => null,
                'null' => true,
                'limit' => 255,
                'after' => 'thumb_image',
            ])
            ->addColumn('image_url2', 'string', [
                'default' => null,
                'null' => true,
                'limit' => 255,
                'after' => 'image_url1',
            ])
            ->addColumn('image_url3', 'string', [
                'default' => null,
                'null' => true,
                'limit' => 255,
                'after' => 'image_url2',
            ])
            ->addColumn('category', 'integer', [
                'default' => null,
                'null' => false,
                'limit' => MysqlAdapter::INT_SMALL,
                'after' => 'description',
            ])
            ->addColumn('area', 'integer', [
                'default' => null,
                'null' => false,
                'limit' => MysqlAdapter::INT_TINY,
                'after' => 'category',
            ])
            ->addColumn('host_area', 'text', [
                'default' => null,
                'null' => true,
                'after' => 'area',
            ])
            ->addColumn('venue', 'text', [
                'default' => null,
                'null' => true,
                'after' => 'host_area',
            ])
            ->addColumn('adress', 'text', [
                'default' => null,
                'null' => true,
                'after' => 'venue',
            ])
            ->addColumn('latitude', 'text', [
                'default' => null,
                'null' => true,
                'after' => 'venue',
            ])
            ->addColumn('longitude', 'text', [
                'default' => null,
                'null' => true,
                'after' => 'latitude',
            ])
            ->addColumn('map_flg', 'integer', [
                'default' => null,
                'null' => true,
                'limit' => MysqlAdapter::INT_TINY,
                'after' => 'longitude',
            ])
            ->addColumn('event_date', 'text', [
                'default' => null,
                'null' => true,
                'after' => 'map_flg',
            ])
            ->changeColumn('start_time', 'datetime', [
                'default' => null,
                'null'    => true,
                'after' => 'event_date'
            ])
            ->changeColumn('end_time', 'datetime', [
                'default' => null,
                'null'    => true,
                'after' => 'start_time'
            ])
            ->addColumn('mail', 'text', [
                'default' => null,
                'null'    => true,
                'after' => 'end_time'
            ])
            ->addColumn('phone_number', 'text', [
                'default' => null,
                'null'    => true,
                'after' => 'mail'
            ])
            ->addColumn('business_hour', 'text', [
                'default' => null,
                'null'    => true,
                'after' => 'phone_number'
            ])
            ->addColumn('application_limit', 'integer', [
                'default' => 0,
                'null'    => true,
                'limit' => MysqlAdapter::INT_TINY,
                'after' => 'business_hour'
            ])
            ->update();
    }
}
