<?php
use Migrations\AbstractMigration;

class AlterQuestionnaireResultDetail27032020 extends AbstractMigration
{
    /**
     * Change Method.
     *
     * More information on this method is available here:
     * https://book.cakephp.org/phinx/0/en/migrations.html#the-change-method
     * @return void
     */
    public function change()
    {
        $table = $this->table('questionnaire_result_detail');
        $table
            ->dropForeignKey('questionnaire_result_id', 'questionnaire_result_detail_ibfk_1')
            ->update();
    }
}
