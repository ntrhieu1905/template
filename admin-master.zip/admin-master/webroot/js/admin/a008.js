$(document).ready(function(){
    // validation
    $('#a008').validate({
        ignore: [],
        focusInvalid: true,
        rules: {
            'start_time': {
                datetime: true,
            },
            'end_time': {
                datetime: true,
            },
        },
        messages: {
            'start_time': {
                datetime: $.validator.messages.datetime('公開日時'),
            },
            'end_time': {
                datetime: $.validator.messages.datetime('終了日時'),
            },
        },
        onfocusout: function(element) {
            this.element(element);
        },
        submitHandler: function(form) {
            $('#form-btn-008').attr('disabled', true);
            form.submit();
        }
    });

    //Copy url to clipboard OrderSpecChange #68011
    $('.btn-copy').click(function () {
        //Create temp DOM with value and copy
        var $temp = $("<input>");
        $("body").append($temp);
        $temp.val($(this).data('hash-url')).select();
        document.execCommand("copy");
        $temp.remove();
    })
});
