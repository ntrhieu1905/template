<?php
/**
 * Created by PhpStorm.
 * User: dat.tnt
 * Date: 2019/10/23
 * Time: 12:24
 */
namespace App\Controller;

use App\Libs\ConfigUtil;
use App\Libs\ValueUtil;
use Cake\Event\Event;
use Cake\ORM\TableRegistry;

/**
 * mast_ticket content controller
 */
class MasController extends AppAdminController
{
    /**
     * Override beforeFilter callback
     *
     * @return \Cake\Network\Response|null|void
     */
    public function beforeFilter(Event $event) {
        parent::beforeFilter($event);
        //Load common model
        $this->loadModel('mast_ticket');
        //Load common component
        $this->loadComponent('File');
        $this->loadComponent('FileAwsS3');
        $this->loadComponent('Query');
    }

    /**
     * Override beforeRender callback
     *
     * @param Event $event
     * @return \Cake\Network\Response|void|null
     */
    public function beforeRender(Event $event) {
        parent::beforeRender($event);
        // Get value from libs
        $category = ValueUtil::get('mast_ticket.category');
        $area = ValueUtil::get('mast_ticket.area');
        //Set parametters to view
        $this->set(compact('category', 'area'));
    }

    /**
     * A015 チケット一覧
     * A015
     */
    public function a015() {
        $session = $this->getRequest()->getSession();
        $params = [];
        //Check searching data session
        if($session->check('Mas.a015')){
            $params = $session->read('Mas.a015');
            $this->set(['searchData' => $params]);
        }
        //Process request post
        if($this->getRequest()->is(['post'])){
            $data = $this->getRequest()->getData();
            //Write session
            $session->delete('Mas.a015');
            $session->write('Mas.a015', $data);
            //Reload page
            return $this->redirect(['action' => 'a015']);
        }
        //Get records from database then paginate result
        $result = $this->MastTicket->search($params);
        $mastTickets = $this->paginate($result, ['limit' => ConfigUtil::get('paginate.ten_pages')]);
        //Set parametters to view
        $this->set(compact('mastTickets'));
    }

    /**
     * A016 チケット登録
     * A016
     */
    public function a016() {
        $mastTicketTable = 'mast_ticket';
        //Process request post
        if($this->getRequest()->is(['post'])){
            //Get params data
            $data = $this->getRequest()->getData();
            $data['total_number'] = $data['number'];
            $mastTicket = $this->Query->saveTable($mastTicketTable, $data);
            //Check when save data not success
            if(is_bool($mastTicket)){
                $this->set(compact('mastTicket'));
                $this->Flash->error(ConfigUtil::getMessage('CREATE_FAILURE'));
            }
            if(empty($mastTicket->getErrors())){
                //Update mast_ticket.image_url
                $this->saveImageUrl($mastTicket['id'], $data);
                //Redirect to view A015
                $this->Flash->success(ConfigUtil::getMessage('CREATE_SUCCESS'));
                return $this->redirect(['action' => 'a015']);
            }
            $this->showErrors($mastTicket->getErrors());
            $this->set(compact('data'));
        }
    }

    /**
     * A017 チケット編集
     * A017
     */
    public function a017($id = null) {
        //Check valid param id
        if(empty($id) || !is_numeric($id)){
            return $this->redirect(['controller' => 'Top', 'action' => 'error']);
        }
        //Check valid record
        $mastTicket = $this->MastTicket->getMastTicketById($id, true);
        if(empty($mastTicket) || !$mastTicket){
            return $this->redirect(['controller' => 'Top', 'action' => 'error']);
        }
        $mastTicket['exp_from'] = !empty($mastTicket['exp_from']) ? date_format($mastTicket['exp_from'], 'Y/m/d') : null;
        $mastTicket['exp_to'] = !empty($mastTicket['exp_to']) ? date_format($mastTicket['exp_to'], 'Y/m/d') : null;
        $mastTicketTable = 'mast_ticket';
        //Process request post | put | patch
        if($this->getRequest()->is(['post', 'put', 'patch'])){
            //Get params data
            $data = $this->getRequest()->getData();
            $data['start_time'] = !empty($data['start_time']) ? $data['start_time'] : null;
            $data['end_time'] = !empty($data['end_time']) ? $data['end_time'] : null;
            // mast_ticket.total_number = mast_ticket.total_number(old) + (number(new, enter on screen) - mast_ticket.number(old))
            $data['total_number'] = intval($mastTicket['total_number']) + (intval($data['number']) - intval($mastTicket['number']));
            $mastTicket = $this->Query->saveTable($mastTicketTable, $data, $id);
            //Check when save data not success
            if(is_bool($mastTicket)){
                $this->set(compact('mastTicket'));
                $this->Flash->error(ConfigUtil::getMessage('UPDATE_FAILURE'));
            }
            if(empty($mastTicket->getErrors())){
                //Update mast_ticket.image_url
                $this->saveImageUrl($mastTicket['id'], $data);
                //Redirect to view A015
                $this->Flash->success(ConfigUtil::getMessage('UPDATE_SUCCESS'));
                return $this->redirect(['action' => 'a015']);
            }
            $this->showErrors($mastTicket->getErrors());
        }
        $this->set(compact('mastTicket'));
    }

    /**
     * Save image_url to mast_ticket table
     * A016 - A017
     *
     * @param $mastTicketId
     * @param $data
     */
    private function saveImageUrl($mastTicketId, $data) {
        //Moved upload file and save image_url field
        for($i = 1; $i <= 3; $i++){
            $imgUrl = $data['image_url'.$i];
            switch($imgUrl['error']){
                case UPLOAD_ERR_NO_FILE:
                    if(empty($data['ticket_image_url'.$i])){
                        $data['image_url'.$i] = null;
                    } else { //Set old image
                        $data['image_url'.$i] = $data['ticket_image_url'.$i];
                    }
                    break;
                case UPLOAD_ERR_OK:
                    $imgUpload = !empty($imgUrl) ? $this->FileAwsS3->uploadFileToS3($imgUrl, 'ticket', $mastTicketId) : '';
                    $data['image_url'.$i] = isset($imgUpload->data->file_path) ? current($imgUpload->data->file_path) : $data['image_url'.$i];
                    break;
            }
        }
        //Save mast_ticket
        $this->Query->saveTable('mast_ticket', $data, $mastTicketId);
    }
}
