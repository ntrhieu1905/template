var onlyOneRecord = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
var MODE_SAVE = {
    ADD: 1,
    EDIT: 2,
    COPY: 3
};
var SCREEN_ID = $('#screen-id').val();
var disabledFieldWithConditions = [
    'unit_price',
    'exp_from',
    'exp_to',
    'e_ticket'
];
var E_TICKET_VAL = {
    NO: 0,
    YES: 1
};
var NUMBER_DISP_VAL = {
    NO: 0,
    YES: 1
};
var USAGE_LIMIT_VAL = {
    NO_LIMITED: 0,
    LIMITED: 1
};
var FREE_SHIPPING_VAL = {
    SHIPPING:0,
    NO_SHIPPING: 1
};
var NO_PAYMENT_FLAG = 0;
$(document).ready(function() {
    // enter key event
    $('#part-list').keypress(enterEvent);
    $('#detail-preview').keypress(enterEvent);
    // 追加 button
    $('body').on('click', '.add-record', createQuestionnaireDetail);
    // 削除 button
    $('body').on('click', '.remove-record', deleteQuestionnaireDetail);
    // validate initialize
    $('#part-list').validate();
    // イベント参加費 not negative
    $('body').on('input', '.number-not-negative', function () {
        this.value = (this.value < 0) ? Math.abs(this.value) : this.value;
    });
    // validation
    validateForm();
    // パーツリスト validation
    $('#part-list').validate({
        focusInvalid: true,
        ignore: []
    });
    // 公開フラグ
    var status = $('#statusFlg').val();
    var questionnaireDetailDiv = $('#questionnaireDetail');
    if (status == 'enable') {
        // sortable
        $("#sortable").sortable();
        $("#sortable").disableSelection();
    }
    // show パーツリスト
    var $dropFields = $("#mastQuestionnaireData");
    var details = $dropFields.data('details');
    if (details) {
        $.each(details, function(index, mastQuestionnaireDetail) {
            var $dropElement = buildElement(index, mastQuestionnaireDetail, status);
            $dropElement.appendTo('#mastQuestionnaire');
            // validation
            $dropElement.find('.labelInput').rules('add', {
                maxlength: 255,
                messages: {
                    maxlength: function(params, input) {
                        return $.validator.messages.maxlength(['ラベル名', 255, $(input).val().length]);
                    }
                }
            });
        });
        getPrefectureList();
        getMarriageList();
        getJobList();
        $('.datepicker').datepicker();
    }
    // show 申込フォームプレビュー
    var questionnaireDetailData = $('#questionnaireDetailData').data('details');
    if (questionnaireDetailData) {
        $.each(questionnaireDetailData, function(index, questionnaireDetail) {
            var element = showQuestionnaireDetail(questionnaireDetail, status);
            questionnaireDetailDiv.append(element);
            if (status == 'enable') {
                questionnaireDetailDiv.sortable();
            }
        });
        $('.datepicker').datepicker();
    }
    if (status == 'enable') {
        questionnaireDetailDiv.sortable({
            axis: 'y',
            update: function (event, ui) {
                if (status == 'disable') {
                    return false;
                }
                // show loading
                showLoading();
                // get data
                var data = $(this).sortable('serialize');
                // get url
                var hostname = window.location.origin;
                var url = hostname + $('#updateSortQuestionnaireDetailLink').val();
                var options = {
                    data: data,
                    type: 'POST',
                    url: url
                };
                var doneFunction = function (res) {
                    hideLoading();
                };
                var failFunction = function () {
                    hideLoading();
                };
                // POST to server using $.post or $.ajax
                $.ajax(options)
                    .done(doneFunction)
                    .fail(failFunction);
            }
        });
    }
    // validate required when focus btn file
    $('[id*="btn-file-"]').click(function(event) {
        $(this).focus(function() {
            if($(this).closest('.file-area').find('.file-img').val() == '') {
                $(this).closest('.file-area').find('.old-img').val('');
                $(this).closest('.file-area').find('.show-file').html('');
                $('.formA009').validate().element($(this).closest('.file-area').find('.file-img'));
            }
        });
    });

    // set data upper_limit to input lower_limit
    $('#number').data('lower', $('#lower-limit').val());
    $('#upper-limit').data('limit', $('#lower-limit').val());
    $('#lower-limit').change(function () {
        $('#upper-limit').data('limit', $('#lower-limit').val());
        $('#number').data('lower', $('#lower-limit').val());
    });
    // set data lower_limit to input upper_limit
    $('#upper-limit').change(function () {
        $('#lower-limit').data('limit', $('#upper-limit').val());
        $('#number').data('upper', $('#upper-limit').val());
    });
    $('#number').change(function () {
        var number = parseInt($(this).val()); //get value number input
        var lowerlimit = typeof $(this).data('lower') !== "undefined" ? parseInt($(this).data('lower')) : ""; //get value lower to compare
        var upperlimit = typeof $(this).data('upper') !== "undefined" ? parseInt($(this).data('upper')) : ""; //get value upper to compare
        if (number < lowerlimit ||
            number < upperlimit ||
            number <= 0) { // number < lower or upper || <= 0
            $('#upper-limit').valid();
            $('#lower-limit').valid();
            return;
        }
        if(upperlimit !== "") {
            if(lowerlimit <= upperlimit &&
                lowerlimit > 0 &&
                upperlimit > 0
            ) {
                $('#upper-limit').removeClass('error-message');
                $('#lower-limit').removeClass('error-message');
                $('.limit-number').find('div.error-message').remove();
            }
        } else {
            if(lowerlimit > 0 || lowerlimit < number) {
                $('#upper-limit').removeClass('error-message');
                $('#lower-limit').removeClass('error-message');
                $('.limit-number').find('div.error-message').remove();
            }
        }
    })
    /** Event process button in table&form event ticket **/
    $('#table-event-ticket tbody').find('.list-event-ticket').each(function() {
        // get mast_ticket.id in table ticket
        var idMastTicket = $(this).find('#id-mast-ticket').data('id_mast_ticket');
        // 編集(チケット) edit button | コピー copy button
        var btnEditTicket = '#edit-ticket-'+idMastTicket,
            btnCopyTicket = '#copy-ticket-'+idMastTicket,
            combinedStringBtn = btnEditTicket.concat(',',btnCopyTicket);
        $(combinedStringBtn).click(function() {
            var $this = $(this);
            // focusout button
            $this.blur();
            // show form ticket
            $('.body-form-event-ticket').removeClass('hidden');
            // clear form ticket
            clearFormTicket();
            // set info data to form ticket
            $.ajax({
                method: 'post',
                url: $('#post-url-list-mast-ticket').val(),
                data: { id_mast_ticket: idMastTicket },
                success: function(res) {
                    var dataRes = res != '' ? JSON.parse(res) : '';
                    var paymentFlagCheck = $('[name="payment_flag_check"]').val();
                    if(dataRes) {
                        for(var dataTicket in dataRes) {
                            var fieldNameOfTicket = dataTicket;
                            var dataFieldOfTicket = dataRes[dataTicket];
                            var targetForm = $('#form-input-ticket');
                            var targetField = targetForm.find('input[name='+fieldNameOfTicket+']');
                            // if valid field name then set value
                            if(fieldNameOfTicket == targetField.attr('name')) {
                                // screen A010 - disabled field with condition mast_ticket.number != mast_ticket.total_number
                                disabledFieldWithConditions.filter((field) => {
                                    if(SCREEN_ID == 'a010' && field == fieldNameOfTicket) {
                                        return dataRes.number != dataRes.total_number
                                            ? targetField.prop('disabled', true) : targetField.prop('disabled', false);
                                    }
                                });
                                //disable 価格 if paymentFlag = 0
                                if(paymentFlagCheck == NO_PAYMENT_FLAG) {
                                    if(targetField.attr('name') === 'unit_price') {
                                        targetField.prop('disabled', true);
                                    }
                                }
                                if(targetField.is(':radio')) {
                                    // check form have radio input
                                    targetField.each(function() {
                                        console.log(dataFieldOfTicket);
                                        console.log(parseInt($(this).val()));
                                        if(parseInt(dataFieldOfTicket) == parseInt($(this).val())) {
                                            $(this).prop('checked', true);
                                        } else {
                                            $(this).prop('checked', false);
                                        }
                                    });
                                } else if(targetField.is(':checkbox')) {
                                    // check form have checkbox input
                                   if(targetField.attr('name') == 'free_shipping') {
                                       if(dataFieldOfTicket == FREE_SHIPPING_VAL.NO_SHIPPING) {
                                           // free_shipping = 1(no shipping) is checked.
                                           // no set value input hidden so input helper free_shipping have use hiddenField
                                           targetField.is(':hidden') ? '' : targetField.val(dataFieldOfTicket);
                                           targetField.prop('checked', true);
                                       }
                                       //check and disable 送料を無料にする if paymentFlag = 0
                                       if(paymentFlagCheck == NO_PAYMENT_FLAG) {
                                           targetField.closest('.bb-form-group').find('#free_shipping_hidden').val(FREE_SHIPPING_VAL.NO_SHIPPING);
                                           targetField.prop('checked', true);
                                           targetField.prop('disabled', true);
                                           targetField.css('cursor', 'not-allowed');
                                       }
                                   }
                                } else {
                                    // can't get value input disabled when submit form so process create and set value input hidden
                                    if(targetField.is(':disabled')) {
                                        $("<input>").attr({
                                            name: targetField.attr('name'),
                                            id: targetField.attr('id'),
                                            type: 'hidden',
                                            value: dataFieldOfTicket
                                        }).appendTo($('#frmEventTicket').find('#'+targetField.attr('id')).parent());
                                    }
                                    targetField.val(dataFieldOfTicket);
                                    if(targetField.hasClass('date-hour-minute')) {
                                        var elementDate = targetField.parent().find('.date-hour-minute-item'),
                                            elementHour = targetField.parent().find('.hour-item'),
                                            elementMinute = targetField.parent().find('.minute-item');
                                        // split string with pattern "2020/4/3 00:00"
                                        if(!isEmpty(dataFieldOfTicket)) {
                                            var splitDate = dataFieldOfTicket.split(' '),
                                                splitTime = splitDate[1].split(':'),
                                                date = splitDate[0],
                                                hour = splitTime[0],
                                                minute = splitTime[1];
                                            elementDate.val(date);
                                            elementHour.val(hour);
                                            elementMinute.val(minute);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            });
            // scroll to form ticket
            scrollToFormTicket();
            // set mode save
            if($this.attr('name') == $(btnEditTicket).attr('name')) {
                $('#mode-save').val(MODE_SAVE.EDIT);
            } else {
                $('#mode-save').val(MODE_SAVE.COPY);
            }
        });
    });

    // 追加(チケット) add button. Show form event ticket
    $('#add-ticket').click(function() {
        // focusout button
        $(this).blur();
        // show form ticket
        var bodyForm = $('.body-form-event-ticket');
        bodyForm.removeClass('hidden');
        // clear input of form ticket
        clearFormTicket();
        // scroll to form ticket
        scrollToFormTicket();
        //disable if paymentFlag = 0
        var paymentFlagCheck = $('[name="payment_flag_check"]').val();
        if(paymentFlagCheck == NO_PAYMENT_FLAG) {
            //価格
            bodyForm.find('#unit-price').prop('disabled', true);
            bodyForm.find('#unit-price').val(0);
            //送料を無料にする
            bodyForm.find('#free-shipping').closest('.bb-form-group').find('input[name="free_shipping"]:hidden').val(FREE_SHIPPING_VAL.NO_SHIPPING);
            bodyForm.find('#free-shipping').prop('disabled', true);
            bodyForm.find('#free-shipping').prop('checked', true);
            bodyForm.find('#free-shipping').css('cursor', 'not-allowed');
        }
        // set mode save
        $('#mode-save').val(MODE_SAVE.ADD);
    });
    // リセット reset button. Clear form event ticket
    $('#reset-ticket').click(function() {
        // focusout button
        $(this).blur();
        // clear input of form ticket
        clearFormTicket();
        // scroll to form ticket
        scrollToFormTicket();
    });
    // input address get latitude and longitude from api google maps for screen a009
    $('#address').change(function() {
        var addressVal = $(this).val();
        var latitude = $('#latitude'),
            longitude = $('#longitude');
        if(SCREEN_ID == 'a009') {
            getLatitudeLongitude(addressVal, showResultLatitudeLongitude);
        }
    });
});

/**
 * Validate form
 */
function validateForm() {
    //form A009
    $('.formA009').validate({
        ignore: "[contenteditable='true'].note-editable",
        focusInvalid: true,
        rules: {
            'publish_flag': {
                required: true
            },
            'title': {
                required: true,
                maxlength: 100,
            },
            'image_url1': {
                required: function() {
                    return $('[name="image_url1_url"]').val() == '' ? true : false;
                },
                extension: "jpg|jpeg|png",
                filesize: 4
            },
            'image_url2': {
                extension: "jpg|jpeg|png",
                filesize: 1
            },
            'image_url3': {
                extension: "jpg|jpeg|png",
                filesize: 1
            },
            'thumb_image': {
                required: function() {
                    return $('[name="thumb_image_url"]').val() == '' ? true : false;
                },
                extension: "jpg|jpeg|png",
                filesize: 1
            },
            'description': {
                required: true,
                maxlength: 1000
            },
            'detail_description': {
                required: true,
                maxLengthEditor: 3000
            },
            'start_time': {
                required: true,
                datetime: true,
                lesserThanDateNormal: true
            },
            'end_time': {
                required: true,
                datetime: true,
                greaterThanDateNormal: true
            },
            'host_area': {
                required: true,
                maxlength: 10
            },
            'venue': {
                maxlength: 50
            },
            'address': {
                maxlength: 50
            },
            'latitude': {
                maxlength: 50
            },
            'longitude': {
                maxlength: 50
            },
            'event_date': {
                required: true,
                maxlength: 50
            },
            'mail': {
                email: true,
                maxlength: 50
            },
            'phone_number': {
                maxlength: 50
            },
            'business_hour': {
                maxlength: 50
            },
        },
        messages: {
            'publish_flag': {
                required: function(params, input) {
                    return $.validator.messages.required($(input).data('label'));
                },
            },
            'title': {
                required: function(params, input) {
                    return $.validator.messages.required($(input).data('label'));
                },
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), 100, $(input).val().length]);
                }
            },
            'image_url1': {
                required: function(params, input) {
                    return $.validator.messages.required($(input).data('label'));
                },
                extension: $.validator.messages.extension('「jpg, jpeg, png」')
            },
            'image_url2': {
                extension: $.validator.messages.extension('「jpg, jpeg, png」')
            },
            'image_url3': {
                extension: $.validator.messages.extension('「jpg, jpeg, png」')
            },
            'thumb_image': {
                required: function(params, input) {
                    return $.validator.messages.required($(input).data('label'));
                },
                extension: $.validator.messages.extension('「jpg, jpeg, png」')
            },
            'description': {
                required: function(params, input) {
                    return $.validator.messages.required($(input).data('label'));
                },
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), params, $(input).val().length]);
                }
            },
            'detail_description': {
                required: function(params, input) {
                    return $.validator.messages.required($(input).data('label'));
                },
                maxLengthEditor: function(params, input) {
                    return $.validator.messages.maxLengthEditor([$(input).data('label'), params, checkMaxLength($(input).val())]);
                }
            },
            'start_time': {
                required: function(params, input) {
                    return $.validator.messages.required($(input).data('label'));
                },
                datetime: function(params, input) {
                    return $.validator.messages.datetime($(input).data('label'));
                },
                lesserThanDateNormal: function(params, input) {
                    return $.validator.messages.lesserThanDateNormal(['販売終了日時', $(input).data('label')]);
                }
            },
            'end_time': {
                required: function(params, input) {
                    return $.validator.messages.required($(input).data('label'));
                },
                datetime: function(params, input) {
                    return $.validator.messages.datetime($(input).data('label'));
                },
                greaterThanDateNormal: function(params, input) {
                    return $.validator.messages.greaterThanDateNormal([$(input).data('label'), '販売開始日時']);
                }
            },
            'host_area': {
                required: function(params, input) {
                    return $.validator.messages.required($(input).data('label'));
                },
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), 10, $(input).val().length]);
                }
            },
            'venue': {
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), 50, $(input).val().length]);
                }
            },
            'address': {
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), 50, $(input).val().length]);
                }
            },
            'latitude': {
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), 50, $(input).val().length]);
                }
            },
            'longitude': {
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), 50, $(input).val().length]);
                }
            },
            'event_date': {
                required: function(params, input) {
                    return $.validator.messages.required($(input).data('label'));
                },
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), 50, $(input).val().length]);
                }
            },
            'mail': {
                email: $.validator.messages.email(),
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), 50, $(input).val().length]);
                }
            },
            'phone_number': {
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), 50, $(input).val().length]);
                }
            },
            'business_hour': {
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), 50, $(input).val().length]);
                }
            },
        },
        errorPlacement: function(error, element) {
            switch(element.attr('name')) {
                case 'publish_flag':
                    error.appendTo($('#publish-flag-group'));
                    break;
                default:
                    error.appendTo($(element).parent());
                    break;
            }
        },
        submitHandler: function(form) {
            $('#submit-a009-btn').attr('disabled', true);
            form.submit();
        }
    });
    //form event ticket
    $('#frmEventTicket').validate({
        ignore: [],
        focusInvalid: true,
        rules: {
            'ticket_name': {
                required: true,
                maxlength: 50
            },
            'list_price': {
                maxlength: 255
            },
            'unit_price': {
                required: true,
                checkNumeric: true,
                maxlength: 10
            },
            'number': {
                required: true,
                checkNumeric: true,
                maxlength: 10,
                numberCorrectly: true
            },
            'lower_limit': {
                checkNumeric: true,
                maxlength: 10,
                limitCorrectly: true
            },
            'upper_limit': {
                checkNumeric: true,
                maxlength: 10,
                limitCorrectly: true
            },
            'exp_from': {
                date: true,
                lesserThanDateNormal: true
            },
            'exp_to': {
                date: true,
                greaterThanDateNormal: true
            },
            'start_time': {
                datetime: true,
                lesserThanDateNormal: true
            },
            'end_time': {
                datetime: true,
                greaterThanDateNormal: true
            }
        },
        messages: {
            'ticket_name': {
                required: function(params, input) {
                    return $.validator.messages.required($(input).data('label'));
                },
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), 50, $(input).val().length]);
                }
            },
            'list_price': {
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), 255, $(input).val().length]);
                }
            },
            'unit_price': {
                required: function(params, input) {
                    return $.validator.messages.required($(input).data('label'));
                },
                checkNumeric: function(params, input) {
                    return $.validator.messages.checkNumeric($(input).data('label'));
                },
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), 10, $(input).val().length]);
                }
            },
            'number': {
                required: function(params, input) {
                    return $.validator.messages.required($(input).data('label'));
                },
                checkNumeric: function(params, input) {
                    return $.validator.messages.checkNumeric($(input).data('label'));
                },
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), 10, $(input).val().length]);
                },
                numberCorrectly: function(params, input) {
                    return $.validator.messages.numberCorrectly;
                }
            },
            'lower_limit': {
                checkNumeric: function(params, input) {
                    return $.validator.messages.checkNumeric($(input).data('label'));
                },
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), 10, $(input).val().length]);
                },
                limitCorrectly: function(params, input) {
                    return $.validator.messages.limitCorrectly;
                }
            },
            'upper_limit': {
                checkNumeric: function(params, input) {
                    return $.validator.messages.checkNumeric($(input).data('label'));
                },
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), 10, $(input).val().length]);
                },
                limitCorrectly: function(params, input) {
                    return $.validator.messages.limitCorrectly;
                }
            },
            'exp_from': {
                date: function(params, input) {
                    return $.validator.messages.date($(input).data('label'));
                },
                lesserThanDateNormal: function(params, input) {
                    return $.validator.messages.lesserThanDateNormal(['有効期限(to)', $(input).data('label')]);
                }
            },
            'exp_to': {
                date: function(params, input) {
                    return $.validator.messages.date($(input).data('label'));
                },
                greaterThanDateNormal: function(params, input) {
                    return $.validator.messages.greaterThanDateNormal([$(input).data('label'), '有効期限(from)']);
                }
            },
            'start_time': {
                datetime: function(params, input) {
                    return $.validator.messages.datetime($(input).data('label'));
                },
                lesserThanDateNormal: function(params, input) {
                    return $.validator.messages.lesserThanDateNormal(['販売終了日時', $(input).data('label')]);
                }
            },
            'end_time': {
                datetime: function(params, input) {
                    return $.validator.messages.datetime($(input).data('label'));
                },
                greaterThanDateNormal: function(params, input) {
                    return $.validator.messages.greaterThanDateNormal([$(input).data('label'), '販売開始日時']);
                }
            }

        },
        submitHandler: function(form) {
            $('#save-ticket').attr('disabled', true);
            form.submit();
            // clear form ticket
            // clearFormTicket();
        }
    });
}
/**
 * Enter event
 */
function enterEvent(e) {
    if (e.which == 13) { e.preventDefault(); }
}
// Replace all function
String.prototype.replaceAll = function(search, replacement) {
    var target = this;
    return target.replace(new RegExp(search, 'g'), replacement);
};
/**
 * CREATE ELEMENT
 *
 * [input type]
 * 1:name       2:kana
 * 3:address    4:tel
 * 5:mobile     6:birth
 * 7:sex        8:job
 * 9:email      10:text
 * 11:number    12:radio
 * 13:check     14:select
 * 15:title     16:textarea
 */
function buildElement(index, questionnaireDetail, status) {
    var dropElement =  buildHTML(index, questionnaireDetail, status);
    var $dropElement = $(dropElement);
    var inputType = questionnaireDetail.input_type;
    return $dropElement;
}
/**
 * CREATE HTML ELEMENT FROM OPTION
 */
function buildHTML(newIndex, questionnaireDetail, status) {
    var id          = questionnaireDetail.id,
        inputType   = questionnaireDetail.input_type,
        labelName   = questionnaireDetail.label_name,
        mandatoryFlag     = questionnaireDetail.mandatory_flag,
        inputFormat = JSON.parse(questionnaireDetail.input_format)
    ;
    // var required = (questionnaireDetail.mandatory_flag == 1) ? '*' : '';
    var templateHtml = $('#template').html();
    // create 入力形式
    var content = createQuestionnaireDetailInput(inputType, inputFormat, id, status, 'questionnaire');
    // ラベル名
    var labelEditInput = '';
    var errorDiv = '';
    // validate one record
    if ($.inArray(inputType, onlyOneRecord) > -1) {
        labelEditInput = createEditInputLabel(labelName, 'labelName_' + id, 'disable');
    } else {
        labelEditInput = createEditInputLabel(labelName, 'labelName_' + id, status, true);
    }
    var inputButton = '';
    // 追加ボタン表示
    if (status == 'enable') {
        var buttonData = {
            mastQuestionnairePartsId: id,
            countQuestionnaireDetail: questionnaireDetail.questionnaire_detail.length
        };
        inputButton = createButton('add', buttonData);
    }
    // 必須 checkbox
    var requireCheckbox = createRequireCheckbox(mandatoryFlag, id, status);
    // パーツタイプ
    var label = labelName.charAt(0).toUpperCase() + labelName.slice(1);
    // create HTML
    templateHtml = templateHtml.replace('__label__', label)
                               .replace('__requireCheckbox__', requireCheckbox)
                               .replace('__inputLabel__', labelEditInput)
                               .replace('__errorDiv__', errorDiv)
                               .replace('__inputForm__', content)
                               .replace('__buttonData__', inputButton);
    return templateHtml;
}
/**
 * 必須 checkbox
 */
function createRequireCheckbox(requiredFlg, index, status) {
    // add disable attribute
    var disable = '';
    if (status == 'disable') {
        disable = 'disabled';
    }
    // 必須フラグ
    var require = '';
    var html = '<input ' + disable + ' type="checkbox" id="mast_questionnaire_require_' + index + '"' + require + ' />';
    return html;
}
/**
 * Create 追加 button
 */
function createButton(btnTyp, data) {
    if (data.countQuestionnaireDetail > 0) {
        var className = 'btn btn-danger bb-btn-round btn-sm add-record btn-disable';
    } else {
        var className = 'btn btn-danger bb-btn-round btn-sm add-record';
    }
    var html = "<button name='add-record' data-index='" + data.mastQuestionnairePartsId +
                "' style='margin-left:10px' class='" + className + "' data-questionnaire-parts='" +
                JSON.stringify(data) + "' type='submit' id='add-record-" + data.mastQuestionnairePartsId + "'>追加</button>";
    return html;
}
/**
 * パーツリスト - ラベル名
 */
function createEditInputLabel(labelName, inputName, status, validation = false) {
    // add disable attribute
    var disable = '';
    if (status == 'disable') {
        disable = 'disabled';
    }
    if (validation) {
        var $html = '<input ' + disable + ' type="text" name="' + inputName + '" class="form-control labelInput" value="' + labelName + '" />';
    } else {
        var $html = '<input ' + disable + ' type="text" name="' + inputName + '" class="form-control" value="' + labelName + '" />';
    }
    return $html;
}
function showValidateMessage(validate, type) {
    var html = '';
    if (typeof validate !== "undefined" && validate.length > 0) {
        if ((type == 'text' || type == 'multi-text' || type == 'tel' || type == 'address') && validate[0].maxlength) {
            html += '<p class="small-txt">最大' + nvl(validate[0].maxlength) + '文字</p>';
        }
        if (type == 'number' && validate[0].maxlength) {
            html += '<p class="small-txt">数字' + nvl(validate[0].maxlength) + '文字</p>';
        }
    }
    return html;
}
/**
 * パーツリスト: 13:radio, 14:check, 15:select
 */
function createSpecialInput(format, index, status) {
    var html = '';
    // add disable attribute
    var disable = '';
    if (status == 'disable') {
        disable = 'disabled';
    }
    // create input
    html += '<div>';
    html += '<input ' + disable + ' name="input_option_' + index + '"' + ' class="form-control"' + ' value=' + format.options.join() + '>';
    html += '</div>';
    return html;
}
/**
 * 住所
 */
function createAddressInput(format, status) {
    var html = '';
    var disable = '';
    if (status == 'disable') {
        disable = 'disabled';
    }
    html += '<div class="float-left width-100-p">';
    html += createTextbox(format.first, 'address', status);
    html += '<div class="options float-left width-50-p mg-5 ' +  nvl(format.class) + '"' + '>';
    html += '<select ' + disable + ' class="form-control prefectureList">';
    html += '<option value="">-</option>';
    html += '</select><p class="small-txt">&nbsp;</p>';
    html += '</div>';
    html += '</div></div><div class="float-left width-100-p">';
    html += createTextbox(format.third, 'address', status);
    html += createTextbox(format.fourth, 'address', status);
    html += '</div><div class="float-left width-100-p">';
    html += createTextbox(format.fifth, 'address', status);
    html += '</div>';
    return html;
}

/**
 * create 職種 in パーツリスト
 */
function createJobInput(format, status) {
    var html = '';
    var disable = '';
    if (status == 'disable') {
        disable = 'disabled';
    }
    html += '<div class="float-left width-100-p mg-5">';
    html += '<select ' + disable + ' class="form-control jobList">';
    html += '<option value="">-</option>';
    html += '</select>';
    html += '</div>';
    return html;
}

/**
 * create あなたは結婚していますか？ in パーツリスト
 */
function createMarriageInput(format, status) {
    var html = '';
    var disable = '';
    if (status == 'disable') {
        disable = 'disabled';
    }
    html += '<div class="float-left width-100-p mg-5">';
    html += '<select ' + disable + ' class="form-control marriageList">';
    html += '<option value="">-</option>';
    html += '</select>';
    html += '</div>';
    return html;
}

// get prefectures list by ajax
function getPrefectureList(format, status) {
    var options = {
        url: $('#getPrefectureUrl').val(),
        type: 'GET',
        dataType: 'json',
        data: {}
    };
    var doneFunction = function(res) {
        var prefectures = res.data;
        var html = '<option value="">-</option>';
        // create option
        $.each(prefectures, function (idx, text) {
            html += '<option value="' + text + '">' + text + '</option>';
        });
        $('.prefectureList option').remove();
        $('.prefectureList').each(function() {
            $(this).append(html);
        });
    };
    var failFunction = function() {};
    $.ajax(options)
        .done(doneFunction)
        .fail(failFunction);
}

// get jobs list by ajax
function getJobList(format, status) {
    var options = {
        url: $('#getJobsUrl').val(),
        type: 'GET',
        dataType: 'json',
        data: {}
    };
    var doneFunction = function(res) {
        var jobs = res.data;
        var html = '<option value="">-</option>';
        // create option
        $.each(jobs, function (idx, text) {
            html += '<option value="' + text + '">' + text + '</option>';
        });
        $('.jobList option').remove();
        $('.jobList').each(function() {
            $(this).append(html);
        });
    };
    var failFunction = function() {};
    $.ajax(options)
        .done(doneFunction)
        .fail(failFunction);
}

// get marriage list by ajax
function getMarriageList(format, status) {
    var options = {
        url: $('#getMarriagesUrl').val(),
        type: 'GET',
        dataType: 'json',
        data: {}
    };
    var doneFunction = function(res) {
        var marriages = res.data;
        var html = '<option value="">-</option>';
        // create option
        $.each(marriages, function (idx, text) {
            html += '<option value="' + text + '">' + text + '</option>';
        });
        $('.marriageList option').remove();
        $('.marriageList').each(function() {
            $(this).append(html);
        });
    };
    var failFunction = function() {};
    $.ajax(options)
        .done(doneFunction)
        .fail(failFunction);
}
/**
 * CREATE TEXT INPUT
 */
function createTextbox(format, type, status) {
    var html = '';
    var width = 'width-100-p';
    var datePicker = '';
    if (type == 'date') {
        width = 'width-50';
        datePicker = 'datepicker';
    } else if (type == 'address' || type == 'multi-text' || type == 'tel') {
        width = 'width-50-p';
    } else if (type == 'tel') {
        width = 'width-auto';
    }
    html += '<div class="float-left ' + width + ' mg-5">';
    // add disable attribute
    var disable = '';
    if (status == 'disable') {
        disable = 'disabled';
    }
    // create validate attribute
    var validationAttr = '';
    if ($.type(format.validate) == 'string') {
        validationAttr = validateAttr(format.validate);
    }
    if ($.type(format.validate) == 'array') {
        $.each(format.validate, function(key, value) {
            validationAttr = validateAttr(value);
        });
    }
    // create input
    html += '<input ' + disable + ' class="form-control ' + datePicker + ' ' +  nvl(format.class) + '"' + validationAttr + ' size="' + nvl(format.size) + '" placeholder=' + nvl(format.placeholder) + '>';
    if (type !== 'date') {
        html += showValidateMessage(format.validate, type);
    }
    html += '</div>';
    return html;
}
/**
 * CREATE MULTI TEXT INPUT
 */
function createMultiTextbox(format, type, status) {
    var html = '';
    $.each(format, function (idx, elementFormat) {
        html += createTextbox(elementFormat, type, status);
    });
    return html;
}
/**
 * CREATE TEXTAREA INPUT
 */
function createTextArea(format, status) {
    // add disable attribute
    var disable = '';
    if (status == 'disable') {
        disable = 'disabled';
    }
    var html = '';
    html += '<div>';
    html += '<textarea ' + disable + ' class="form-control "' +  validateAttr(format.validate) +  '></textarea>';
    // show validate message
    html += showValidateMessage(format.validate, 'text');
    html += '</div>';
    return html;
}
/**
 * CREATE RADIO INPUT
 */
function createRadio(newIndex, format, status) {
    // add disable attribute
    var disable = '';
    if (status == 'disable') {
        disable = 'disabled';
    }
    var html = '<div class="radio options "' + nvl(format.class) + ' data-value="' + format.options.join("\n") + '">';
    $.each(format.options, function (idx, text) {
        html += '<label class="radio-inline"> ' +
            '<input type="radio" ' + disable + ' name="radioName' + newIndex + '" value="' + text.replace(/(<([^>]+)>)/ig,"") + '"> ' +
            text.replace(/(<([^>]+)>)/ig,"") +
            '</label>';
    });
    html += '</div>';
    return html;
}
/**
 * CREATE CHECKBOX INPUT
 */
function createCheckbox(format, status) {
    // add disable attribute
    var disable = '';
    if (status == 'disable') {
        disable = 'disabled';
    }
    var html = '<div class="checkbox options ' +  + nvl(format.class) + '" data-value="' + format.options.join("\n") + '">';
    $.each(format.options, function (idx, text) {
        html += '<label class="checkbox-inline bb-checkbox">' +
            '<input ' + disable + ' type="checkbox" value="' + text.replace(/(<([^>]+)>)/ig,"") + '">' +
            '<span class="bb-ui"></span> ' +
            text.replace(/(<([^>]+)>)/ig,"") +
            '</label>';
    });
    html += '</div>';
    return html;
}
/**
 * CREATE SELECT INPUT
 */
function createSelect(format, status) {
    // add disable attribute
    var disable = '';
    if (status == 'disable') {
        disable = 'disabled';
    }
    var html = '<div class="options ' +  nvl(format.class) + '"' + '>';
    html += '<select ' + disable + ' class="form-control">';
    html += '<option value="">-</option>';
    $.each(format.options, function (idx, text) {
        html += '<option value="' + text + '">' + text + '</option>';
    });
    html += '</select>';
    html += '</div>';
    return html;
}
/**
 * CREATE LABEL
 */
function createTitle(format) {
    return '<div class="' + nvl(format.class) +'">' + nvl(format.text) + '</div>';
}
/**
 * CREATE VALIDATE FOR INPUT
 */
function validateAttr(option) {
    var str = '';
    return str;
}
/**
 * Prevent null
 */
function nvl(param, defaultValue) {
    if(defaultValue == null){
        defaultValue = '';
    }
    return param || defaultValue;
}
/**
 * 追加ボタン
 */
function createQuestionnaireDetail(e) {
    e.preventDefault();
    var addBtn = $(this);
    if (addBtn.hasClass('btn-disable')) {
        return false;
    }
    var data = addBtn.data('questionnaire-parts');
    var id = addBtn.data('index');
    data.labelName = $('input[name=labelName_'+id+']').val();
    if (data.labelName.length > 255) {
        return false;
    }
    showLoading();
    // create require label
    var required = '';
    if ($('#mast_questionnaire_require_'+id+':checkbox:checked').length > 0) {
        required = 'required';
    }
    data.required = required;
    // get input option value
    var inputOption = $('input[name=input_option_' + id + ']');
    if (inputOption.length > 0) {
        data.options = inputOption.val();
    }
    // get url
    var hostname = window.location.origin;
    var url = hostname + $('#createQuestionnaireDetailLink').val();
    var options = {
        url: url,
        type: 'POST',
        dataType: 'json',
        data: data
    };
    var doneFunction = function(res) {
        if (res.code !== 200) {
            hideLoading();
            return false;
        }
        // show questionnaire detail
        var questionnaireDetail = showQuestionnaireDetail(res.data);
        $('#questionnaireDetail').append(questionnaireDetail);
        $('#questionnaireDetail').sortable();
        var inputType = res.data.input_type;
        if ($.inArray(inputType, onlyOneRecord) > -1) {
            $('#add-record-'+id).addClass('btn-disable');
        }
        // 住所
        if (inputType == 3) {
            getPrefectureList();
        }
        // あなたは結婚していますか？
        if (inputType == 8) {
            getMarriageList();
        }
        // 職業
        if (inputType == 9) {
            getJobList();
        }
        // 生年月日
        if (inputType == 6) {
            $('.datepicker').datepicker();
        }
        addBtn.blur();
        hideLoading();
    };
    var failFunction = function(jqxhr, textStatus, error) {
        hideLoading();
    };
    // call ajax
    $.ajax(options)
        .done(doneFunction)
        .fail(failFunction);
}
function showQuestionnaireDetail(questionnaireDetail, status) {
    var templateHtml = $('#questionnaireDetailTemplate').html();
    // show 必須 label
    var required = '';
    if (questionnaireDetail.mandatory_flag == '1') {
        required = '<span class="required" aria-required="true">必須</span>';
    }
    // show input
    var content = createQuestionnaireDetailInput(questionnaireDetail.input_type, JSON.parse(questionnaireDetail.input_format), questionnaireDetail.id, status, 'questionnaireDetail');
    templateHtml = templateHtml.replaceAll('__index__', questionnaireDetail.id)
            .replace('__label__', (questionnaireDetail.label_name == null ? '' : questionnaireDetail.label_name))
            .replace('__required__', required)
            .replace('__input__', content)
            .replace('__sort__', questionnaireDetail.sort)
            ;
    return templateHtml;
}
/**
 * 削除
 */
function deleteQuestionnaireDetail(e) {
    e.preventDefault();
    showLoading();
    // delete error message
    $('.detail-error-msg').text('');
    var deleteBtn = $(this);
    var id = deleteBtn.data('index');
    var hostname = window.location.origin;
    var url = hostname + $('#deleteQuestionnaireDetailLink').val();
    var options = {
        url: url,
        type: 'POST',
        dataType: 'json',
        data: {
            id: id
        }
    };
    var doneFunction = function(res) {
        if (res.code !== 200) {
            $('#detail-error-'+id).text(res.message);
            hideLoading();
            return false;
        }
        // delete questionnaire detail
        $('#detail-'+id).remove();
        if ($.inArray(res.data.input_type, onlyOneRecord) > -1) {
            $('#add-record-'+res.data.mast_questionnaire_id).removeClass('btn-disable');
        }
        hideLoading();
    };
    var failFunction = function(jqxhr, textStatus, error) {
        hideLoading();
    };
    // call ajax
    $.ajax(options)
        .done(doneFunction)
        .fail(failFunction);
}
function createQuestionnaireDetailInput(inputType, inputFormat, index, status, showType) {
    // status = 'disable';
    var content = '';
    // 1:氏名, 2:カナ
    if ($.inArray(inputType, [1, 2]) > -1) {
        content = createMultiTextbox(inputFormat, 'multi-text', status);
    }
     // 3:住所
    if (inputType == 3) {
        content = createAddressInput(inputFormat, status);
    }
    // 4: 電話番号(携帯), 5: 携帯番号
    if($.inArray(inputType, [4, 5]) > -1){
        content = createTextbox(inputFormat.first, 'tel', status);
    }
    // 6:birth
    if($.inArray(inputType, [6]) > -1){
        content = createTextbox(inputFormat, 'date', status);
    }
    // 7: 性別
    if($.inArray(inputType, [7]) > -1){
        content = createRadio(index, inputFormat, status);
    }
    // 8: marriage
    if($.inArray(inputType, [8]) > -1){
        content = createMarriageInput(inputFormat, status);
    }
    // 9: job
    if($.inArray(inputType, [9]) > -1){
        content = createJobInput(inputFormat, status);
    }
    // 10:email, 11:text, 12: number
    if ($.inArray(inputType, [10, 11, 12]) > -1) {
        content = createTextbox(inputFormat, 'text', status);
    }
    // 13:radio, 14:check, 15:select
    if (showType == 'questionnaire') {
        if ($.inArray(inputType, [13, 14, 15]) > -1) {
            content = createSpecialInput(inputFormat, index, status);
        }
    }
    if (showType == 'questionnaireDetail') {
        // 13:radio
        if ($.inArray(inputType, [13]) > -1) {
            content = createRadio(index, inputFormat, status);
        }
        // 14:check
        if($.inArray(inputType, [14]) > -1) {
            content = createCheckbox(inputFormat, status);
        }
        // 15:select
        if($.inArray(inputType, [15]) > -1) {
            content = createSelect(inputFormat, status);
        }
    }
    // 16:title
    if($.inArray(inputType, [16]) > -1) {
        content = createTitle(inputFormat);
    }
    // 17:textarea
    if($.inArray(inputType, [17]) > -1) {
        content = createTextArea(inputFormat, status);
    }
    return content;
}
// load summernote
loadSummernoteEditor('detail-description', 'formA009');
/**
 * Scroll to form ticket
 */
function scrollToFormTicket() {
    $('html,body').animate({
        scrollTop: $('#form-input-ticket').offset().top
    }, 500);
}
/**
 * Clear form event ticket
 */
function clearFormTicket() {
    $('#form-input-ticket').each(function() {
        $(this).find('input:text, input[type="number"]').val('').prop('disabled', false);
        $(this).find('input[type="radio"]').prop('disabled', false);
        $(this).find('[name="number_disp"]').filter('[value='+NUMBER_DISP_VAL.YES+']').prop('checked', true);
        $(this).find('[name="e_ticket"]').filter('[value='+E_TICKET_VAL.NO+']').prop('checked', true);
        $(this).find('[name="usage_limit"]').filter('[value='+USAGE_LIMIT_VAL.NO_LIMITED+']').prop('checked', true);
        $(this).find('[name="free_shipping"]').prop('checked', false);
        $(this).find('select').each(function() {
            var optVal = $(this).find('option:first').val();
            $(this).val(optVal);
            $(this).trigger('change');
            $(this).prop('disabled', false);
        });
        if($(this).find(':input').hasClass('error-message')) {
            $(this).find(':input').removeClass('error-message');
            $(this).find(':input').closest('div').find('.error-message').remove();
        }
        //disable if paymentFlag = 0
        var paymentFlagCheck = $('[name="payment_flag_check"]').val();
        if(paymentFlagCheck == NO_PAYMENT_FLAG) {
            //価格
            $(this).find('#unit-price').prop('disabled', true);
            $(this).find('#unit-price').val(0);
            //送料を無料にする
            $(this).find('#free_shipping_hidden').val(FREE_SHIPPING_VAL.NO_SHIPPING);
            $(this).find('#free-shipping').prop('disabled', true);
            $(this).find('#free-shipping').prop('checked', true);
            $(this).find('#free-shipping').css('cursor', 'not-allowed');
        }
    });
}

/**
 * Function callback. Show result latitude and longitude from address
 *
 * @param result
 */
function showResultLatitudeLongitude(result) {
    var latitude = $('#latitude'),
        longitude = $('#longitude');
    if(!isEmpty(result)) {
        var latitudeResult = result.geometry.location.lat(),
            longitudeResult = result.geometry.location.lng();
        latitude.val(latitudeResult);
        longitude.val(longitudeResult);
    } else {
        latitude.val('');
        longitude.val('');
    }
}

/**
 * Get latitude and longitude. Library Geocoding api from Places api of google maps
 *
 * @param address
 * @param callback
 */
function getLatitudeLongitude(address, callback) {
    if(!isEmpty(address)) {
        var geocoder = new google.maps.Geocoder();
        if (geocoder) {
            geocoder.geocode({'address': address}, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    callback(results[0]);
                } else {
                    callback(null);
                }
            });
        }
    } else {
        callback(null);
    }
}
