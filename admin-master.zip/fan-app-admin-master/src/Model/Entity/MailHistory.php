<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * MailHistory Entity
 *
 * @property int $id
 * @property \Cake\I18n\FrozenTime $send_time
 * @property string|null $mail_from
 * @property string|null $subject
 * @property int|null $mail_template
 * @property string|null $send_to_file
 * @property int $del_flg
 * @property int|null $created_by
 * @property \Cake\I18n\FrozenTime|null $created_at
 * @property int|null $updated_by
 * @property \Cake\I18n\FrozenTime|null $updated_at
 * @property int|null $deleted_by
 * @property \Cake\I18n\FrozenTime|null $deleted_at
 */
class MailHistory extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'send_time' => true,
        'mail_from' => true,
        'subject' => true,
        'mail_template' => true,
        'mail_content' => true,
        'send_to_file' => true,
        'del_flg' => true,
        'created_by' => true,
        'created_at' => true,
        'updated_by' => true,
        'updated_at' => true,
        'deleted_by' => true,
        'deleted_at' => true
    ];
}
