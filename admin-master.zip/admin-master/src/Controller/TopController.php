<?php
/**
 * Created by PhpStorm.
 * User: dat.tnt
 * Date: 2019/10/23
 * Time: 12:24
 */
namespace App\Controller;

use App\Libs\ConfigUtil;
use App\Libs\ValueUtil;
use Cake\Core\Configure;
use Cake\Event\Event;
use Cake\Network\Exception\NotFoundException;
use Cake\ORM\TableRegistry;
use Cake\View\Exception\MissingTemplateException;

/**
 * Static content controller
 *
 * This controller will render views from Template/Pages/
 *
 * @link http://book.cakephp.org/3.0/en/controllers/pages-controller.html
 */
class TopController extends AppAdminController
{
    /**
     * Top screen
     */
    public function index() {
        $user = $this->Auth->user();
        $roleList = ConfigUtil::get('role');
        if(!in_array($user['role'], $roleList)){
            return $this->redirect(['controller' => 'Top', 'action' => 'permissionError']);
        }
        //Go to A008 screen
        return $this->redirect(['controller' => 'Que', 'action' => 'a008']);
    }

    /**
     * Ajax function reset search session
     *
     * @return \Cake\Http\Response
     */
    public function resetSearch() {
        if($this->getRequest()->is(['ajax'])){
            $data = $this->getRequest()->getData();
            $screenSession = $data['controller']. '.'. $data['action'];
            $session = $this->getRequest()->getSession();
            if($session->check($screenSession)){
                $session->delete($screenSession);
            }
            $this->response = $this->response->withType('json');
            $this->response = $this->response->withStringBody(json_encode(['success' => true]));
            return $this->response;
        }
    }

    /**
     * System error screen
     *
     * @return \Cake\Http\Response
     */
    public function error() {
        return $this->errorProcess('system.error');
    }

    /**
     * Permission error screen
     *
     * @return \Cake\Http\Response
     */
    public function permissionError() {

    }
}
