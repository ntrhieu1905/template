$(document).ready(function(){
    //JSでバリデーションをチェクする
    $('#frma007').validate({
        focusInvalid: true,
        rules : {
            'user_name_first': {
                required: true,
                maxlength: 24
            },
            'user_name_last': {
                required: true,
                maxlength: 24
            },
            'user_kana_first': {
                required: true,
                checkKatakana: true,
                maxlength: 24
            },
            'user_kana_last': {
                required: true,
                checkKatakana: true,
                maxlength: 24
            },
            'birthday': {
                required: true,
                datetime: true
            },
            'email': {
                required: true,
                checkValidEmailRFC: true,
                maxlength: 255,
                remote: {
                    url: $('#email_exists').val(),
                    type: 'post',
                    data: {
                        id: $('#id_fan').val(),
                        email: function () { return $('#email').val(); }
                    },
                    dataFilter: function(res) {
                        return res ? true : false;
                    }
                }
            },
            'password_edit': {
                minlength: 10,
                maxlength: 20,
                passwordRule: true
            },
            'area': {
                required: true
            },
            'mobile': {
                required: true,
                checkNumeric: true,
                maxlength: 13
            },
            'tel': {
                checkNumeric: true,
                maxlength: 13
            },
            'zip': {
                required: true,
                checkNumeric: true,
                maxlength: 7
            },
            'prefecture': {
                required: true
            },
            'city': {
                required: true,
                maxlength: 50
            },
            'address1': {
                required: true,
                maxlength: 50
            },
            'address2': {
                maxlength: 50
            },
            'job_type': {
                required: true,
                maxlength: 50
            },
            'job_type_other': {
                maxlength: 50
            },
            'working_type': {
                required: true
            },
            'working_type_other': {
                maxlength: 50
            },
            'working_area': {
                workingAreaRequired: true
            },
            'interest_other': {
                maxlength: 50
            },
            'working_company': {
                maxlength: 50
            },
            'line_name': {
                maxlength: 50
            },
            'bukatsu_free': {
                maxlength: 255
            },
            'memo': {
                maxlength: 255
            },
            'company_code': {
                maxlength: 50
            },
            'marriage': {
                required: true
            },
            'sex': {
                required: true
            }
        },
        messages : {
            'user_name_first':{
                required: function(params, input) {
                    return $.validator.messages.required($(input).data('label'));
                },
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), params, $(input).val().length]);
                }
            },
            'user_name_last':{
                required: function(params, input) {
                    return $.validator.messages.required($(input).data('label'));
                },
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), params, $(input).val().length]);
                }
            },
            'user_kana_first':{
                required: function(params, input) {
                    return $.validator.messages.required($(input).data('label'));
                },
                checkKatakana: function(params, input) {
                    return $.validator.messages.checkKatakana([$(input).data('label')]);
                },
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), params, $(input).val().length]);
                }
            },
            'user_kana_last':{
                required: function(params, input) {
                    return $.validator.messages.required($(input).data('label'));
                },
                checkKatakana: function(params, input) {
                    return $.validator.messages.checkKatakana([$(input).data('label')]);
                },
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), params, $(input).val().length]);
                }
            },
            'birthday':{
                required: function(params, input) {
                    return $.validator.messages.required($(input).data('label'));
                },
                datetime: function (params, input) {
                    return $.validator.messages.datetime($(input).data('label'));
                }
            },
            'email':{
                required: function(params, input) {
                    return $.validator.messages.required($(input).data('label'));
                },
                checkValidEmailRFC: $.validator.messages.mail_valid,
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), params, $(input).val().length]);
                },
                remote: function(params, input) {
                    return $.validator.messages.checkExistsEmail($(input).data('label'));
                }
            },
            'password_edit':{
                minlength: function(params, input) {
                    return $.validator.messages.minlength([$(input).data('label'), params, $(input).val().length]);
                },
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), params, $(input).val().length]);
                },
                passwordRule: function(params, input) {
                    return $.validator.messages.passwordRule($(input).data('label'));
                }
            },
            'area':{
                required: function(params, input) {
                    return $.validator.messages.required($(input).data('label'));
                }
            },
            'mobile':{
                required: function(params, input) {
                    return $.validator.messages.required($(input).data('label'));
                },
                checkNumeric: function(params, input) {
                    return $.validator.messages.checkNumeric($(input).data('label'));
                },
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), params, $(input).val().length]);
                }
            },
            'tel':{
                checkNumeric: function(params, input) {
                    return $.validator.messages.checkNumeric($(input).data('label'));
                },
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), params, $(input).val().length]);
                }
            },
            'zip':{
                required: function(params, input) {
                    return $.validator.messages.required($(input).data('label'));
                },
                checkNumeric: function(params, input) {
                    return $.validator.messages.checkNumeric($(input).data('label'));
                },
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), params, $(input).val().length]);
                }
            },
            'prefecture':{
                required: function(params, input) {
                    return $.validator.messages.required($(input).data('label'));
                }
            },
            'city':{
                required: function(params, input) {
                    return $.validator.messages.required($(input).data('label'));
                },
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), params, $(input).val().length]);
                }
            },
            'address1':{
                required: function(params, input) {
                    return $.validator.messages.required($(input).data('label'));
                },
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), params, $(input).val().length]);
                }
            },
            'address2':{
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), params, $(input).val().length]);
                }
            },
            'job_type':{
                required: function(params, input) {
                    return $.validator.messages.required($(input).data('label'));
                }
            },
            'working_type':{
                required: function(params, input) {
                    return $.validator.messages.required($(input).data('label'));
                }
            },
            'working_area':{
                workingAreaRequired: function(params, input) {
                    return $.validator.messages.workingAreaRequired($(input).data('label'));
                }
            },
            'job_type_other':{
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), params, $(input).val().length]);
                }
            },
            'working_type_other':{
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), params, $(input).val().length]);
                }
            },
            'interest_other':{
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), params, $(input).val().length]);
                }
            },
            'working_company':{
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), params, $(input).val().length]);
                }
            },
            'line_name':{
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), params, $(input).val().length]);
                }
            },
            'bukatsu_free':{
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), params, $(input).val().length]);
                }
            },
            'memo':{
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), params, $(input).val().length]);
                }
            },
            'company_code':{
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), params, $(input).val().length]);
                }
            },
            'marriage':{
                required: function(params, input) {
                    return $.validator.messages.required([$(input).data('label'), params, $(input).val().length]);
                }
            },
            'sex':{
                required: function(params, input) {
                    return $.validator.messages.required([$(input).data('label'), params, $(input).val().length]);
                }
            }
        },
        errorPlacement: function(error, element) {
            if ($(element).attr('name') === 'user_name_first') {
                error.appendTo($("#user_name_error").find('.error1'));
            } else if($(element).attr('name') === 'user_name_last') {
                error.appendTo($("#user_name_error").find('.error2'));
            } else if($(element).attr('name') === 'user_kana_first') {
                error.appendTo($("#user_kana_error").find('.error1'));
            } else if($(element).attr('name') === 'user_kana_last') {
                error.appendTo($("#user_kana_error").find('.error2'));
            } else if($(element).attr('name') === 'area') {
                $("#area_error").html("");
                error.appendTo($("#area_error"));
            } else if($(element).attr('name') === 'sex') {
                $("#sex_error").html("");
                error.appendTo($("#sex_error"));
            } else {
                error.insertAfter(element);
            }
        },
        submitHandler: function(form) {
            $('#btn-save-a007').attr('disabled', true);
            form.submit();
        }
    });

    //can type 職種その他 with 職種 = 99
    var job_type_other = $('[name="job_type_other"]');
    var job_type = $('[name="job_type"]');
    job_type_other.hide();
    if(job_type.val() == 99) {
        job_type_other.show();
    }
    $(job_type).on('change', function () {
        if(job_type.val() == 99) {
            job_type_other.show();
        } else {
            job_type_other.hide();
            job_type_other.val('');
            job_type_other.removeClass('error-message');
            job_type_other.closest('div').find('.error-message').remove();
        }
    });

    //can type 勤務形態その他 with 勤務形態 = 99
    var working_type_other = $('[name="working_type_other"]');
    var working_type = $('[name="working_type"]');
    working_type_other.hide();
    if(working_type.val() == 99) {
        working_type_other.show();
    }
    $(working_type).on('change', function () {
        if(working_type.val() == 99) {
            working_type_other.show();
        } else {
            working_type_other.hide();
            working_type_other.val('');
            working_type_other.removeClass('error-message');
            working_type_other.closest('div').find('.error-message').remove();
        }
    });

    //can type 興味その他 with どんなことに興味ある？ = 99
    var interest_other = $('[name="interest_other"]');
    var interest = $('[name="interest[]"]');
    interest_other.hide();
    //get all value checkbox checked of interest
    var searchIDs = $('[name="interest[]"]:checked').map(function(){
        return $(this).val();
    }).get();
    if($.inArray("99", searchIDs) !== -1) {
        interest_other.show();
    }
    $(interest).on('change', function () {
        var searchIDs = $('[name="interest[]"]:checked').map(function(){
            return $(this).val();
        }).get();
        if($.inArray("99", searchIDs) !== -1) {
            interest_other.show();
        } else {
            interest_other.hide();
            interest_other.val('');
            interest_other.removeClass('error-message');
            interest_other.closest('div').find('.error-message').remove();
        }
    });

    //get working area list by area
    getWorkingAreaList($('[name="area"]:checked').val(), $('[name="working_area_value"]').val());
    $('[name="area"]').on('change', function () {
        var area_val = $(this).val();
        getWorkingAreaList(area_val);
    });

    //get working_area list by ajax with conditions
    function getWorkingAreaList(area_val, working_area_val) {
        var url = $('[name="get_working_area_list"]').val();
        $.ajax({
            method: "POST",
            url: url,
            data: {
                area: area_val
            },
            dataType: "json",
            success: function (result) {
                var option = '<option value="">-</option>';
                $('#working_area option').remove();
                $('#working_area').append(option);
                $.each(result, function(key, val){
                    $('#working_area').append($("<option></option>").attr('value',key).text(val));
                    if(working_area_val) {
                        $('#working_area').val(working_area_val);
                    }
                });
            }
        });
    }
});