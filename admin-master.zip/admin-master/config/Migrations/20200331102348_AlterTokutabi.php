<?php
use Migrations\AbstractMigration;

class AlterTokutabi extends AbstractMigration
{
    /**
     * Change Method.
     *
     * More information on this method is available here:
     * https://book.cakephp.org/phinx/0/en/migrations.html#the-change-method
     * @return void
     */
    public function change()
    {
        $table = $this->table('tokutabi');
        $table
            ->changeColumn('end_time', 'datetime', [
                'default' => null,
                'null'    => true
            ])
            ->update();
    }
}
