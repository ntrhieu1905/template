<?php
use Migrations\AbstractMigration;

class UpdateFanv3 extends AbstractMigration
{
    /**
     * Change Method.
     *
     * More information on this method is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-change-method
     * @return void
     */
    public function change()
    {
        try {
            $table = $this->table('fan');
            $table
                ->changeColumn('used_sns', 'string', [
                    'default' => NULL,
                    'limit' => 50,
                    'null' => TRUE
                ])
                ->removeColumn('favorite_area')
                ->save();
        } catch (\Exception $ex) {
            echo ($ex->getMessage());
        }
    }
}
