<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Questionnaire Entity
 *
 * @property int $id
 * @property int $publish_flag
 * @property string $title
 * @property string|null $thumb_image
 * @property string|null $image_url1
 * @property string|null $image_url2
 * @property string|null $image_url3
 * @property string|null $description
 * @property string|null $detail_description
 * @property string|null $host_area
 * @property string|null $venue
 * @property string|null $address
 * @property string|null $latitude
 * @property string|null $longitude
 * @property int|null $map_flg
 * @property string|null $event_date
 * @property \Cake\I18n\FrozenTime $start_time
 * @property \Cake\I18n\FrozenTime $end_time
 * @property string|null $mail
 * @property string|null $phone_number
 * @property string|null $business_hour
 * @property int $application_limit
 * @property int $payment_flag
 * @property int $del_flg
 * @property int|null $created_by
 * @property \Cake\I18n\FrozenTime|null $created_at
 * @property int|null $updated_by
 * @property \Cake\I18n\FrozenTime|null $updated_at
 * @property int|null $deleted_by
 * @property \Cake\I18n\FrozenTime|null $deleted_at
 *
 * @property \App\Model\Entity\QuestionnaireDetail[] $questionnaire_detail
 * @property \App\Model\Entity\QuestionnaireResult[] $questionnaire_result
 */
class Questionnaire extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'id' => false,
        '*' => true
    ];
}
