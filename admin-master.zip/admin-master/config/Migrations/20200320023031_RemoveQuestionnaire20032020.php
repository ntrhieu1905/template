<?php
use Migrations\AbstractMigration;

class RemoveQuestionnaire20032020 extends AbstractMigration
{
    /**
     * Change Method.
     *
     * More information on this method is available here:
     * https://book.cakephp.org/phinx/0/en/migrations.html#the-change-method
     * @return void
     */
    public function change()
    {
        $table = $this->table('questionnaire');
        $table
            ->removeColumn('payment_method')
            ->removeColumn('total_no_tax')
            ->removeColumn('tax')
            ->removeColumn('total_amount')
            ->update();
    }
}
