$(document).ready(function(){
    //JSでバリデーションをチェクする
    $('.staff-form').validate({
        focusInvalid: true,
        rules : {
            'user_name': {
                required: true,
                maxlength: 50
            },
            'email': {
                required: true,
                maxlength: 255,
                checkValidEmailRFC: true,
                remote: {
                    url: $('#email_exists').val(),
                    type: 'post',
                    data: {
                        id: $('#id_staff').val(),
                        email: function () { return $('#email').val(); }
                    },
                    dataFilter: function(res) {
                        return res ? true : false;
                    }
                }
            },
            'password': {
                required: true,
                minlength: 10,
                maxlength: 20,
                passwordRule: true
            },
            'password_edit': {
                minlength: 10,
                maxlength: 20,
                passwordRule: true
            },
            'user_flg': {
                required: true
            },
            'area': {
                required: true
            }
        },
        messages : {
            'user_name':{
                required: function(params, input) {
                    return $.validator.messages.required($(input).data('label'));
                },
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), params, $(input).val().length]);
                }
            },
            'email':{
                required: function(params, input) {
                    return $.validator.messages.required($(input).data('label'));
                },
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), params, $(input).val().length]);
                },
                checkValidEmailRFC: $.validator.messages.mail_valid,
                remote: function(params, input) {
                    return $.validator.messages.checkExistsEmail($(input).data('label'));
                }
            },
            'password':{
                required: function(params, input) {
                    return $.validator.messages.required($(input).data('label'));
                },
                minlength: function(params, input) {
                    return $.validator.messages.minlength([$(input).data('label'), params, $(input).val().length]);
                },
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), params, $(input).val().length]);
                },
                passwordRule: function(params, input) {
                    return $.validator.messages.passwordRule($(input).data('label'));
                }
            },
            'password_edit':{
                minlength: function(params, input) {
                    return $.validator.messages.minlength([$(input).data('label'), params, $(input).val().length]);
                },
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), params, $(input).val().length]);
                },
                passwordRule: function(params, input) {
                    return $.validator.messages.passwordRule($(input).data('label'));
                }
            },
            'user_flg':{
                required: function(params, input) {
                    return $.validator.messages.required($(input).data('label'));
                }
            },
            'area':{
                required: function(params, input) {
                    return $.validator.messages.required($(input).data('label'));
                }
            }
        }
    });
    //Fix submit button not working at A004 screen
    if ($('#id_staff').val() != '') {
        $('#email').focus();
        $('#email').blur();
    }
});
