<?php
use Migrations\AbstractMigration;
use Phinx\Db\Adapter\MysqlAdapter;

class UpdateQuestionnaireResultDetail extends AbstractMigration
{
    /**
     * Change Method.
     *
     * More information on this method is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-change-method
     * @return void
     */
    public function change()
    {
        try {
            $table = $this->table('questionnaire_result_detail');
            $table->removeColumn('sort')->save();
            $table
                ->addColumn('sort', 'integer', [
                    'default' => null,
                    'limit' => MysqlAdapter::INT_SMALL,
                    'null' => true
                ]);
            $table->save();
        } catch (\Exception $ex) {
            echo ($ex->getMessage());
        }
    }
}
