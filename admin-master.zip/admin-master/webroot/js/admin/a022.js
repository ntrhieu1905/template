var onlyOneRecord = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
$(document).ready(function() {
    // load summernote
    loadSummernoteEditor('description', 'formA022');
    // enter key event
    $('#part-list').keypress(enterEvent);
    $('#detail-preview').keypress(enterEvent);
    // 追加 button
    $('body').on('click', '.add-record', createQuestionnaireDetail);
    // 削除 button
    $('body').on('click', '.remove-record', deleteQuestionnaireDetail);
    // validate initialize
    $('#part-list').validate();
    // イベント参加費 not negative
    $('body').on('input', '#total_no_tax', function () {
        this.value = (this.value < 0) ? Math.abs(this.value) : this.value;
    });
    jQuery.validator.setDefaults({ ignore: "[contenteditable='true'].note-editable" });
    // validation
    $('.formA022').validate({
        focusInvalid: true,
        rules: {
            'publish_flag': {
                required: true,
            }
            ,
            'title': {
                required: true,
                maxlength: 50,
            },
            'description': {
                required: true,
                maxLengthEditor: 3000,
            },
            'start_time': {
                required: true,
                date_time: true,
                lesserThanDateNormal: true
            },
            'end_time': {
                required: true,
                date_time: true,
                greaterThanDateNormal: true
            }
        },
        messages: {
            'publish_flag': {
                required: $.validator.messages.required('公開／非公開'),
            },
            'title': {
                required: $.validator.messages.required('タイトル'),
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength(['タイトル', 50, $(input).val().length]);
                }
            },
            'description': {
                required: $.validator.messages.required('説明文'),
                maxLengthEditor: function(params, input) {
                    return $.validator.messages.maxLengthEditor(['説明文', params, checkMaxLength($(input).val())]);
                },
            },
            'start_time': {
                required: function(params, input) {
                    return $.validator.messages.required('公開日時');
                },
                date_time: $.validator.messages.date_time('公開日時'),
                lesserThanDateNormal: function(params, input) {
                   return $.validator.messages.lesserThanDateNormal(['終了日時', $(input).data('label')]);
                }
            },
            'end_time': {
                required: function(params, input) {
                    return $.validator.messages.required('終了日時');
                },
                date_time: $.validator.messages.date_time('終了日時'),
                greaterThanDateNormal: function(params, input) {
                    return $.validator.messages.greaterThanDateNormal([$(input).data('label'), '公開日時']);
                }
            }
        },
        errorPlacement: function(error, element) {
            //Show error message
            if(element.attr('name') === 'publish_flag') {
                error.appendTo($(element).parent().parent().parent());
            } else {
                error.appendTo($(element).parent());
            }
        },
        submitHandler: function(form) {
            $('#submit-a022-btn').attr('disabled', true);
            form.submit();
        }
    });
    // パーツリスト validation
    $('#part-list').validate({
        focusInvalid: true,
        ignore: []
    });
    // 公開フラグ
    var status = $('#statusFlg').val();
    var questionnaireDetailDiv = $('#questionnaireDetail');
    if (status == 'enable') {
        // sortable
        $("#sortable").sortable();
        $("#sortable").disableSelection();
    }
    // show パーツリスト
    var $dropFields = $("#mastQuestionnaireData");
    var details = $dropFields.data('details');
    if (details) {
        $.each(details, function(index, mastQuestionnaireDetail) {
            var $dropElement = buildElement(index, mastQuestionnaireDetail, status);
            $dropElement.appendTo('#mastQuestionnaire');
            // validation
            $dropElement.find('.labelInput').rules('add', {
                maxlength: 255,
                messages: {
                    maxlength: function(params, input) {
                        return $.validator.messages.maxlength(['ラベル名', 255, $(input).val().length]);
                    }
                }
            });
        });
        getPrefectureList();
        getMarriageList();
        getJobList();
        $('.datepicker').datepicker();
    }

    // show 申込フォームプレビュー
    var questionnaireDetailData = $('#questionnaireDetailData').data('details');
    if (questionnaireDetailData) {
        $.each(questionnaireDetailData, function(index, questionnaireDetail) {
            var element = showQuestionnaireDetail(questionnaireDetail, status);
            questionnaireDetailDiv.append(element);
            if (status == 'enable') {
                questionnaireDetailDiv.sortable();
            }
        });
        $('.datepicker').datepicker();
    }

    if (status == 'enable') {
        questionnaireDetailDiv.sortable({
            axis: 'y',
            update: function (event, ui) {
                if (status == 'disable') {
                    return false;
                }
                // show loading
                showLoading();
                // get data
                var data = $(this).sortable('serialize');
                // get url
                var hostname = window.location.origin;
                var url = hostname + $('#updateSortTokutabiDetailLink').val();
                var options = {
                    data: data,
                    type: 'POST',
                    url: url
                };
                var doneFunction = function (res) {
                    hideLoading();
                };
                var failFunction = function () {
                    hideLoading();
                };
                // POST to server using $.post or $.ajax
                $.ajax(options)
                    .done(doneFunction)
                    .fail(failFunction);
            }
        });
    }

});

// enter event
function enterEvent(e) {
    if (e.which == 13) {
        e.preventDefault();
    }
}

// Replace all function
String.prototype.replaceAll = function(search, replacement) {
    var target = this;
    return target.replace(new RegExp(search, 'g'), replacement);
};

/**
 * CREATE ELEMENT
 *
 * [input type]
 * 1:name       2:kana
 * 3:address    4:tel
 * 5:mobile     6:birth
 * 7:sex        8:job
 * 9:email      10:text
 * 11:number    12:radio
 * 13:check     14:select
 * 15:title     16:textarea
 */
function buildElement(index, questionnaireDetail, status) {
    var dropElement =  buildHTML(index, questionnaireDetail, status);
    var $dropElement = $(dropElement);
    var inputType = questionnaireDetail.input_type;

    return $dropElement;
}

/**
 * CREATE HTML ELEMENT FROM OPTION
 */
function buildHTML(newIndex, questionnaireDetail, status) {
    var id          = questionnaireDetail.id,
        inputType   = questionnaireDetail.input_type,
        labelName   = questionnaireDetail.label_name,
        mandatoryFlag     = questionnaireDetail.mandatory_flag,
        inputFormat = JSON.parse(questionnaireDetail.input_format)
    ;
    var templateHtml = $('#template').html();
    // create 入力形式
    var content = createQuestionnaireDetailInput(inputType, inputFormat, id, status, 'questionnaire');
    // ラベル名
    var labelEditInput = '';
    var errorDiv = '';
    // validate one record
    if ($.inArray(inputType, onlyOneRecord) > -1) {
        labelEditInput = createEditInputLabel(labelName, 'labelName_' + id, 'disable');
    } else {
        labelEditInput = createEditInputLabel(labelName, 'labelName_' + id, status, true);
    }
    var inputButton = '';
    // 追加ボタン表示
    if (status == 'enable') {
        var buttonData = {
            mastQuestionnairePartsId: id,
            countQuestionnaireDetail: questionnaireDetail.tokutabi_detail.length
        };
        inputButton = createButton('add', buttonData);
    }
    // 必須 checkbox
    var requireCheckbox = createRequireCheckbox(mandatoryFlag, id, status);
    // パーツタイプ
    var label = labelName.charAt(0).toUpperCase() + labelName.slice(1);
    // create HTML
    templateHtml = templateHtml.replace('__label__', label)
        .replace('__requireCheckbox__', requireCheckbox)
        .replace('__inputLabel__', labelEditInput)
        .replace('__errorDiv__', errorDiv)
        .replace('__inputForm__', content)
        .replace('__buttonData__', inputButton);

    return templateHtml;
}

/**
 * 必須 checkbox
 */
function createRequireCheckbox(requiredFlg, index, status) {
    // add disable attribute
    var disable = '';
    if (status == 'disable') {
        disable = 'disabled';
    }
    // 必須フラグ
    var require = '';
    var html = '<input ' + disable + ' type="checkbox" id="mast_questionnaire_require_' + index + '"' + require + ' />';

    return html;
}

/**
 * create 追加 button
 */
function createButton(btnTyp, data) {
    if (data.countQuestionnaireDetail > 0) {
        var className = 'btn btn-danger bb-btn-round btn-sm add-record btn-disable';
    } else {
        var className = 'btn btn-danger bb-btn-round btn-sm add-record';
    }
    var html = "<button name='add-record' data-index='" + data.mastQuestionnairePartsId +
        "' style='margin-left:10px' class='" + className + "' data-questionnaire-parts='" +
        JSON.stringify(data) + "' type='submit' id='add-record-" + data.mastQuestionnairePartsId + "'>追加</button>";

    return html;
}

/**
 * パーツリスト - ラベル名
 */
function createEditInputLabel(labelName, inputName, status, validation = false) {
    // add disable attribute
    var disable = '';
    if (status == 'disable') {
        disable = 'disabled';
    }
    if (validation) {
        var $html = '<input ' + disable + ' type="text" name="' + inputName + '" class="form-control labelInput" value="' + labelName + '" />';
    } else {
        var $html = '<input ' + disable + ' type="text" name="' + inputName + '" class="form-control" value="' + labelName + '" />';
    }

    return $html;
}

function showValidateMessage(validate, type) {
    var html = '';
    if (typeof validate !== "undefined" && validate.length > 0) {
        if ((type == 'text' || type == 'multi-text' || type == 'tel' || type == 'address') && validate[0].maxlength) {
            html += '<p class="small-txt">最大' + nvl(validate[0].maxlength) + '文字</p>';
        }
        if (type == 'number' && validate[0].maxlength) {
            html += '<p class="small-txt">数字' + nvl(validate[0].maxlength) + '文字</p>';
        }
    }

    return html;
}

/**
 * パーツリスト: 13:radio, 14:check, 15:select
 */
function createSpecialInput(format, index, status) {
    var html = '';
    // add disable attribute
    var disable = '';
    if (status == 'disable') {
        disable = 'disabled';
    }
    // create input
    html += '<div>';
    html += '<input ' + disable + ' name="input_option_' + index + '"' + ' class="form-control"' + ' value=' + format.options.join() + '>';
    html += '</div>';

    return html;
}

/**
 * 住所
 */
function createAddressInput(format, status) {
    var html = '';
    var disable = '';
    if (status == 'disable') {
        disable = 'disabled';
    }
    html += '<div class="float-left width-100-p">';
    html += createTextbox(format.first, 'address', status);
    html += '<div class="options float-left width-50-p mg-5 ' +  nvl(format.class) + '"' + '>';
    html += '<select ' + disable + ' class="form-control prefectureList">';
    html += '<option value="">-</option>';
    html += '</select><p class="small-txt">&nbsp;</p>';
    html += '</div>';
    html += '</div></div><div class="float-left width-100-p">';
    html += createTextbox(format.third, 'address', status);
    html += createTextbox(format.fourth, 'address', status);
    html += '</div><div class="float-left width-100-p">';
    html += createTextbox(format.fifth, 'address', status);
    html += '</div>';

    return html;
}

/**
 * create 職種 in パーツリスト
 */
function createJobInput(format, status) {
    var html = '';
    var disable = '';
    if (status == 'disable') {
        disable = 'disabled';
    }
    html += '<div class="float-left width-100-p mg-5">';
    html += '<select ' + disable + ' class="form-control jobList">';
    html += '<option value="">-</option>';
    html += '</select>';
    html += '</div>';

    return html;
}

/**
 * create あなたは結婚していますか？ in パーツリスト
 */
function createMarriageInput(format, status) {
    var html = '';
    var disable = '';
    if (status == 'disable') {
        disable = 'disabled';
    }
    html += '<div class="float-left width-100-p mg-5">';
    html += '<select ' + disable + ' class="form-control marriageList">';
    html += '<option value="">-</option>';
    html += '</select>';
    html += '</div>';
    return html;
}

// get prefectures list by ajax
function getPrefectureList(format, status) {
    var options = {
        url: $('#getPrefectureUrl').val(),
        type: 'GET',
        dataType: 'json',
        data: {}
    };
    var doneFunction = function(res) {
        var prefectures = res.data;
        var html = '<option value="">-</option>';
        // create option
        $.each(prefectures, function (idx, text) {
            html += '<option value="' + text + '">' + text + '</option>';
        });
        $('.prefectureList option').remove();
        $('.prefectureList').each(function() {
            $(this).append(html);
        });
    };
    var failFunction = function() {

    };
    $.ajax(options)
        .done(doneFunction)
        .fail(failFunction);
}

// get jobs list by ajax
function getJobList(format, status) {
    var options = {
        url: $('#getJobsUrl').val(),
        type: 'GET',
        dataType: 'json',
        data: {}
    };
    var doneFunction = function(res) {
        var jobs = res.data;
        var html = '<option value="">-</option>';
        // create option
        $.each(jobs, function (idx, text) {
            html += '<option value="' + text + '">' + text + '</option>';
        });
        $('.jobList option').remove();
        $('.jobList').each(function() {
            $(this).append(html);
        });
    };
    var failFunction = function() {

    };
    $.ajax(options)
        .done(doneFunction)
        .fail(failFunction);
}

// get marriage list by ajax
function getMarriageList(format, status) {
    var options = {
        url: $('#getMarriagesUrl').val(),
        type: 'GET',
        dataType: 'json',
        data: {}
    };
    var doneFunction = function(res) {
        var marriages = res.data;
        var html = '<option value="">-</option>';
        // create option
        $.each(marriages, function (idx, text) {
            html += '<option value="' + text + '">' + text + '</option>';
        });
        $('.marriageList option').remove();
        $('.marriageList').each(function() {
            $(this).append(html);
        });
    };
    var failFunction = function() {};
    $.ajax(options)
        .done(doneFunction)
        .fail(failFunction);
}

/**
 * CREATE TEXT INPUT
 */
function createTextbox(format, type, status) {
    var html = '';
    var width = 'width-100-p';
    var datePicker = '';
    if (type == 'date') {
        width = 'width-50';
        datePicker = 'datepicker';
    } else if (type == 'address' || type == 'multi-text' || type == 'tel') {
        width = 'width-50-p';
    } else if (type == 'tel') {
        width = 'width-auto';
    }
    html += '<div class="float-left ' + width + ' mg-5">';
    // add disable attribute
    var disable = '';
    if (status == 'disable') {
        disable = 'disabled';
    }
    // create validate attribute
    var validationAttr = '';
    if ($.type(format.validate) == 'string') {
        validationAttr = validateAttr(format.validate);
    }
    if ($.type(format.validate) == 'array') {
        $.each(format.validate, function(key, value) {
            validationAttr = validateAttr(value);
        });
    }
    // create input
    html += '<input ' + disable + ' class="form-control ' + datePicker + ' ' +  nvl(format.class) + '"' + validationAttr + ' size="' + nvl(format.size) + '" placeholder=' + nvl(format.placeholder) + '>';
    if (type !== 'date') {
        html += showValidateMessage(format.validate, type);
    }
    html += '</div>';

    return html;
}

/**
 * CREATE MULTI TEXT INPUT
 */
function createMultiTextbox(format, type, status) {
    var html = '';
    $.each(format, function (idx, elementFormat) {
        html += createTextbox(elementFormat, type, status);
    });
    return html;
}

/**
 * CREATE TEXTAREA INPUT
 */
function createTextArea(format, status) {
    // add disable attribute
    var disable = '';
    if (status == 'disable') {
        disable = 'disabled';
    }
    var html = '';
    html += '<div>';
    html += '<textarea ' + disable + ' class="form-control "' +  validateAttr(format.validate) +  '></textarea>';
    // show validate message
    html += showValidateMessage(format.validate, 'text');
    html += '</div>';

    return html;
}

/**
 * CREATE RADIO INPUT
 */
function createRadio(newIndex, format, status) {
    // add disable attribute
    var disable = '';
    if (status == 'disable') {
        disable = 'disabled';
    }
    var html = '<div class="radio options "' + nvl(format.class) + ' data-value="' + format.options.join("\n") + '">';
    $.each(format.options, function (idx, text) {
        html += '<label class="radio-inline"> ' +
            '<input type="radio" ' + disable + ' name="radioName' + newIndex + '" value="' + text.replace(/(<([^>]+)>)/ig,"") + '"> ' +
            text.replace(/(<([^>]+)>)/ig,"") +
            '</label>';
    });
    html += '</div>';

    return html;
}

/**
 * CREATE CHECKBOX INPUT
 */
function createCheckbox(format, status) {
    // add disable attribute
    var disable = '';
    if (status == 'disable') {
        disable = 'disabled';
    }
    var html = '<div class="checkbox options ' +  + nvl(format.class) + '" data-value="' + format.options.join("\n") + '">';
    $.each(format.options, function (idx, text) {
        html += '<label class="checkbox-inline bb-checkbox">' +
            '<input ' + disable + ' type="checkbox" value="' + text.replace(/(<([^>]+)>)/ig,"") + '">' +
            '<span class="bb-ui"></span> ' +
            text.replace(/(<([^>]+)>)/ig,"") +
            '</label>';
    });
    html += '</div>';

    return html;
}

/**
 * CREATE SELECT INPUT
 */
function createSelect(format, status) {
    // add disable attribute
    var disable = '';
    if (status == 'disable') {
        disable = 'disabled';
    }
    var html = '<div class="options ' +  nvl(format.class) + '"' + '>';
    html += '<select ' + disable + ' class="form-control">';
    html += '<option value="">-</option>';
    $.each(format.options, function (idx, text) {
        html += '<option value="' + text + '">' + text + '</option>';
    });
    html += '</select>';
    html += '</div>';

    return html;
}

/**
 * CREATE LABEL
 */
function createTitle(format) {
    return '<div class="' + nvl(format.class) +'">' + nvl(format.text) + '</div>';
}

/**
 * CREATE VALIDATE FOR INPUT
 */
function validateAttr(option) {
    var str = '';
    return str;
}

/**
 * Prevent null
 */
function nvl(param, defaultValue) {
    if(defaultValue == null){
        defaultValue = '';
    }
    return param || defaultValue;
}

/**
 * 追加ボタン
 */
function createQuestionnaireDetail(e) {
    e.preventDefault();
    var addBtn = $(this);
    if (addBtn.hasClass('btn-disable')) {
        return false;
    }
    var data = addBtn.data('questionnaire-parts');
    var id = addBtn.data('index');
    data.labelName = $('input[name=labelName_'+id+']').val();
    if (data.labelName.length > 255) {
        return false;
    }
    showLoading();
    // create require label
    var required = '';
    if ($('#mast_questionnaire_require_'+id+':checkbox:checked').length > 0) {
        required = 'required';
    }
    data.required = required;
    // get input option value
    var inputOption = $('input[name=input_option_' + id + ']');
    if (inputOption.length > 0) {
        data.options = inputOption.val();
    }
    // get url
    var hostname = window.location.origin;
    var url = hostname + $('#createTokutabiDetailLink').val();
    var options = {
        url: url,
        type: 'POST',
        dataType: 'json',
        data: data
    };

    var doneFunction = function(res) {
        if (res.code !== 200) {
            hideLoading();
            // show error message
            return false;
        }
        // show questionnaire detail
        var questionnaireDetail = showQuestionnaireDetail(res.data);
        $('#questionnaireDetail').append(questionnaireDetail);
        $('#questionnaireDetail').sortable();
        var inputType = res.data.input_type;
        if ($.inArray(inputType, onlyOneRecord) > -1) {
            $('#add-record-'+id).addClass('btn-disable');
        }
        // 住所
        if (inputType == 3) {
            getPrefectureList();
        }
        // あなたは結婚していますか？
        if (inputType == 8) {
            getMarriageList();
        }
        // 職業
        if (inputType == 9) {
            getJobList();
        }

        // 生年月日
        if (inputType == 6) {
            $('.datepicker').datepicker();
        }
        addBtn.blur();
        hideLoading();
    };
    var failFunction = function(jqxhr, textStatus, error) {
        hideLoading();
    };
    // call ajax
    $.ajax(options)
        .done(doneFunction)
        .fail(failFunction);
}

function showQuestionnaireDetail(questionnaireDetail, status) {
    var templateHtml = $('#questionnaireDetailTemplate').html();
    // show 必須 label
    var required = '';
    if (questionnaireDetail.mandatory_flag == '1') {
        required = '<span class="required" aria-required="true">必須</span>';
    }
    // show input
    var content = createQuestionnaireDetailInput(questionnaireDetail.input_type, JSON.parse(questionnaireDetail.input_format), questionnaireDetail.id, status, 'questionnaireDetail');
    templateHtml = templateHtml.replaceAll('__index__', questionnaireDetail.id)
        .replace('__label__', (questionnaireDetail.label_name == null ? '' : questionnaireDetail.label_name))
        .replace('__required__', required)
        .replace('__input__', content)
        .replace('__sort__', questionnaireDetail.sort)
    ;

    return templateHtml;
}

/**
 * 削除
 */
function deleteQuestionnaireDetail(e) {
    e.preventDefault();
    showLoading();
    // delete error message
    $('.detail-error-msg').text('');
    var deleteBtn = $(this);
    var id = deleteBtn.data('index');
    var hostname = window.location.origin;
    var url = hostname + $('#deleteTokutabiDetailLink').val();
    var options = {
        url: url,
        type: 'POST',
        dataType: 'json',
        data: {
            id: id
        }
    };
    var doneFunction = function(res) {
        if (res.code !== 200) {
            $('#detail-error-'+id).text(res.message);
            hideLoading();
            return false;
        }
        // delete questionnaire detail
        $('#detail-'+id).remove();
        if ($.inArray(res.data.input_type, onlyOneRecord) > -1) {
            $('#add-record-'+res.data.mast_questionnaire_id).removeClass('btn-disable');
        }
        hideLoading();
    };
    var failFunction = function(jqxhr, textStatus, error) {
        hideLoading();
    };
    // call ajax
    $.ajax(options)
        .done(doneFunction)
        .fail(failFunction);
}

function createQuestionnaireDetailInput(inputType, inputFormat, index, status, showType) {
    // status = 'disable';
    var content = '';
    // 1:氏名, 2:カナ
    if ($.inArray(inputType, [1, 2]) > -1) {
        content = createMultiTextbox(inputFormat, 'multi-text', status);
    }
    // 3:住所
    if (inputType == 3) {
        content = createAddressInput(inputFormat, status);
    }
    // 4: 電話番号(携帯), 5: 携帯番号
    if($.inArray(inputType, [4, 5]) > -1){
        content = createTextbox(inputFormat.first, 'tel', status);
    }
    // 6:birth
    if($.inArray(inputType, [6]) > -1){
        content = createTextbox(inputFormat, 'date', status);
    }
    // 7: 性別
    if($.inArray(inputType, [7]) > -1){
        content = createRadio(index, inputFormat, status);
    }
    // 8: marriage
    if($.inArray(inputType, [8]) > -1){
        content = createMarriageInput(inputFormat, status);
    }
    // 9: job
    if($.inArray(inputType, [9]) > -1){
        content = createJobInput(inputFormat, status);
    }
    // 10:email, 11:text, 12: number
    if ($.inArray(inputType, [10, 11, 12]) > -1) {
        content = createTextbox(inputFormat, 'text', status);
    }
    // 13:radio, 14:check, 15:select
    if (showType == 'questionnaire') {
        if ($.inArray(inputType, [13, 14, 15]) > -1) {
            content = createSpecialInput(inputFormat, index, status);
        }
    }
    if (showType == 'questionnaireDetail') {
        // 13:radio
        if ($.inArray(inputType, [13]) > -1) {
            content = createRadio(index, inputFormat, status);
        }
        // 14:check
        if($.inArray(inputType, [14]) > -1) {
            content = createCheckbox(inputFormat, status);
        }
        // 15:select
        if($.inArray(inputType, [15]) > -1) {
            content = createSelect(inputFormat, status);
        }
    }
    // 16:title
    if($.inArray(inputType, [16]) > -1) {
        content = createTitle(inputFormat);
    }
    // 17:textarea
    if($.inArray(inputType, [17]) > -1) {
        content = createTextArea(inputFormat, status);
    }

    return content;
}
