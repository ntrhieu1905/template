<?php
/**
 * Created by PhpStorm.
 * User: dat.tnt
 * Date: 2019/10/23
 * Time: 12:24
 */
namespace App\Controller;

use App\Libs\ConfigUtil;
use App\Libs\ExportDataUtil;
use App\Libs\ValueUtil;
use App\Libs\DateUtil;
use Cake\Event\Event;
use Cake\ORM\TableRegistry;

/**
 * Reserve_history content controller
 */
class ResController extends AppAdminController
{
    /**
     * Override beforeFilter callback
     *
     * @return \Cake\Network\Response|null|void
     */
    public function beforeFilter(Event $event) {
        parent::beforeFilter($event);
        //Load common model
        $this->loadModel('ReserveHistory');
    }

    /**
     * A012 予約申込一覧
     * A012
     */
    public function a012() {
        //Get login user data
        $session = $this->getRequest()->getSession();
        //Check searching data session
        $params = [];
        if($session->check('Res.a012')) {// when have session
            $params = $session->read('Res.a012');
            $this->set([
                'searchData' => $params,
            ]);
        }
        // Process after submit
        if ($this->getRequest()->is(['post'])) {
            $searchData = $this->getRequest()->getData();
            //Write session
            $session->delete('Res.a012');
            $session->write('Res.a012', $searchData);
            // Reload page
            return $this->redirect(['action' => 'a012']);
        }
        //Get records from database then paginate result
        $result = $this->ReserveHistory->search($params);
        $reserves = $this->paginate($result, ['limit' => ConfigUtil::get('paginate.ten_pages')]);
        //Show list evaluation
        $this->set(compact('reserves'));
        $this->set('_serialize', ['reserves']);
    }

    /**
     * export Csv
     */
    public function exportCsv() {
        if ($this->getRequest()->is(['post'])) {
            $params = $this->getRequest()->getData();
            //Get records from database then paginate result
            $reserves = $this->ReserveHistory->search($params)->toArray();
            //get header
            $header = ValueUtil::get('res.header_csv');
            $listReserves = [];
            $listReserves[] = $header;
            foreach ($reserves as $res) {
                $arrData = [];
                $res['shop_id'] = !empty($res['shop_id']) ? $res['shop_id'] : '';
                $res['shop_name'] = !empty($res['shop_name']) ? $res['shop_name'] : '';
                $res['mem_id'] = !empty($res['mem_id']) ? $res['mem_id'] : '';
                $res['rsv_date'] = !empty($res['rsv_date']) ? DateUtil::getJapaneseDate($res['rsv_date']) : '';
                $res['rsv_count'] = !empty($res['rsv_count']) ? $res['rsv_count'] : '';
                $res['rsv_course_price'] = !empty($res['rsv_course_price']) ? $res['rsv_course_price'].'円' : '';
                $res['in_tsp'] = !empty($res['in_tsp']) ? DateUtil::getJapaneseDate($res['in_tsp'], false, true) : '';
                //add column name to csv
                foreach ($header as $colName => $colTitle) {
                    $arrData[$colName] = !empty($res[$colName]) ? $res[$colName] : '';
                }
                $listReserves[] = $arrData;
            }
            // Csv file name
            $fileName = 'A012_' . DateUtil::getFileNameByCurrentTime() . '.csv';
            // execute export csv
            $exportData = new ExportDataUtil();
            $exportData->exportCSV($listReserves, $fileName);
        }
    }
}
