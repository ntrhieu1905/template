$(document).ready(function () {
    // validate
    $('#a021').validate({
        ignore: [],
        focusInvalid: true,
        rules: {
            'tokutabi_date_create': {
                date: true,
            },
        },
        messages: {
            'tokutabi_date_create': {
                date: function(params, input) {
                    return $.validator.messages.date('作成日');
                },
            },
        }
    });
});
