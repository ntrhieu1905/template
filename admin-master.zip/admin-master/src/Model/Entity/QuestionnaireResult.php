<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * QuestionnaireResult Entity
 *
 * @property int $id
 * @property int|null $questionnaire_id
 * @property int|null $fan_id
 * @property int|null $payment_method
 * @property int|null $total_no_tax
 * @property int|null $tax
 * @property int|null $total_amount
 * @property string|null $credit_token
 * @property int|null $winning_flg
 * @property \Cake\I18n\FrozenTime|null $receive_date
 * @property string|null $memo
 * @property int $del_flg
 * @property int|null $created_by
 * @property \Cake\I18n\FrozenTime|null $created_at
 * @property int|null $updated_by
 * @property \Cake\I18n\FrozenTime|null $updated_at
 * @property int|null $deleted_by
 * @property \Cake\I18n\FrozenTime|null $deleted_at
 *
 * @property \App\Model\Entity\Questionnaire $questionnaire
 * @property \App\Model\Entity\Fan $fan
 * @property \App\Model\Entity\QuestionnaireResultDetail[] $questionnaire_result_detail
 */
class QuestionnaireResult extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'questionnaire_id' => true,
        'fan_id' => true,
        'payment_method' => true,
        'total_no_tax' => true,
        'tax' => true,
        'total_amount' => true,
        'credit_token' => true,
        'winning_flg' => true,
        'receive_date' => true,
        'memo' => true,
        'del_flg' => true,
        'created_by' => true,
        'created_at' => true,
        'updated_by' => true,
        'updated_at' => true,
        'deleted_by' => true,
        'deleted_at' => true,
        'questionnaire' => true,
        'fan' => true,
        'questionnaire_result_detail' => true
    ];
}
