<?php
/**
 * Created by PhpStorm.
 * User: dat.tnt
 * Date: 10/10/2019
 * Time: 19:35
 */
namespace App\Controller;

use App\Libs\ConfigUtil;
use Cake\Console\ShellDispatcher;
use Cake\Datasource\ConnectionManager;
use Cake\Event\Event;
use Cake\Log\Log;
use Cake\ORM\TableRegistry;
use App\Libs\ValueUtil;
use Cake\Http\Client;

class AppAdminController extends AppController
{
    protected $connection;

    public $helpers = array(
        'AdminView',
    );

    public function initialize() {
        parent::initialize();
        //Load component to check user permission
        $this->loadComponent('Auth', [
            'authorize' => ['Controller'], // Added this line
            'loginAction' => [
                'controller' => 'Log',
                'action' => 'login',
            ],
            'loginRedirect' => [
                'controller' => 'Que',
                'action' => 'a008',
            ],
            'logoutRedirect' => [
                'controller' => 'Log',
                'action' => 'login',
            ],
            'authenticate' => [
                'Form' => [
                    'fields' => [
                        'username' => 'email',
                        'password' => 'password'
                    ],
                    'userModel' => 'Staff',
                    'finder' => 'auth',
                    /*'passwordHasher' => [
                        'className' => 'AdminLegacy',
                    ]*/
                ]
            ],
            'authError' => ''
        ]);
        $this->set('session',$this->getRequest()->getSession()); #Set for all Views
        //Set connection
        $this->connection = ConnectionManager::get('default');
    }

    /**
     * Basic firewall
     *
     * @param $user
     * @return bool
     */
    public function isAuthorized($user) {
        // Get controller and action parameter
        $controller = $this->getRequest()->getParam('controller');
        $action = $this->getRequest()->getParam('action');
        // Get firewall setting
        $firewallList = ConfigUtil::get('firewall');
        if($user === null || empty($user['role'])){
            $firewall  = $firewallList['DEFAULT'];
        }else{
            $role = $user['role'];
            $firewall = $firewallList[$role];
        }
        //Check screen permission
        if($firewall && array_key_exists($controller, $firewall)){
            if($firewall[$controller] === null || in_array($action, $firewall[$controller])){
                return true;
            } else {
                //Redirect to error page
                return $this->redirect(['controller' => 'Top', 'action' => 'permissionError']);
            }
        }
        //If can't go to page, redirect to error page
        return $this->redirect(['controller' => 'Top', 'action' => 'permissionError']);
    }

    /**
     * Override beforeRender callback
     *
     * @param \Cake\Event\Event $event The beforeRender event.
     * @return \Cake\Network\Response|null|void
     */
    public function beforeRender(Event $event) {
        parent::beforeRender($event);
        $this->viewBuilder()->setLayout('admin');
    }

    /**
     * Override beforeFilter callback
     *
     * @return \Cake\Network\Response|null|void
     */
    function beforeFilter(Event $event) {
        parent::beforeFilter($event);
        $user = $this->Auth->user();
        if($user){
            // 物件数・会員数を取得
            $this->set(compact('user'));
        }
        //Set param to view
        $this->set('secure_server', ConfigUtil::get('SECURE_SERVER'));
    }

    /**
     * Get role name of a user
     *
     * @param $user
     * @return string
     */
    protected function getRole($user) {
        if(!$user){
            return null;
        }
        //Get list of roles
        $roleList = ConfigUtil::get('role');
        if(empty($roleList[$user['role_name']])){
            return null;
        } else {
            return $roleList[$user['role_name']];
        }
    }

    /**
     * Override function paginate
     *
     * @param null $object
     * @param array $settings
     * @return mixed
     */
    public function paginate($object = null, array $settings = []) {
        if(!isset($settings['limit'])){
            $limit = $this->getRequest()->getQuery('limit');
            $paginateMenu = ConfigUtil::get('paginate_menu');
            if($limit && in_array($limit, $paginateMenu)){
                $settings['limit'] = $limit;
            } else {
                $settings['limit'] = ConfigUtil::get('paginate.default');
            }
        }
        //Process pagigation
        return parent::paginate($object, $settings);
    }

    /**
     * Error process for error screen
     * @param $errorKey
     * @param $redirect
     * @return \Cake\Network\Response|null
     */
    public function errorProcess($errorKey, $redirect = null) {
        $session = $this->getRequest()->getSession();
        $message =  ConfigUtil::getMessage('system_error');
        // Get error message
        if($session->check($errorKey)){
            $error = $session->read($errorKey);
            $session->delete($errorKey);
            if(isset($error['message'])){
                $message = $error['message'];
            } else {
                $error['message'] = $message;
            }
            // Write log
            Log::error(print_r($error, true));
            $this->set(compact('error', 'message'));
            return null;
        }
        if($redirect != null){
            return $this->redirect($redirect);
        }
        $this->set(compact('message'));
        return null;
    }

    /**
     * Delete session key or array of session key
     *
     * @param string|array $sessionKeys Session key
     */
    public function deleteSession($sessionKeys) {
        $session = $this->getRequest()->getSession();
        if(is_string($sessionKeys)){
            $session->delete($sessionKeys);
        }
        if(is_array($sessionKeys)){
            foreach ($sessionKeys as $key){
                $session->delete($key);
            }
        }
    }

    /**
     * Redirect after delete a record
     *
     * @param string $action action key
     * @return \Cake\Http\Response|null
     */
    public function redirectAfterDelete($action) {
        //If delete last record in a page, redirect to previous page
        $page = $this->getRequest()->getQuery('page');
        $limit = $this->getRequest()->getQuery('limit');
        if($limit){
            if(empty($page)){
                return $this->redirect(['action' => $action]);
            } else {
                return $this->redirect(['action' => $action . '?page=' . $page . '&limit=' . $limit]);
            }
        }
        //Redirect to previous page
        return $this->redirect($this->referer());
    }

    function xssClean($data) {
        // Fix &entity\n;
        $data = str_replace(array('&amp;','&lt;','&gt;'), array('&amp;amp;','&amp;lt;','&amp;gt;'), $data);
        $data = preg_replace('/(&#*\w+)[\x00-\x20]+;/u', '$1;', $data);
        $data = preg_replace('/(&#x*[0-9A-F]+);*/iu', '$1;', $data);
        $data = html_entity_decode($data, ENT_COMPAT, 'UTF-8');
        // Remove any attribute starting with "on" or xmlns
        $data = preg_replace('#(<[^>]+?[\x00-\x20"\'])(?:on|xmlns)[^>]*+>#iu', '$1>', $data);
        // Remove javascript: and vbscript: protocols
        $data = preg_replace('#([a-z]*)[\x00-\x20]*=[\x00-\x20]*([`\'"]*)[\x00-\x20]*j[\x00-\x20]*a[\x00-\x20]*v[\x00-\x20]*a[\x00-\x20]*s[\x00-\x20]*c[\x00-\x20]*r[\x00-\x20]*i[\x00-\x20]*p[\x00-\x20]*t[\x00-\x20]*:#iu', '$1=$2nojavascript...', $data);
        $data = preg_replace('#([a-z]*)[\x00-\x20]*=([\'"]*)[\x00-\x20]*v[\x00-\x20]*b[\x00-\x20]*s[\x00-\x20]*c[\x00-\x20]*r[\x00-\x20]*i[\x00-\x20]*p[\x00-\x20]*t[\x00-\x20]*:#iu', '$1=$2novbscript...', $data);
        $data = preg_replace('#([a-z]*)[\x00-\x20]*=([\'"]*)[\x00-\x20]*-moz-binding[\x00-\x20]*:#u', '$1=$2nomozbinding...', $data);
        // Only works in IE: <span style="width: expression(alert('Ping!'));"></span>
        $data = preg_replace('#(<[^>]+?)style[\x00-\x20]*=[\x00-\x20]*[`\'"]*.*?expression[\x00-\x20]*\([^>]*+>#i', '$1>', $data);
        $data = preg_replace('#(<[^>]+?)style[\x00-\x20]*=[\x00-\x20]*[`\'"]*.*?behaviour[\x00-\x20]*\([^>]*+>#i', '$1>', $data);
        $data = preg_replace('#(<[^>]+?)style[\x00-\x20]*=[\x00-\x20]*[`\'"]*.*?s[\x00-\x20]*c[\x00-\x20]*r[\x00-\x20]*i[\x00-\x20]*p[\x00-\x20]*t[\x00-\x20]*:*[^>]*+>#iu', '$1>', $data);
        // Remove namespaced elements (we do not need them)
        $data = preg_replace('#</*\w+:\w[^>]*+>#i', '', $data);
        do
        {
            // Remove really unwanted tags
            $old_data = $data;
            $data = preg_replace('#</*(?:applet|b(?:ase|gsound|link)|embed|frame(?:set)?|i(?:frame|layer)|l(?:ayer|ink)|meta|object|s(?:cript|tyle)|title|xml)[^>]*+>#i', '', $data);
        }
        while ($old_data !== $data);
        return $data;
    }

    /**
     * Process to break link in html string
     *
     * @param string $html
     * @return string
     */
    public function breakLine($html) {
        return str_replace('<br />', "\n", $html);
    }

    /**
     * Set errors to session to display in view
     *
     * @param array $errors
     * @return \Cake\Http\Response|null
     */
    public function showErrors($errors) {
        $errorMessages = $this->errorMessageProcess($errors);
        $this->Flash->set('', [
            'element' => 'errors',
            'params' => ['errors' => $errorMessages]
        ]);
    }

    /**
     * Validate date
     *
     * @param string $date
     * @return boolean
     */
    public function validDate($date) {
        if(!empty($date)){
            $iTimestamp = strtotime($date);
            if($iTimestamp >= 0 && false !== $iTimestamp){
                return true;
            } else {
                return false;
            }
        }
        return true;
    }

    /**
     * Process error messages
     *
     * @param array $errors
     * @return array
     */
    public function errorMessageProcess($errors) {
        $values = array_values($errors);
        $errorMessages = [];
        foreach($values as $error){
            foreach($error as $item){
                if(is_array($item)){
                    foreach($item as $endItem){
                        $errorMessages[] = $endItem;
                    }
                } else {
                    $errorMessages[] = $item;
                }
            }
        }
        return $errorMessages;
    }

    /**
     * Check login user
     * If user_flag = 5, set user partner_company_id to parameter
     *
     * @param array $params
     * @return array
     */
    public function checkLoginWithUserFlag($params = []) {
        $loginUser   = $this->Auth->user();
        $roles       = ValueUtil::get('user.user_role');
        //if user_flag = 5
        if($loginUser['user_flg'] == $roles['PARTNER']) {
            $params['partner_company_id'] = $loginUser['partner_company_id'];
        }
        return $params;
    }

    /**
     * Function call api to convert zipcode to address
     *
     * @return string
     */
    public function getZipcode() {
        $zipCode = $this->getRequest()->getQuery('zip_code');
        $http = new Client();
        // Simple get
        $url = ConfigUtil::get('api_zipcode').$zipCode;
        $response = $http->get($url);
        $address = "";
        if(!empty($response->getBody())){
            $result = json_decode($response->getBody(), true);
            $data = $result['results'][0];
            $address = [
                'city' => $data['address2'],
                'prefecture' => $data['prefcode'],
                'address' => $data['address3']
            ];
        }
        echo json_encode($address);
        exit();
    }

    /**
     * Function run batch with params
     *
     * @param string $batchName batch name
     * @param array $params
     * @return bool
     */
    public function runBatch($batchName, $params = []) {
        $shell = new ShellDispatcher();
        $output = $shell->run(['cake', $batchName], $params);

        return 0 === $output;
    }

	/**
	 * Function valid params on det
	 *
	 * @param string $params1 $params2
	 * @return bool
	 */
	public function validParamIdsOnDet($params1 , $params2){
		if(empty($params1) || empty($params2)){
			return false;
		}
		if(!ctype_digit($params1) || !ctype_digit($params2)) {
			return false;
		}
		return true;
	}

    public function __get($name) {
        if ($this->loadModel($name)) {
            return $this->$name;
        }
        return null;
    }

    /**
     * get prefecture list
     *
     * @return \Cake\Http\Response
     */
    public function getPrefectureList() {
        $prefectures = ValueUtil::get('fan.prefecture');
        $this->returnForAjax('success', 'create', '', $prefectures);
    }

    /**
     * get job list
     *
     * @return \Cake\Http\Response
     */
    public function getJobList() {
        $jobs = ValueUtil::get('fan.job_type');
        $this->returnForAjax('success', 'create', '', $jobs);
    }

    /**
     * get marriage list
     *
     * @return \Cake\Http\Response
     */
    public function getMarriageList() {
        $marriages = ValueUtil::get('fan.marriage');
        $this->returnForAjax('success', 'create', '', $marriages);
    }

    /**
     * check id tokutabi
     * @param null $tokutabiId
     * @return bool
     */
    public function checkTokutabi($tokutabiId = null, $checkSurveyType = null) {
        try {
            //Check valid Id
            if (empty($tokutabiId) || !is_numeric($tokutabiId)) {
                return false;
            }
            //get data of tokutabi
            $tokutabi = $this->Tokutabi->getTokutabiById($tokutabiId, $checkSurveyType);
            if (empty($tokutabi)) {
                return false;
            }
            return $tokutabi;
        } catch (\Exception $e) {
            return false;
        }
    }
    /**
     * Get the url page in the mail body
     * $url_screen = controller/screen
     * @param null $fan
     * @param null $url_screen
     * @return string
     */
    public function getUrlTemplate($fan = null, $url_screen = null) {
        $request_uri_honban = $_SERVER['REQUEST_URI'];
        $request_uri_config = ConfigUtil::get('REQUEST_URI_USER');
        $uri = '/';
        if(strpos($request_uri_honban, $request_uri_config) !== false) {
            $uri = $request_uri_config;
        }
        //set domain name in release environment
        $host = $_SERVER['HTTP_HOST'];
        if(strcmp($_SERVER['HTTP_HOST'], '54.238.226.185') === 0) {
            $host = 'nasse-club.com';
        }
        if (!empty($fan)) {
            $url = ($this->getRequest()->scheme() == "https" ? "https" : "http") . "://" .$host. $uri . $url_screen . '/' . $fan['auth_code'];
        } else {
            $url = ($this->getRequest()->scheme() == "https" ? "https" : "http") . "://" .$host . $uri . $url_screen;
        }
        return $url;
    }
}
