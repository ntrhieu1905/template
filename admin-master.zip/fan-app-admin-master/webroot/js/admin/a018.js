$(document).ready(function () {

    // validation
    $('#a018').validate({
        ignore: [],
        focusInvalid: true,
        rules: {
            'start_date': {
                datetime: true,
            },
            'end_date': {
                datetime: true,
            },
        },
        messages: {
            'start_date': {
                datetime: $.validator.messages.datetime('公開日時'),
            },
            'end_date': {
                datetime: $.validator.messages.datetime('終了日時'),
            },
        },
        onfocusout: function(element) {
            this.element(element);
        },
        submitHandler: function(form) {
            $('#form-btn-018').attr('disabled', true);
            form.submit();
        }
    });
   $('.csv-export-mail').click(function () {
       let idMail = '#csv-export-' + $(this).data('id');
       $(idMail).click();
   });
});
