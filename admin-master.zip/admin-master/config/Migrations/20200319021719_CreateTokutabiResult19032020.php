<?php
use Migrations\AbstractMigration;
use Phinx\Db\Adapter\MysqlAdapter;

class CreateTokutabiResult19032020 extends AbstractMigration
{
    /**
     * Change Method.
     *
     * More information on this method is available here:
     * https://book.cakephp.org/phinx/0/en/migrations.html#the-change-method
     * @return void
     */
    public function change()
    {
        $table = $this->table('tokutabi_result', [
            'id' => false,
            'primary_key' => 'id',
            'encoding' => 'utf8',
            'collation' => 'utf8_general_ci'
        ]);
        $table
            ->addColumn('id', 'biginteger', [
                'identity' => true
            ])
            ->addColumn('tokutabi_id', 'biginteger', [
                'default' => null,
                'null'    => true,
            ])
            ->addColumn('fan_id', 'biginteger', [
                'default' => null,
                'null'    => true,
            ])
            ->addColumn('memo1', 'string', [
                'default' => null,
                'null'    => true,
                'limit' => 255
            ])
            ->addColumn('memo2', 'string', [
                'default' => null,
                'null'    => true,
                'limit' => 255
            ])
            ->addColumn('memo3', 'string', [
                'default' => null,
                'null'    => true,
                'limit' => 255
            ])
            ->addColumn('created_by', 'biginteger', [
                'default' => null,
                'null'    => true
            ])
            ->addColumn('created_at', 'datetime', [
                'default' => null,
                'null'    => true
            ])
            ->addColumn('updated_by', 'biginteger', [
                'default' => null,
                'null'    => true
            ])
            ->addColumn('updated_at', 'datetime', [
                'default' => null,
                'null'    => true
            ])
            ->addColumn('deleted_by', 'biginteger', [
                'default' => null,
                'null'    => true
            ])
            ->addColumn('deleted_at', 'datetime', [
                'default' => null,
                'null'    => true
            ])
            ->addForeignKey('tokutabi_id', 'tokutabi', 'id')
            ->addForeignKey('fan_id', 'fan', 'id')
            ->create();
    }
}
