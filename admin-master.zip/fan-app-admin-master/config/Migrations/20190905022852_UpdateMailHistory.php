<?php
use Migrations\AbstractMigration;
use Phinx\Db\Adapter\MysqlAdapter;

class UpdateMailHistory extends AbstractMigration
{
    /**
     * Change Method.
     *
     * More information on this method is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-change-method
     * @return void
     */
    public function change()
    {
        try {
            $table = $this->table('mail_history');
            $table
                ->addColumn('mail_content', 'text', [
                    'default' => null,
                    'after' => 'mail_template',
                    'limit' => MysqlAdapter::INT_SMALL,
                    'null' => true
                ])
                ->save();
        }
        catch (\Exception $ex) {
            echo ($ex->getMessage());
        }

    }
}
