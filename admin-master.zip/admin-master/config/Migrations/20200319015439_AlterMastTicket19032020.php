<?php
use Migrations\AbstractMigration;
use Phinx\Db\Adapter\MysqlAdapter;

class AlterMastTicket19032020 extends AbstractMigration
{
    /**
     * Change Method.
     *
     * More information on this method is available here:
     * https://book.cakephp.org/phinx/0/en/migrations.html#the-change-method
     * @return void
     */
    public function change()
    {
        $table = $this->table('mast_ticket');
        $table
            ->addColumn('questionnaire_id', 'biginteger', [
                'default' => null,
                'null' => true,
                'after' => 'id',
            ])
            ->addColumn('ticket_type', 'integer', [
                'default' => 0,
                'null' => false,
                'limit' => MysqlAdapter::INT_TINY,
                'after' => 'questionnaire_id',
            ])
            ->addColumn('number_disp', 'integer', [
                'default' => 1,
                'null' => false,
                'limit' => MysqlAdapter::INT_TINY,
                'after' => 'number',
            ])
            ->addColumn('total_number', 'integer', [
                'default' => null,
                'null' => false,
                'after' => 'number_disp',
            ])
            ->addColumn('e_ticket', 'integer', [
                'default' => 0,
                'null' => false,
                'limit' => MysqlAdapter::INT_TINY,
                'after' => 'total_number',
            ])
            ->addColumn('usage_limit', 'integer', [
                'default' => 0,
                'null' => false,
                'limit' => MysqlAdapter::INT_TINY,
                'after' => 'e_ticket',
            ])
            ->addColumn('lower_limit', 'integer', [
                'default' => 1,
                'null' => false,
                'after' => 'usage_limit',
            ])
            ->addColumn('upper_limit', 'integer', [
                'default' => null,
                'null' => true,
                'after' => 'lower_limit',
            ])
            ->addColumn('exp_from', 'datetime', [
                'default' => null,
                'null'    => true,
                'after' => 'upper_limit'
            ])
            ->addColumn('exp_to', 'datetime', [
                'default' => null,
                'null'    => true,
                'after' => 'exp_from'
            ])
            ->addForeignKey('questionnaire_id', 'questionnaire', 'id')
            ->update();
    }
}
