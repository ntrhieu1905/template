<?php
namespace App\Model\Table;

use App\Libs\ConfigUtil;
use App\Libs\ValueUtil;
use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Tokutabi Model
 *
 * @property \App\Model\Table\TokutabiDetailTable&\Cake\ORM\Association\HasMany $TokutabiDetail
 * @property \App\Model\Table\TokutabiResultTable&\Cake\ORM\Association\HasMany $TokutabiResult
 * @property \App\Model\Table\TokutabiResultDetailTable&\Cake\ORM\Association\HasMany $TokutabiResultDetail
 *
 * @method \App\Model\Entity\Tokutabi get($primaryKey, $options = [])
 * @method \App\Model\Entity\Tokutabi newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Tokutabi[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Tokutabi|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Tokutabi saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Tokutabi patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Tokutabi[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Tokutabi findOrCreate($search, callable $callback = null, $options = [])
 */
class TokutabiTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('tokutabi');
        $this->setDisplayField('title');
        $this->setPrimaryKey('id');

        $this->hasMany('TokutabiDetail', [
            'foreignKey' => 'tokutabi_id',
        ]);
        $this->hasMany('TokutabiResult', [
            'foreignKey' => 'tokutabi_id',
        ]);
        $this->hasMany('TokutabiResultDetail', [
            'foreignKey' => 'tokutabi_id',
        ]);
        $this->addBehavior('UpdateSync');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->allowEmptyString('id', null, 'create');

        $validator
            ->scalar('title')
            ->notEmptyString('title', ['message' => ConfigUtil::getMessage('ECL001', ['タイトル'])])
            ->add('title', 'max-length', [
                'rule' => function ($value, $context) {
                    $len = mb_strlen($value);
                    if($len > 50) {
                        return ConfigUtil::getMessage("ECL002", ["タイトル", 50, $len]);
                    }
                    return true;
                }
            ]);

        $validator
            ->scalar('description')
            ->notEmptyString('description', ['message' => ConfigUtil::getMessage('ECL001', ['説明文'])])
            ->add('description', 'max-length', [
                'rule' => function ($value, $context) {
                    $length = ValueUtil::countCharacters($value);
                    if($length > 3000) {
                        return ConfigUtil::getMessage("ECL002", ["説明文", 3000, $length]);
                    }
                    return true;
                }
            ]);
        $validator
            ->requirePresence('publish_flag', 'create')
            ->notEmptyString('publish_flag', ConfigUtil::getMessage("ECL001", ["公開/非公開"]));

        $validator
                ->notEmptyString('start_time', ConfigUtil::getMessage("ECL001", ["公開日時"]))
                ->add('start_time', 'datetime', [
                    'rule' => 'datetime',
                    'message' => ConfigUtil::getMessage("ECL014", ["公開日時"])
                ]);

        $validator
            ->notEmptyString('end_time', ConfigUtil::getMessage("ECL001", ["終了日時"]))
            ->add('end_time', [
                'datetime' => [
                    'rule' => 'datetime',
                    'message' => ConfigUtil::getMessage("ECL014", ["終了日時"]),
                ]])
            ->add('end_time',[
                'greaterThanDate' => [
                    'rule' => function($value, $context) {
                        $startTime = !empty($context['data']['start_time']) ? $context['data']['start_time'] : '';
                        $endTime = !empty($context['data']['end_time']) ? $context['data']['end_time'] : '';
                        if($endTime < $startTime) {
                            return ConfigUtil::getMessage("ECL036", ["終了日時", "公開日時"]);
                        }
                        return true;
                    }
                ]
            ]);;

        $validator
            ->requirePresence('survey_type', 'create')
            ->notEmptyString('survey_type');

        $validator
            ->scalar('hash_url')
            ->allowEmptyString('hash_url');

        $validator
            ->notEmptyString('del_flg');

        $validator
            ->allowEmptyString('created_by');

        $validator
            ->dateTime('created_at')
            ->allowEmptyDateTime('created_at');

        $validator
            ->allowEmptyString('updated_by');

        $validator
            ->dateTime('updated_at')
            ->allowEmptyDateTime('updated_at');

        $validator
            ->allowEmptyString('deleted_by');

        $validator
            ->dateTime('deleted_at')
            ->allowEmptyDateTime('deleted_at');

        return $validator;
    }

    /**
     * Search tokutabi
     *
     * @param array $params
     * @return array|Query|null
     */
    public function search($params = []) {
        try {
            $query = $this->find()
                ->select([
                    'Tokutabi.id', 'Tokutabi.title',
                    'Tokutabi.publish_flag', 'Tokutabi.created_at', 'staff.area'])
                ->join([
                    'table'      => 'staff',
                    'alias'      => 'staff',
                    'type'       => 'LEFT',
                    'conditions' => 'staff.id = Tokutabi.created_by'
                ])
                ->where(['Tokutabi.del_flg' => ValueUtil::constToValue('common.deleted_flg.NOT_DELETED')])
                ->andWhere(['Tokutabi.survey_type' => ValueUtil::constToValue('tok.survey_type_val.special_survey')])
                ->andWhere(['Tokutabi.deleted_at IS NULL']);
            if (count($params) > 0) {
                // タイトル
                if (strlen($params['title']) > 0) {
                    $ticketName = $params['title'] . '%';
                    $query->andWhere(['Tokutabi.title LIKE ' => $ticketName]);
                }
                // 公開／非公開
                if (!empty($params['publish_flag'])) {
                    $query->andWhere(['Tokutabi.publish_flag IN ' => $params['publish_flag']]);
                }
                // 作成日
                if (strlen($params['tokutabi_date_create']) > 0) {
                    $query->andWhere("DATE_FORMAT(Tokutabi.created_at, '%Y/%m/%d') ='" . $params['tokutabi_date_create']."'");
                }
                // 登録担当者エリア
                if (is_numeric($params['staff_area'])) {
                    $query->andWhere(["staff.area" => $params['staff_area']]);
                }
            }
            $query->order([
                'Tokutabi.created_at DESC'
            ]);
            return $query;
        } catch (\Exception $e) {
            return null;
        }
    }

    /**
     * get data tokutabi
     *
     * @param $id
     * @return \App\Model\Entity\Fan|bool
     */
    public function getTokutabiById($id = null, $checkSurveyType = null) {
        try {
            $result = $this->find()
                ->where([
                    'id' => $id,
                    'del_flg' => ValueUtil::constToValue('common.deleted_flg.NOT_DELETED'),
                    'deleted_at IS NULL'
                ]);
            if (!is_null($checkSurveyType)) {
                $result->andWhere(['survey_type' => $checkSurveyType]);
            }
            return $result->first();
        } catch (\Exception $e) {
            return null;
        }
    }

    /**
     * Search tokutabi
     * Get: - Tokutabi: id, title, publish_flag, created_at, hash_url
     *      - Staff: area
     * @param array $params
     * @return array|Query|null
     */
    public function searchA026($params = []) {
        try {
            $surveyTypeVal = ValueUtil::get('sur.survey_type_val');
            $query = $this->find()
                ->select([
                    'Tokutabi.id', 'Tokutabi.title',
                    'Tokutabi.publish_flag', 'Tokutabi.created_at',
                    'Tokutabi.hash_url' , 'staff.area'])
                ->join([
                    'table'      => 'staff',
                    'alias'      => 'staff',
                    'type'       => 'LEFT',
                    'conditions' => 'staff.id = Tokutabi.created_by'
                ])
                ->where(['Tokutabi.del_flg' => ValueUtil::constToValue('common.deleted_flg.NOT_DELETED')])
                ->andWhere(['Tokutabi.deleted_at IS NULL'])
                ->andWhere(['Tokutabi.survey_type' => $surveyTypeVal['question_survey']]);
            if (count($params) > 0) {
                // タイトル
                if (strlen($params['title']) > 0) {
                    $ticketName = $params['title'] . '%';
                    $query->andWhere(['Tokutabi.title LIKE ' => $ticketName]);
                }
                // 公開／非公開
                if (!empty($params['publish_flag'])) {
                    $query->andWhere(['Tokutabi.publish_flag IN ' => $params['publish_flag']]);
                }
                // 作成日
                if (strlen($params['tokutabi_date_create']) > 0) {
                    $query->andWhere("DATE_FORMAT(Tokutabi.created_at, '%Y/%m/%d') ='" . $params['tokutabi_date_create']."'");
                }
                // 登録担当者エリア
                if (is_numeric($params['staff_area'])) {
                    $query->andWhere(["staff.area" => $params['staff_area']]);
                }
            }
            $query->order([
                'Tokutabi.created_at DESC'
            ]);
            return $query;
        } catch (\Exception $e) {
        return null;
        }
    }
    /**
     *  get last id tokutabi
     *  use in (A027)
     * @return |null
     */
    public function getLastIdBeforeInsert() {
        try {
            $query = $this->find()->select(['id'])->last();
            return $query->id;
        } catch (\Exception $e) {
            return null;
        }
    }

}
