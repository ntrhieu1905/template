$(document).ready(function () {
    //check valid
    $('#a020').validate({
        ignore: [],
        focusInvalid: true,
        rules : {
            'subject' : {
                required: true,
                maxlength: 100
            },
            'mail_content' : {
                required: true,
                maxlength: 2000
            },
            'send_time' : {
                required: true,
                datetime: true,
                greaterThanDateSendTime: true,
            }
        },
        messages : {
            'subject': {
                required: function (params, input) {
                    return $.validator.messages.required($(input).data('label'));
                },
                maxlength: function (params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), params, $(input).val().length]);
                }
            },
            'mail_content': {
                required: function (params, input) {
                    return $.validator.messages.required($(input).data('label'));
                },
                maxlength: function (params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), params, $(input).val().length]);
                }
            },
            'send_time': {
                required: function (params, input) {
                    return $.validator.messages.required($(input).data('label'));
                },
                datetime: function (params, input) {
                    return $.validator.messages.datetime($(input).data('label'));
                },
                greaterThanDateSendTime: function (params, input) {
                    return $.validator.messages.greaterThanDateSendTime($(input).data('label'));
                }
            }
        },
        submitHandler: function (form) {
            $('#from-btn-020').attr('disabled', true);
            form.submit();
        }
    });
    // call ajax to get template for fields subject, mail_content
    $('#select_template').click(function () {
       // Call ajax
        $.ajax({
            method: "POST",
            url: $(this).data('url'),
            data: {
                'option' : $('#mail_template').val(),
                'paymentFlag' : $('#payment_flag').val(),
                'questTitle' : $('#quest_title').val(),
            },
            dataType: "json",
            success: function (data) {
                $('#subject').val(data.subject).removeClass('error-message');
                $('#mail_content').val(data.content).removeClass('error-message');
                $('#subject-error').remove();
                $('#mail_content-error').remove();
            }
        });
    });
    // export CSV
    $('#csv-export-mail-tmp').click(function () {
        $('#csv-export-history').click();
    });
});
