<?php
/**
 * Created by PhpStorm.
 * User: leminhtoan
 * Date: 3/27/17
 * Time: 14:36
 */

namespace App\Model\Behavior;


use App\Libs\ConfigUtil;
use Cake\Datasource\EntityInterface;
use Cake\Event\Event;
use Cake\ORM\Behavior;
use Cake\Http\Session;

class UpdateSyncBehavior extends Behavior
{
    /**
     * Before update event
     *
     * @param Event $event
     * @param EntityInterface $entity
     * @param \ArrayObject $options the options passed to the save method
     */
    public function beforeSave(Event $event, EntityInterface $entity, \ArrayObject $options) {
        $now = new \DateTime();
        $session = new Session();
        $user = $session->read('Usr.info');
        $userId = isset($user['id']) ? $user['id'] : "";

        if($entity->isNew()){
            // Insert
            $entity->set('created_at', $now);
            if ($userId !== null && $entity->get('created_by') === null) {
                $entity->set('created_by', $userId);
            } 
            
            $entity->set('updated_at', $now);
            if ($userId !== null) {
                $entity->set('updated_by', $userId);
            } 
        } else {
            if(empty($entity->get('deleted_by')) && empty($entity->get('deleted_at'))){
                // Update
                $entity->set('updated_at', $now);
                if ($event->getSubject()->getAlias() != 'JobManager') {
                    if($userId !== null){
                        $entity->set('updated_by', $userId);
                    }
                }
            }
        }
    }

}