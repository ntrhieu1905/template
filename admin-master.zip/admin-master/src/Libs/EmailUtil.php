<?php

/**
 * Created by PhpStorm.
 * User: Briswell_User
 * Date: 12/09/2019
 * Time: 14:25 PM
 */
namespace App\Libs;

use Cake\Log\Log;
use SendGrid;
use Cake\Mailer\Email;


class EmailUtil
{
    /**
     * send all mail with sendgrid
     * @param $listFan
     * @return int|mixed
     * @throws \SendGrid\Mail\TypeException
     */
    public function sendSmtpMail($listFan, $param, $timeStart = null)
    {
        $fromMail = ConfigUtil::get('from_mail');
        $fromName = ConfigUtil::get('from_name');
        $subject = $param['subject'];
        try {
            foreach ($listFan as $fan) {
                if (empty($fan))continue;
                $content = $param['mail_content'];
                $content = preg_replace("/\r\n|\r|\n/", '<br/>', $content);
                $fan_email = $fan->email;
                $user_name = $fan->user_name;
                //replace ●● by data
                $content = str_replace('●●様', $user_name.'様', $content);
                if($param['mail_template'] == 'A011') {
                    $questId = $listFan['questionnaire']['id'];
                    $ordId = $fan['order']['id'];
                    $content = str_replace('●●●●に関し', $listFan['questionnaire']['title'].'に関し', $content);
                    $content = str_replace('「●●●●●●」', '「'.$listFan['questionnaire']['title'].'」', $content);
                    $content = str_replace('●●●●円', !empty($fan['order']['total_no_tax']) ? number_format($fan['order']['total_no_tax']).'円' : '0円', $content);
                    $content = str_replace($listFan['url_temp'],$listFan['url_event']. "$questId/$ordId", $content);
                }
                $sendgridEmailer = new Email('sendgrid');
                $sendgridEmailer->setFrom($fromMail,$fromName);
                if($timeStart != null){
                    $json = \json_encode(["send_at" => $timeStart]);
                    $header = [
                        "x-smtpapi" => $json
                    ];
                    $sendgridEmailer->setHeaders($header);
                }
                $sendgridEmailer->setTo($fan_email,$user_name);
                $sendgridEmailer->setEmailFormat("html");
                $sendgridEmailer->setSubject($subject);
                $sendgridEmailer->send($content);
            }
        } catch (\Exception $e) {
            Log::error('Send Mail - with error ' . $e->getMessage());
        }
    }
    
    /**
     * send mail with sendgrid
     * @param $listFan
     * @return int|mixed
     * @throws \SendGrid\Mail\TypeException
     */
    public function sendMail($listFan, $param, $timeStart = null)
    {
        //switch using X-SMTPAPI
        $this->sendSmtpMail($listFan, $param, $timeStart);
    }
}
