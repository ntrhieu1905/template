<?php
use Migrations\AbstractMigration;

class AlterTicketManager30032020 extends AbstractMigration
{
    /**
     * Change Method.
     *
     * More information on this method is available here:
     * https://book.cakephp.org/phinx/0/en/migrations.html#the-change-method
     * @return void
     */
    public function change()
    {
        $table = $this->table('ticket_manager');
        $table
            ->renameColumn('order_id', 'order_items_id')
            ->update();
    }
}
