<?php
use Migrations\AbstractMigration;
use Phinx\Db\Adapter\MysqlAdapter;

class CreateTokutabi19032020 extends AbstractMigration
{
    /**
     * Change Method.
     *
     * More information on this method is available here:
     * https://book.cakephp.org/phinx/0/en/migrations.html#the-change-method
     * @return void
     */
    public function change()
    {
        $table = $this->table('tokutabi', [
            'id' => false,
            'primary_key' => 'id',
            'encoding' => 'utf8',
            'collation' => 'utf8_general_ci'
        ]);
        $table
            ->addColumn('id', 'biginteger', [
                'identity' => true
            ])
            ->addColumn('title', 'string', [
                'default' => null,
                'null'    => true,
                'limit' => 50
            ])
            ->addColumn('description', 'text', [
                'default' => null,
                'null'    => true
            ])
            ->addColumn('publish_flag', 'integer', [
                'default' => null,
                'null'    => false,
                'limit'   => MysqlAdapter::INT_SMALL
            ])
            ->addColumn('start_time', 'datetime', [
                'default' => null,
                'null'    => true
            ])
            ->addColumn('end_time', 'biginteger', [
                'default' => null,
                'null'    => true
            ])
            ->addColumn('survey_type', 'integer', [
                'default' => null,
                'null'    => false,
                'limit'   => MysqlAdapter::INT_TINY
            ])
            ->addColumn('hash_url', 'text', [
                'default' => null,
                'null'    => true
            ])
            ->addColumn('del_flg', 'integer', [
                'default' => 0,
                'null'    => false,
                'limit'   => MysqlAdapter::INT_TINY
            ])
            ->addColumn('created_by', 'biginteger', [
                'default' => null,
                'null'    => true
            ])
            ->addColumn('created_at', 'datetime', [
                'default' => null,
                'null'    => true
            ])
            ->addColumn('updated_by', 'biginteger', [
                'default' => null,
                'null'    => true
            ])
            ->addColumn('updated_at', 'datetime', [
                'default' => null,
                'null'    => true
            ])
            ->addColumn('deleted_by', 'biginteger', [
                'default' => null,
                'null'    => true
            ])
            ->addColumn('deleted_at', 'datetime', [
                'default' => null,
                'null'    => true
            ])
            ->create();
    }
}
