<?php
use Migrations\AbstractMigration;
use Phinx\Db\Adapter\MysqlAdapter;

class CreateTicketManager19032020 extends AbstractMigration
{
    /**
     * Change Method.
     *
     * More information on this method is available here:
     * https://book.cakephp.org/phinx/0/en/migrations.html#the-change-method
     * @return void
     */
    public function change()
    {
        $table = $this->table('ticket_manager', [
            'id' => false,
            'primary_key' => 'id',
            'encoding' => 'utf8',
            'collation' => 'utf8_general_ci'
        ]);
        $table
            ->addColumn('id', 'biginteger', [
                'identity' => true
            ])
            ->addColumn('fan_id', 'biginteger', [
                'default' => null,
                'null'    => true
            ])
            ->addColumn('ticket_id', 'biginteger', [
                'default' => null,
                'null'    => true
            ])
            ->addColumn('order_id', 'biginteger', [
                'default' => null,
                'null'    => true
            ])
            ->addColumn('used_ticket', 'integer', [
                'default' => 0,
                'null' => false,
                'limit' => MysqlAdapter::INT_TINY
            ])
            ->addColumn('created_by', 'biginteger', [
                'default' => null,
                'null'    => true
            ])
            ->addColumn('created_at', 'datetime', [
                'default' => null,
                'null'    => true
            ])
            ->addColumn('updated_by', 'biginteger', [
                'default' => null,
                'null'    => true
            ])
            ->addColumn('updated_at', 'datetime', [
                'default' => null,
                'null'    => true
            ])
            ->addColumn('deleted_by', 'biginteger', [
                'default' => null,
                'null'    => true
            ])
            ->addColumn('deleted_at', 'datetime', [
                'default' => null,
                'null'    => true
            ])
            ->addForeignKey('fan_id', 'fan', 'id')
            ->addForeignKey('ticket_id', 'mast_ticket', 'id')
            ->addForeignKey('order_id', 'order_items', 'id')
            ->create();
    }
}
