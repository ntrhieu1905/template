$(document).ready(function(){
    //JSでバリデーションをチェクする
    $('#a001').validate({
        focusInvalid: true,
        rules : {
            'email_address': {
                required: true
            },
            'password': {
                required: true
            }
        },
        messages : {
            'email_address':{
                required: function(params, input) {
                    return $.validator.messages.required($(input).data('label'));
                }
            },
            'password':{
                required: function(params, input) {
                    return $.validator.messages.required($(input).data('label'));
                }
            }
        }
    });
});