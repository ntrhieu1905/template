<?php
/**
 * Created by PhpStorm.
 * User: dat.tnt
 * Date: 27/08/2019
 * Time: 3:43 PM
 */
namespace App\Controller\Component;

use App\Libs\ValueUtil;
use Cake\Controller\Component;
use Cake\ORM\TableRegistry;
use App\Libs\ConfigUtil;
use Cake\I18n\Date;

class QueryComponent extends Component
{
    /**
     * check email exists when registration
     * @param string $table
     * @param $email
     * @param null $id
     * @return null
     */
    public function checkEmailExisted($table, $email, $id = null)
    {
        $table = TableRegistry::getTableLocator()->get($table);
        try {
            $delVal = ValueUtil::constToValue('common.deleted_flg.NOT_DELETED');
            $id = !empty($id) ? $id : '';
            $result = $table->find()
                ->where([
                    'email' => $email,
                    'del_flg' => $delVal,
                    'deleted_at IS NULL'
                ]);
            if (!empty($id)) {
                $result->andWhere(['id <>' => $id]);
            }
            return $result;
        } catch (\Exception $ex) {
            return null;
        }
    }

    /**
     * save data to table
     *
     * @return object
     */
    public function saveTable($table, $params, $id = null, $validateCustom = null) {
        $table = TableRegistry::getTableLocator()->get($table);
        try{
            if(empty($id)){
                $entity = $table->newEntity();
            } else {
                $entity = $table->get($id);
            }
            $object = $table->patchEntity(
                $entity,
                $params,
                [
                    'validate' => !empty($validateCustom) ? $validateCustom : true,
                ]
            );
            $table->getConnection()->begin();
            $result = $table->save($object);
            if($result){
                $table->getConnection()->commit();
            } else {
                $table->getConnection()->rollback();
            }
            return $object;
        } catch(\Exception $e) {
            $table->getConnection()->rollback();
            return false;
        }
    }
}
