<?php
use Migrations\AbstractMigration;
use Phinx\Db\Adapter\MysqlAdapter;

class CreateFanAppDb extends AbstractMigration
{
    /**
     * Change Method.
     *
     * More information on this method is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-change-method
     * @return void
     */
    public function change()
    {
        $table_db = [
            'fan',
            'staff',
            'questionnaire',
            'questionnaire_detail',
            'mast_questionnaire_parts',
            'questionnaire_result',
            'questionnaire_result_detail',
            'mast_ticket',
            'cart_items',
            'order',
            'order_items',
            'reserve_history',
            'mail_history'
        ];
        foreach ($table_db as $db) {

            if ($this->table($db)->exists()) {
                continue;
            }

            if ($db == 'reserve_history') {
                //reserve_history table
                $table = $this->table($db, [
                    'id' => false,
                    'primary_key' => 'rsv_log_id',
                    'encoding' => 'utf8',
                    'collation' => 'utf8_general_ci'
                ])
                    ->addColumn('rsv_log_id', 'integer', [
                        'identity' => true
                    ])
                    ->addColumn('shop_id', 'integer', [
                        'default' => null,
                        'null' => false
                    ])
                    ->addColumn('mem_id', 'integer', [
                        'default' => null,
                        'null' => true
                    ])
                    ->addColumn('rsv_date', 'timestamp', [
                        'default' => null,
                        'timezone' => false,
                        'null' => true
                    ])
                    ->addColumn('rsv_count', 'integer', [
                        'default' => null,
                        'null' => true
                    ])
                    ->addColumn('rsv_course', 'text', [
                        'default' => null,
                        'null' => true
                    ])
                    ->addColumn('rsv_coupon', 'text', [
                        'default' => null,
                        'null' => true
                    ])
                    ->addColumn('cpn_id', 'integer', [
                        'default' => null,
                        'null' => true
                    ])
                    ->addColumn('rsv_name', 'text', [
                        'default' => null,
                        'null' => true
                    ])
                    ->addColumn('rsv_kana', 'text', [
                        'default' => null,
                        'null' => true
                    ])
                    ->addColumn('rsv_company', 'text', [
                        'default' => null,
                        'null' => true
                    ])
                    ->addColumn('rsv_tel', 'text', [
                        'default' => null,
                        'null' => true
                    ])
                    ->addColumn('rsv_tel2', 'text', [
                        'default' => null,
                        'null' => true
                    ])
                    ->addColumn('rsv_email', 'text', [
                        'default' => null,
                        'null' => true
                    ])
                    ->addColumn('rsv_sex', 'integer', [
                        'default' => null,
                        'limit' => MysqlAdapter::INT_TINY,
                        'null' => true
                    ])
                    ->addColumn('rsv_remark', 'text', [
                        'default' => null,
                        'null' => true
                    ])
                    ->addColumn('in_tsp', 'timestamp', [
                        'default' => null,
                        'timezone' => false,
                        'null' => true
                    ])
                    ->addColumn('in_id', 'integer', [
                        'default' => null,
                        'null' => true
                    ])
                    ->addColumn('rsv_course_price', 'integer', [
                        'default' => null,
                        'null' => true
                    ])
                    ->addColumn('rsv_course_price_org', 'text', [
                        'default' => null,
                        'null' => true
                    ]);
            } else {
                $table = $this->table($db, [
                    'id' => false,
                    'primary_key' => 'id',
                    'encoding' => 'utf8',
                    'collation' => 'utf8_general_ci'
                ])
                    ->addColumn('id', 'biginteger', [
                        'identity' => true
                    ]);
                //fan table
                if ($db == 'fan') {
                    $table
                        ->addColumn('user_name', 'string', [
                            'default' => null,
                            'limit' => 50,
                            'null' => true
                        ])
                        ->addColumn('user_kana', 'string', [
                            'default' => null,
                            'limit' => 50,
                            'null' => true
                        ])
                        ->addColumn('birthday', 'datetime', [
                            'default' => null,
                            'null' => true
                        ])
                        ->addColumn('sex', 'integer', [
                            'default' => null,
                            'limit' => MysqlAdapter::INT_TINY,
                            'null' => true
                        ])
                        ->addColumn('email', 'string', [
                            'default' => null,
                            'limit' => 255,
                            'null' => false
                        ])
                        ->addColumn('password', 'string', [
                            'default' => null,
                            'limit' => 255,
                            'null' => true
                        ])
                        ->addColumn('access_token', 'string', [
                            'default' => null,
                            'limit' => 255,
                            'null' => true
                        ])
                        ->addColumn('access_token_expire', 'datetime', [
                            'default' => null,
                            'null' => true
                        ])
                        ->addColumn('zip', 'integer', [
                            'default' => null,
                            'null' => true
                        ])
                        ->addColumn('prefecture', 'integer', [
                            'default' => null,
                            'limit' => MysqlAdapter::INT_SMALL,
                            'null' => true
                        ])
                        ->addColumn('city', 'string', [
                            'default' => null,
                            'limit' => 50,
                            'null' => true
                        ])
                        ->addColumn('address1', 'string', [
                            'default' => null,
                            'limit' => 50,
                            'null' => true
                        ])
                        ->addColumn('address2', 'string', [
                            'default' => null,
                            'limit' => 50,
                            'null' => true
                        ])
                        ->addColumn('sns_relation', 'string', [
                            'default' => null,
                            'limit' => 50,
                            'null' => true
                        ])
                        ->addColumn('job_type', 'integer', [
                            'default' => null,
                            'limit' => MysqlAdapter::INT_SMALL,
                            'null' => true
                        ])
                        ->addColumn('job_type_other', 'string', [
                            'default' => null,
                            'limit' => 50,
                            'null' => true
                        ])
                        ->addColumn('working_type', 'integer', [
                            'default' => null,
                            'limit' => MysqlAdapter::INT_SMALL,
                            'null' => true
                        ])
                        ->addColumn('working_type_other', 'string', [
                            'default' => null,
                            'limit' => 50,
                            'null' => true
                        ])
                        ->addColumn('tel', 'string', [
                            'default' => null,
                            'limit' => 13,
                            'null' => true
                        ])
                        ->addColumn('used_sns', 'string', [
                            'default' => null,
                            'limit' => 50,
                            'null' => true
                        ])
                        ->addColumn('interest', 'string', [
                            'default' => null,
                            'limit' => 255,
                            'null' => true
                        ])
                        ->addColumn('interest_other', 'string', [
                            'default' => null,
                            'limit' => 50,
                            'null' => true
                        ])
                        ->addColumn('read', 'string', [
                            'default' => null,
                            'limit' => 100,
                            'null' => true
                        ])
                        ->addColumn('working_area', 'integer', [
                            'default' => null,
                            'limit' => MysqlAdapter::INT_SMALL,
                            'null' => true
                        ])
                        ->addColumn('working_company', 'string', [
                            'default' => null,
                            'limit' => 50,
                            'null' => true
                        ])
                        ->addColumn('line_name', 'string', [
                            'default' => null,
                            'limit' => 50,
                            'null' => true
                        ])
                        ->addColumn('area', 'integer', [
                            'default' => null,
                            'limit' => MysqlAdapter::INT_TINY,
                            'null' => true
                        ])
                        ->addColumn('mobile', 'string', [
                            'default' => null,
                            'limit' => 13,
                            'null' => true
                        ])
                        ->addColumn('bukatsu', 'string', [
                            'default' => null,
                            'limit' => 100,
                            'null' => true
                        ])
                        ->addColumn('favorite_area', 'string', [
                            'default' => null,
                            'limit' => 255,
                            'null' => true
                        ])
                        ->addColumn('bukatsu_free', 'string', [
                            'default' => null,
                            'limit' => 255,
                            'null' => true
                        ])
                        ->addColumn('black_flg', 'integer', [
                            'default' => null,
                            'limit' => MysqlAdapter::INT_TINY,
                            'null' => true
                        ])
                        ->addColumn('credit_cust_id', 'string', [
                            'default' => null,
                            'limit' => 255,
                            'null' => true
                        ])
                        ->addColumn('last_login', 'datetime', [
                            'default' => null,
                            'null' => true
                        ])
                        ->addColumn('auth_code', 'string', [
                            'default' => null,
                            'limit' => 10,
                            'null' => true
                        ])
                        ->addColumn('payment_method', 'integer', [
                            'default' => null,
                            'limit' => MysqlAdapter::INT_TINY,
                            'null' => true
                        ])
                        ->addColumn('status', 'integer', [
                            'default' => 0,
                            'limit' => MysqlAdapter::INT_TINY,
                            'null' => false
                        ])
                        ->addColumn('reg_route', 'integer', [
                            'default' => 0,
                            'limit' => MysqlAdapter::INT_TINY,
                            'null' => false
                        ])
                        ->addColumn('memo', 'string', [
                            'default' => null,
                            'limit' => 255,
                            'null' => true
                        ]);
                }
                //staff table
                if ($db == 'staff') {
                    $table
                        ->addColumn('user_name', 'string', [
                            'default' => null,
                            'limit' => 50,
                            'null' => true
                        ])
                        ->addColumn('email', 'string', [
                            'default' => null,
                            'limit' => 255,
                            'null' => true
                        ])
                        ->addColumn('password', 'string', [
                            'default' => null,
                            'limit' => 255,
                            'null' => false
                        ])
                        ->addColumn('user_flg', 'integer', [
                            'default' => null,
                            'limit' => MysqlAdapter::INT_TINY,
                            'null' => true
                        ])
                        ->addColumn('area', 'integer', [
                            'default' => null,
                            'limit' => MysqlAdapter::INT_TINY,
                            'null' => true
                        ])
                        ->addColumn('last_login', 'datetime', [
                            'default' => null,
                            'null' => true
                        ]);
                }
                //questionnaire table
                if ($db == 'questionnaire') {
                    $table
                        ->addColumn('publish_flag', 'integer', [
                            'default' => null,
                            'limit' => MysqlAdapter::INT_SMALL,
                            'null' => false
                        ])
                        ->addColumn('title', 'string', [
                            'default' => null,
                            'limit' => 100,
                            'null' => false
                        ])
                        ->addColumn('title_image', 'string', [
                            'default' => null,
                            'limit' => 50,
                            'null' => true
                        ])
                        ->addColumn('thumb_image', 'string', [
                            'default' => null,
                            'limit' => 50,
                            'null' => true
                        ])
                        ->addColumn('description', 'text', [
                            'default' => null,
                            'null' => true
                        ])
                        ->addColumn('start_time', 'datetime', [
                            'default' => null,
                            'null' => false
                        ])
                        ->addColumn('end_time', 'datetime', [
                            'default' => null,
                            'null' => false
                        ])
                        ->addColumn('payment_flag', 'integer', [
                            'default' => null,
                            'limit' => MysqlAdapter::INT_TINY,
                            'null' => false
                        ])
                        ->addColumn('payment_method', 'integer', [
                            'default' => null,
                            'limit' => MysqlAdapter::INT_TINY,
                            'null' => false
                        ])
                        ->addColumn('total_no_tax', 'integer', [
                            'default' => null,
                            'limit' => MysqlAdapter::INT_REGULAR,
                            'null' => false
                        ])
                        ->addColumn('tax', 'integer', [
                            'default' => null,
                            'limit' => MysqlAdapter::INT_REGULAR,
                            'null' => false
                        ])
                        ->addColumn('total_amount', 'integer', [
                            'default' => null,
                            'limit' => MysqlAdapter::INT_REGULAR,
                            'null' => false
                        ]);
                }
                //questionnaire_detail table
                if ($db == 'questionnaire_detail') {
                    $table
                        ->addColumn('questionnaire_id', 'biginteger', [
                            'default' => null,
                            'null' => true
                        ])
                        ->addForeignKey('questionnaire_id', 'questionnaire', 'id')
                        ->addColumn('mast_questionnaire_parts_id', 'biginteger', [
                            'default' => null,
                            'null' => true
                        ])
                        ->addColumn('input_type', 'integer', [
                            'default' => null,
                            'limit' => MysqlAdapter::INT_REGULAR,
                            'null' => false
                        ])
                        ->addColumn('sort', 'integer', [
                            'default' => null,
                            'limit' => MysqlAdapter::INT_REGULAR,
                            'null' => true
                        ])
                        ->addColumn('label_name', 'string', [
                            'default' => null,
                            'limit' => 255,
                            'null' => true
                        ])
                        ->addColumn('input_format', 'text', [
                            'default' => null,
                            'null' => true
                        ])
                        ->addColumn('mandatory_flag', 'integer', [
                            'default' => null,
                            'limit' => MysqlAdapter::INT_SMALL,
                            'null' => true
                        ]);
                }
                //mast_questionnaire_parts table
                if ($db == 'mast_questionnaire_parts') {
                    $table
                        ->addColumn('input_type', 'integer', [
                            'default' => null,
                            'limit' => MysqlAdapter::INT_REGULAR,
                            'null' => false
                        ])
                        ->addColumn('sort', 'integer', [
                            'default' => null,
                            'limit' => MysqlAdapter::INT_SMALL,
                            'null' => true
                        ])
                        ->addColumn('label_name', 'string', [
                            'default' => null,
                            'limit' => 100,
                            'null' => true
                        ])
                        ->addColumn('input_format', 'text', [
                            'default' => null,
                            'null' => true
                        ])
                        ->addColumn('mandatory_flag', 'integer', [
                            'default' => null,
                            'limit' => MysqlAdapter::INT_SMALL,
                            'null' => true
                        ]);
                }
                //questionnaire_result table
                if ($db == 'questionnaire_result') {
                    $table
                        ->addColumn('questionnaire_id', 'biginteger', [
                            'default' => null,
                            'null' => true
                        ])
                        ->addForeignKey('questionnaire_id', 'questionnaire', 'id')
                        ->addColumn('fan_id', 'biginteger', [
                            'default' => null,
                            'null' => true
                        ])
                        ->addForeignKey('fan_id', 'fan', 'id')
                        ->addColumn('payment_method', 'integer', [
                            'default' => null,
                            'limit' => MysqlAdapter::INT_TINY,
                            'null' => true
                        ])
                        ->addColumn('total_no_tax', 'integer', [
                            'default' => null,
                            'limit' => MysqlAdapter::INT_REGULAR,
                            'null' => true
                        ])
                        ->addColumn('tax', 'integer', [
                            'default' => null,
                            'limit' => MysqlAdapter::INT_REGULAR,
                            'null' => true
                        ])
                        ->addColumn('total_amount', 'integer', [
                            'default' => null,
                            'limit' => MysqlAdapter::INT_REGULAR,
                            'null' => true
                        ])
                        ->addColumn('credit_token', 'string', [
                            'default' => null,
                            'limit' => 255,
                            'null' => true
                        ])
                        ->addColumn('winning_flg', 'integer', [
                            'default' => null,
                            'limit' => MysqlAdapter::INT_TINY,
                            'null' => true
                        ])
                        ->addColumn('receive_date', 'datetime', [
                            'default' => null,
                            'null' => true
                        ])
                        ->addColumn('memo', 'string', [
                            'default' => null,
                            'limit' => 255,
                            'null' => true
                        ]);
                }
                //questionnaire_result_detail table
                if ($db == 'questionnaire_result_detail') {
                    $table
                        ->addColumn('questionnaire_result_id', 'biginteger', [
                            'default' => null,
                            'null' => false
                        ])
                        ->addForeignKey('questionnaire_result_id', 'questionnaire_result', 'id')
                        ->addColumn('questionnaire_detail_id', 'biginteger', [
                            'default' => null,
                            'null' => false
                        ])
                        ->addForeignKey('questionnaire_detail_id', 'questionnaire_detail', 'id')
                        ->addColumn('sort', 'integer', [
                            'default' => null,
                            'limit' => MysqlAdapter::INT_TINY,
                            'null' => true
                        ])
                        ->addColumn('label_name', 'string', [
                            'default' => null,
                            'limit' => 100,
                            'null' => true
                        ])
                        ->addColumn('input_type', 'integer', [
                            'default' => null,
                            'limit' => MysqlAdapter::INT_REGULAR,
                            'null' => false
                        ])
                        ->addColumn('answer', 'text', [
                            'default' => null,
                            'null' => true
                        ]);
                }
                //mast_ticket table
                if ($db == 'mast_ticket') {
                    $table
                        ->addColumn('ticket_name', 'string', [
                            'default' => null,
                            'limit' => 50,
                            'null' => false
                        ])
                        ->addColumn('list_price', 'string', [
                            'default' => null,
                            'limit' => 255,
                            'null' => true
                        ])
                        ->addColumn('unit_price', 'integer', [
                            'default' => 0,
                            'limit' => MysqlAdapter::INT_REGULAR,
                            'null' => false
                        ])
                        ->addColumn('summary_description', 'text', [
                            'default' => null,
                            'null' => true
                        ])
                        ->addColumn('detail_description', 'text', [
                            'default' => null,
                            'null' => true
                        ])
                        ->addColumn('image_url1', 'string', [
                            'default' => null,
                            'limit' => 255,
                            'null' => true
                        ])
                        ->addColumn('image_url2', 'string', [
                            'default' => null,
                            'limit' => 255,
                            'null' => true
                        ])
                        ->addColumn('image_url3', 'string', [
                            'default' => null,
                            'limit' => 255,
                            'null' => true
                        ])
                        ->addColumn('category', 'integer', [
                            'default' => null,
                            'limit' => MysqlAdapter::INT_SMALL,
                            'null' => false
                        ])
                        ->addColumn('area', 'integer', [
                            'default' => null,
                            'limit' => MysqlAdapter::INT_TINY,
                            'null' => false
                        ])
                        ->addColumn('number', 'integer', [
                            'default' => 0,
                            'limit' => MysqlAdapter::INT_REGULAR,
                            'null' => false
                        ])
                        ->addColumn('start_time', 'datetime', [
                            'default' => null,
                            'null' => false
                        ])
                        ->addColumn('end_time', 'datetime', [
                            'default' => null,
                            'null' => false
                        ]);
                }
                //cart_items table
                if ($db == 'cart_items') {
                    $table
                        ->addColumn('fan_id', 'biginteger', [
                            'default' => null,
                            'null' => false
                        ])
                        ->addForeignKey('fan_id', 'fan', 'id')
                        ->addColumn('ticket_id', 'biginteger', [
                            'default' => null,
                            'null' => true
                        ])
                        ->addForeignKey('ticket_id', 'mast_ticket', 'id')
                        ->addColumn('order_request_number', 'integer', [
                            'default' => null,
                            'limit' => MysqlAdapter::INT_REGULAR,
                            'null' => true
                        ]);
                }
                //order table
                if ($db == 'order') {
                    $table
                        ->addColumn('order_date', 'datetime', [
                            'default' => null,
                            'null' => true
                        ])
                        ->addColumn('total_no_tax', 'integer', [
                            'default' => null,
                            'null' => true
                        ])
                        ->addColumn('tax', 'integer', [
                            'default' => null,
                            'limit' => MysqlAdapter::INT_REGULAR,
                            'null' => true
                        ])
                        ->addColumn('total_amount', 'integer', [
                            'default' => null,
                            'limit' => MysqlAdapter::INT_REGULAR,
                            'null' => true
                        ])
                        ->addColumn('payment_method', 'integer', [
                            'default' => null,
                            'limit' => MysqlAdapter::INT_TINY,
                            'null' => true
                        ])
                        ->addColumn('credit_token', 'string', [
                            'default' => null,
                            'limit' => 255,
                            'null' => true
                        ])
                        ->addColumn('receive_plan_date', 'datetime', [
                            'default' => null,
                            'null' => true
                        ])
                        ->addColumn('receive_date', 'date', [
                            'default' => null,
                            'null' => true
                        ])
                        ->addColumn('memo', 'string', [
                            'default' => null,
                            'limit' => 255,
                            'null' => true
                        ])
                        ->addColumn('user_name', 'string', [
                            'default' => null,
                            'limit' => 50,
                            'null' => true
                        ])
                        ->addColumn('mobile', 'integer', [
                            'default' => null,
                            'limit' => MysqlAdapter::INT_REGULAR,
                            'null' => true
                        ])
                        ->addColumn('tel', 'integer', [
                            'default' => null,
                            'limit' => MysqlAdapter::INT_REGULAR,
                            'null' => true
                        ])
                        ->addColumn('zip', 'integer', [
                            'default' => null,
                            'limit' => MysqlAdapter::INT_REGULAR,
                            'null' => true
                        ])
                        ->addColumn('prefecture', 'integer', [
                            'default' => null,
                            'limit' => MysqlAdapter::INT_SMALL,
                            'null' => true
                        ])
                        ->addColumn('city', 'string', [
                            'default' => null,
                            'limit' => 50,
                            'null' => true
                        ])
                        ->addColumn('address1', 'string', [
                            'default' => null,
                            'limit' => 50,
                            'null' => true
                        ])
                        ->addColumn('address2', 'string', [
                            'default' => null,
                            'limit' => 50,
                            'null' => true
                        ]);
                }
                //order_items table
                if ($db == 'order_items') {
                    $table
                        ->addColumn('fan_id', 'biginteger', [
                            'default' => null,
                            'null' => false
                        ])
                        ->addForeignKey('fan_id', 'fan', 'id')
                        ->addColumn('ticket_id', 'biginteger', [
                            'default' => null,
                            'null' => true
                        ])
                        ->addForeignKey('ticket_id', 'mast_ticket', 'id')
                        ->addColumn('order_id', 'biginteger', [
                            'default' => null,
                            'null' => true
                        ])
                        ->addForeignKey('order_id', 'order', 'id')
                        ->addColumn('order_number', 'integer', [
                            'default' => null,
                            'limit' => MysqlAdapter::INT_REGULAR,
                            'null' => true
                        ])
                        ->addColumn('total_no_tax', 'integer', [
                            'default' => null,
                            'limit' => MysqlAdapter::INT_REGULAR,
                            'null' => true
                        ]);
                }
                //mail_history table
                if ($db == 'mail_history') {
                    $table
                        ->addColumn('send_time', 'datetime', [
                            'default' => null,
                            'null' => false
                        ])
                        ->addColumn('mail_from', 'string', [
                            'default' => null,
                            'limit' => 255,
                            'null' => true
                        ])
                        ->addColumn('subject', 'string', [
                            'default' => null,
                            'limit' => 100,
                            'null' => true
                        ])
                        ->addColumn('mail_template', 'integer', [
                            'default' => null,
                            'limit' => MysqlAdapter::INT_SMALL,
                            'null' => true
                        ])
                        ->addColumn('send_to_file', 'string', [
                            'default' => null,
                            'limit' => 255,
                            'null' => true
                        ]);
                }
            }
            $table
                ->addColumn('del_flg', 'integer', [
                    'default' => 0,
                    'limit' => MysqlAdapter::INT_TINY,
                    'null' => false
                ])
                ->addColumn('created_by', 'biginteger', [
                    'default' => null,
                    'null' => true
                ])
                ->addColumn('created_at', 'datetime', [
                    'default' => null,
                    'null' => true
                ])
                ->addColumn('updated_by', 'biginteger', [
                    'default' => null,
                    'null' => true
                ])
                ->addColumn('updated_at', 'datetime', [
                    'default' => null,
                    'null' => true
                ])
                ->addColumn('deleted_by', 'biginteger', [
                    'default' => null,
                    'null' => true
                ])
                ->addColumn('deleted_at', 'datetime', [
                    'default' => null,
                    'null' => true
                ])
                ->create();
        }
    }
}
