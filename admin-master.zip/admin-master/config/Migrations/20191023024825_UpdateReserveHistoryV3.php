<?php
use Migrations\AbstractMigration;

class UpdateReserveHistoryV3 extends AbstractMigration
{
    /**
     * Change Method.
     *
     * More information on this method is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-change-method
     * @return void
     */
    public function change()
    {
        try {
            $table = $this->table('reserve_history');
            $table
                ->changeColumn('rsv_date', 'datetime', [
                    'default' => null,
                    'null' => true
                ])
                ->changeColumn('in_tsp', 'datetime', [
                    'default' => null,
                    'null' => true
                ]);
            $table->save();
        } catch (\Exception $ex) {
            echo ($ex->getMessage());
        }
    }
}
