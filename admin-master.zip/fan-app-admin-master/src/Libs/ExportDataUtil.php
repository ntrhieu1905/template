<?php
/**
 * Created by PhpStorm.
 * User: Briswell_User_003
 * Date: 7/10/2019
 * Time: 10:25 AM
 */
namespace App\Libs;

use App\Libs\ConfigUtil;
use Cake\Log\Log;

class ExportDataUtil
{

    /**
     * export csv
     * @param $listData
     * @param $fileName
     * @param $option
     * @return int|mixed
     */
    public function exportCSV($listData, $fileName, $option = array())
    {
        try{
            $rowCnt = 0;
            $contents = null;
            foreach ($listData as $index => $data) {
                if($index > 0) {
                    foreach ($data as &$row) {
                        $row = '"' . preg_replace('/"/','""', $row) . '"';
                    }
                }
                if ($rowCnt > 0) {
                    $contents .= "\n";
                }
                $contents .= mb_convert_encoding(implode(',', $data), 'SJIS-win', 'UTF-8');
                $rowCnt++;
            }
            $path = WWW_ROOT . ConfigUtil::get('path_csv');
            if (!file_exists($path)) {
                mkdir($path, 0777, true);
            }
            $fullPatchName = $path . $fileName;
            file_put_contents($fullPatchName, $contents);
            header("Content-type: text/html; charset=SJIS-win");
            header("Cache-Control: public");
            header("Content-Disposition: attachment; filename=$fileName");
            header("Content-Description: File Transfer");
            header("Content-Transfer-Encoding: binary");
            header ('Content-Type: application/octet-stream');
            //read file and delete link
            readfile($fullPatchName);
            unlink($fullPatchName);
        }
        catch (\Exception $e) {
            return $e->getCode();
        }
        exit();
    }

    /**
     * download csv
     * @param $file
     * @return boolean
     */
    public function downloadCSV($file, $fileName) {
        try {
            $path = HTML_ROOT;
            if (!file_exists($path)) {
                mkdir($path, 0777, true);
            }
            $filePath = $path . $file;
            if (!file_exists($filePath)) {
                return false;
            }
            header("Content-type:application/csv");
            header('Content-Disposition: attachment; filename=' . $fileName);
            //read file and delete link
            readfile($filePath);
        } catch (\Exception $e) {
            Log::error('Download CSV: ' .$e->getMessage());
        }
        exit();
    }

    /**
     * get file path
     * @param $listData
     * @param $fileName
     * @return int|mixed|string
     */
    public function getFilePath($listData, $fileName) {
        try {
            $rowCnt = 0;
            $contents = null;
            foreach ($listData as $data) {
                foreach ($data as &$row) {
                    $row = '"' . preg_replace('/"/','""', $row) . '"';
                }
                if ($rowCnt > 0) {
                    $contents .= "\n";
                }
                $contents .= mb_convert_encoding(implode(',', $data), 'SJIS-win', 'UTF-8');
                $rowCnt++;
            }
            $path = WWW_ROOT . ConfigUtil::get('path_csv');
            if (!file_exists($path)) {
                mkdir($path, 0777, true);
            }
            $fullPatchName = $path . $fileName;
            file_put_contents($fullPatchName, $contents);
            header("Content-type: text/html; charset=SJIS-win");
            header("Cache-Control: public");
            return $fullPatchName;
        } catch (\Exception $ex) {
            return $ex->getCode();
        }
        exit();
    }

    /**
     * download csv from aws3
     * @param $file
     * @return boolean
     */
    public function downloadCSVFromAWS3($filePath, $fileName) {
        try {

            $file_headers = @get_headers($filePath);

            if(!$file_headers || $file_headers[0] == 'HTTP/1.1 403 Forbidden') {
                return false;
            }
            else {
                header("Content-type:application/csv");
                header('Content-Disposition: attachment; filename=' . $fileName);
                //read file
                readfile($filePath);
            }

        } catch (\Exception $e) {
            Log::error('Download CSV: ' .$e->getMessage());
        }
        exit();
    }
}
