<?php
use Migrations\AbstractMigration;

class AlterOrder27042020 extends AbstractMigration
{
    /**
     * Change Method.
     *
     * More information on this method is available here:
     * https://book.cakephp.org/phinx/0/en/migrations.html#the-change-method
     * @return void
     */
    public function change()
    {
        $table = $this->table('order');
        $table
            ->addColumn('shipping_cost', 'integer', [
                'default' => null,
                'null'    => true,
                'after'   => 'tax'
            ])
            ->update();
    }
}
