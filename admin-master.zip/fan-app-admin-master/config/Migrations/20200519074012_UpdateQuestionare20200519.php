<?php
use Migrations\AbstractMigration;

class UpdateQuestionare20200519 extends AbstractMigration
{
    /**
     * Change Method.
     *
     * More information on this method is available here:
     * https://book.cakephp.org/phinx/0/en/migrations.html#the-change-method
     * @return void
     */
    public function change()
    {
        $table = $this->table('questionnaire');
        $table->addColumn('hash_url', 'string', [
            'default' => null,
            'null'    => true,
            'limit'   => 255,
            'after'   => 'application_limit'
        ])->update();
    }
}
