<?php
namespace App\Model\Table;

use App\Libs\ValueUtil;
use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * QuestionnaireDetail Model
 *
 * @property \Cake\ORM\Association\BelongsTo $Questionnaire
 * @property \Cake\ORM\Association\BelongsTo $MastQuestionnaireParts
 * @property \Cake\ORM\Association\HasMany $QuestionnaireResultDetail
 *
 * @method \App\Model\Entity\QuestionnaireDetail get($primaryKey, $options = [])
 * @method \App\Model\Entity\QuestionnaireDetail newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\QuestionnaireDetail[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\QuestionnaireDetail|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\QuestionnaireDetail saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\QuestionnaireDetail patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\QuestionnaireDetail[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\QuestionnaireDetail findOrCreate($search, callable $callback = null, $options = [])
 */
class QuestionnaireDetailTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('questionnaire_detail');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->belongsTo('Questionnaire', [
            'foreignKey' => 'questionnaire_id'
        ]);
        $this->belongsTo('MastQuestionnaireParts', [
            'foreignKey' => 'mast_questionnaire_parts_id'
        ]);
        $this->hasMany('QuestionnaireResultDetail', [
            'foreignKey' => 'questionnaire_detail_id'
        ]);

        $this->addBehavior('UpdateSync');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->allowEmptyString('id', null, 'create');

        $validator
            ->integer('input_type')
            ->requirePresence('input_type', 'create')
            ->notEmptyString('input_type');

        $validator
            ->integer('sort')
            ->allowEmptyString('sort');

        $validator
            ->scalar('label_name')
            ->maxLength('label_name', 255)
            ->allowEmptyString('label_name');

        $validator
            ->scalar('input_format')
            ->allowEmptyString('input_format');

        $validator
            ->allowEmptyString('mandatory_flag');

        $validator
            ->notEmptyString('del_flg');

        $validator
            ->allowEmptyString('created_by');

        $validator
            ->dateTime('created_at')
            ->allowEmptyDateTime('created_at');

        $validator
            ->allowEmptyString('updated_by');

        $validator
            ->dateTime('updated_at')
            ->allowEmptyDateTime('updated_at');

        $validator
            ->allowEmptyString('deleted_by');

        $validator
            ->dateTime('deleted_at')
            ->allowEmptyDateTime('deleted_at');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['questionnaire_id'], 'Questionnaire'));
        $rules->add($rules->existsIn(['mast_questionnaire_parts_id'], 'MastQuestionnaireParts'));

        return $rules;
    }

    /**
     * get QuestionnaireDetail data by Questionnaire
     *
     * @param $id
     * @return \App\Model\Entity\QuestionnaireDetail|bool
     */
    public function getQuestionnaireDetail($id = null) {
        try {
            $result = $this->find()->where(['questionnaire_id' => $id])
                                   ->andWhere(['del_flg' => ValueUtil::constToValue('common.deleted_flg.NOT_DELETED')])
                                   ->andWhere(['deleted_at IS NULL'])
                                   ->order(['sort' => 'ASC'])
                                   ->toArray();

            return $result;
        } catch (\Exception $e) {
            return null;
        }
    }

    /**
     * get QuestionnaireDetail data by id
     *
     * @param $id
     * @return \App\Model\Entity\QuestionnaireDetail|bool
     */
    public function getQuestionnaireDetailById($id = null) {
        try {
            $result = $this->find()->where(['id' => $id])
                                   ->andWhere(['del_flg' => ValueUtil::constToValue('common.deleted_flg.NOT_DELETED')])
                                   ->andWhere(['deleted_at IS NULL'])
                                   ->first();

            return $result;
        } catch (\Exception $e) {
            return null;
        }
    }

    public function countQuestionnaireDetailByType($questionnaireId, $type) {
        try {
            $result = $this->find()
                        ->where(['questionnaire_id' => $questionnaireId])
                        ->andWhere(['input_type' => $type])
                        ->andWhere(['del_flg' => ValueUtil::constToValue('common.deleted_flg.NOT_DELETED')])
                        ->andWhere(['deleted_at IS NULL'])
                        ->count();

            return $result;
        } catch (\Exception $e) {
            return null;
        }
    }

    /**
     * get max sort value of questionnaire detail by questionnaire id
     *
     * @param $questionnaireId
     * @return array|null
     */
    public function getMaxSortQuestionnaireDetail($questionnaireId) {
        try {
            $query = $this->find();
            $query->select(['maxSort' => 'MAX(QuestionnaireDetail.sort)'])
                  ->where(['QuestionnaireDetail.questionnaire_id' => $questionnaireId])
                  ->andWhere(['del_flg' => ValueUtil::constToValue('common.deleted_flg.NOT_DELETED')])
                  ->andWhere(['deleted_at IS NULL'])
                  ->enableHydration(FALSE);

            return $query->first();
        } catch (\Exception $e) {
            return null;
        }
    }

    /**
     * get QuestionnaireDetail data by id
     *
     * @param null $conds
     * @return array|\Cake\Datasource\EntityInterface|null
     */
    public function getQuestionnaireDetailByConds($conds = null) {
        try {
            $query = $this->find()
                ->where(['del_flg' => ValueUtil::constToValue('common.deleted_flg.NOT_DELETED')])
                ->andWhere(['deleted_at IS NULL']);
            // if param is array
            if (is_array($conds)) {
                $query->andWhere(['id IN ' => $conds]);
                return $query->toArray();
            }
            $query->andWhere(['id' => $conds]);
            return $query->first();
        } catch (\Exception $e) {
            return null;
        }
    }

    /**
     * update sort QuestionnaireDetail
     *
     * @param array $idQuestionnaireDetails
     * @return bool|null
     */
    public function updateArrayQuestionnaireDetails($idQuestionnaireDetails = []) {
        try {
            // get questionnaire_detail
            $questionnaireDetails = $this->getQuestionnaireDetailByConds($idQuestionnaireDetails);
            // if questionnaire_detail don't exists
            if (!$questionnaireDetails) {
                return null;
            }
            // get id of tokutati details
            $getIdOfQuestionnaireDetails = array_column($questionnaireDetails, 'id');
            // begin transaction
            $this->getConnection()->begin();
            foreach ($idQuestionnaireDetails as $key => $idQuestionnaireDetail) {
                // change sort record TokutabiDetail
                $params['sort'] = (int) $key + ValueUtil::get('common.increase_one');
                $getKey = array_search($idQuestionnaireDetail, $getIdOfQuestionnaireDetails);
                $object = $this->patchEntity($questionnaireDetails[$getKey], $params);
                //save record
                $this->save($object);
            }
            // commit transaction
            $this->getConnection()->commit();
            return true;
        } catch (\Exception $e) {
            // error rollback transaction
            $this->getConnection()->rollback();
            return null;
        }
    }
}
