$(document).ready(function(){
    //Validation search form
    $('#ord013').validate({
        ignore: [],
        focusInvalid: true,
        rules: {
            'order_date_from': {
                date: true,
            },
            'order_date_to': {
                date: true,
            },
        },
        messages: {
            'order_date_from': {
                date: function(params, input) {
                    return $.validator.messages.date($(input).data('label'));
                },
            },
            'order_date_to': {
                date: function(params, input) {
                    return $.validator.messages.date($(input).data('label'));
                },
            },
        },
        onfocusout: function(element) {
            this.element(element);
        },
        submitHandler: function(form) {
            $('#form-btn-013').attr('disabled', true);
            form.submit();
        }
    });
    //CSV export
    $('#csv-export-tmp').click(function () {
        var form = $('form');
        form.each(function (i, obj) {
            var frma013 = $('#ord013').find('input').clone();
            if($(obj).is(':hidden')) {
                $(obj).append(frma013);
            }
        });
        //append to postLink form then click csv-export button
        setTimeout(
            function()
            {
                $('#csv-export').click();
            }, 500); //Set the time 500 to wait for the button to click next time
    });
    //Jquery validate
    $('#popup-frmA011').validate({
        rules: {
            receive_date: {
                date: true
            },
            memo: {
                maxlength: 255
            }
        },
        messages: {
            receive_date: {
                date: function(params, input) {
                    return $.validator.messages.date('入金日');
                },
            },
            memo: {
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength(['メモ', params, $(input).val().length]);
                }
            }
        },
        submitHandler: function(form) {
            $('#popup-updateA011').attr('disabled', true);
            form.submit();
        }
    });
    //Pass value in modal
    $('#Que-a011').on('show.bs.modal', function(e) {
        $('#popup-frmA011').validate().resetForm();
        $('#popup-frmA011').find('.form-exp').remove();
        $('#popup-frmA011').attr('action',$('#url-popup-a013').val());
        $('#quest-result-id').val($(e.relatedTarget).data('id'));
        $('#receive-date').val($(e.relatedTarget).data('receive_date'));
        $('#memo').val($(e.relatedTarget).data('memo'));
        $('#screen-id').val($(e.relatedTarget).data('screen_id'));
    });
    $('#Que-a011').on('hidden.bs.modal', function(e) {
        $(this).find('#receive-date').removeClass('error-message');
        $(this).find('#receive-date-error').remove();
        $(this).find('#memo').removeClass('error-message');
        $(this).find('#memo-error').remove();
        //Process css focus
        $(this).parent().find('#popup-'+$(this).find('#quest-result-id').val()).css({
            'background': '#3b99fc',
            'color': '#fff',
            'border': '1px solid #3b99fc'
        });
    });
});
