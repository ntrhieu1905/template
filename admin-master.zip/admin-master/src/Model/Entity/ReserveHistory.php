<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * ReserveHistory Entity
 *
 * @property int $rsv_log_id
 * @property int $shop_id
 * @property int|null $mem_id
 * @property \Cake\I18n\FrozenTime|null $rsv_date
 * @property int|null $rsv_count
 * @property string|null $rsv_course
 * @property string|null $rsv_coupon
 * @property int|null $cpn_id
 * @property string|null $rsv_name
 * @property string|null $rsv_kana
 * @property string|null $rsv_company
 * @property string|null $rsv_tel
 * @property string|null $rsv_tel2
 * @property string|null $rsv_email
 * @property int|null $rsv_sex
 * @property string|null $rsv_remark
 * @property \Cake\I18n\FrozenTime|null $in_tsp
 * @property int|null $in_id
 * @property int|null $rsv_course_price
 * @property string|null $rsv_course_price_org
 * @property int $del_flg
 * @property int|null $created_by
 * @property \Cake\I18n\FrozenTime|null $created_at
 * @property int|null $updated_by
 * @property \Cake\I18n\FrozenTime|null $updated_at
 * @property int|null $deleted_by
 * @property \Cake\I18n\FrozenTime|null $deleted_at
 *
 * @property \App\Model\Entity\Shop $shop
 * @property \App\Model\Entity\Mem $mem
 * @property \App\Model\Entity\Cpn $cpn
 * @property \App\Model\Entity\In $in
 */
class ReserveHistory extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'shop_id' => true,
        'mem_id' => true,
        'rsv_date' => true,
        'rsv_count' => true,
        'rsv_course' => true,
        'rsv_coupon' => true,
        'cpn_id' => true,
        'rsv_name' => true,
        'rsv_kana' => true,
        'rsv_company' => true,
        'rsv_tel' => true,
        'rsv_tel2' => true,
        'rsv_email' => true,
        'rsv_sex' => true,
        'rsv_remark' => true,
        'in_tsp' => true,
        'in_id' => true,
        'rsv_course_price' => true,
        'rsv_course_price_org' => true,
        'del_flg' => true,
        'created_by' => true,
        'created_at' => true,
        'updated_by' => true,
        'updated_at' => true,
        'deleted_by' => true,
        'deleted_at' => true,
        'shop' => true,
        'mem' => true,
        'cpn' => true,
        'in' => true
    ];
}
