<?php
use Migrations\AbstractMigration;
use Phinx\Db\Adapter\MysqlAdapter;

class UpdateReserverHistory extends AbstractMigration
{
    /**
     * Change Method.
     *
     * More information on this method is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-change-method
     * @return void
     */
    public function change()
    {
        try {
            $table = $this->table('reserve_history');
            $table
                ->addColumn('shop_name', 'text', [
                    'default' => null,
                    'after' => 'shop_id',
                    'limit' => MysqlAdapter::INT_SMALL,
                    'null' => true
                ])
                ->save();
        }
        catch (\Exception $ex) {
            echo ($ex->getMessage());
        }

    }
}
