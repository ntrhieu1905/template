<?php
namespace App\Model\Table;

use App\Libs\ConfigUtil;
use App\Libs\ValueUtil;
use Cake\Datasource\EntityInterface;
use Cake\I18n\Time;
use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;
use Cake\Event\Event;

/**
 * Questionnaire Model
 *
 * @property \App\Model\Table\QuestionnaireDetailTable&\Cake\ORM\Association\HasMany $QuestionnaireDetail
 * @property \App\Model\Table\QuestionnaireResultTable&\Cake\ORM\Association\HasMany $QuestionnaireResult
 *
 * @method \App\Model\Entity\Questionnaire get($primaryKey, $options = [])
 * @method \App\Model\Entity\Questionnaire newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Questionnaire[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Questionnaire|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Questionnaire saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Questionnaire patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Questionnaire[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Questionnaire findOrCreate($search, callable $callback = null, $options = [])
 */
class QuestionnaireTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('questionnaire');
        $this->setDisplayField('title');
        $this->setPrimaryKey('id');

        $this->hasMany('QuestionnaireDetail', [
            'foreignKey' => 'questionnaire_id'
        ]);
        $this->hasMany('QuestionnaireResult', [
            'foreignKey' => 'questionnaire_id'
        ]);
        $this->hasMany('Order', [
            'foreignKey' => 'questionnaire_id'
        ]);

        // add behavior
        $this->addBehavior('UpdateSync');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->allowEmptyString('id', null, 'create');

        $validator
            ->notEmptyString('publish_flag', ConfigUtil::getMessage("ECL001", ["公開／非公開"]));

        $validator
            ->notEmptyString('title', ['message' => ConfigUtil::getMessage('ECL001', ['タイトル'])])
            ->add('title', ['length' => $this->checkMaxLength('タイトル', 100, 'title')]);

        $validator
            ->notEmptyFile('image_url1', ConfigUtil::getMessage("ECL001", ["メイン画像"]), function ($context) {
                if(!empty($context['data']['image_url1_url'])) {
                    return false;
                }
                return true;
            })
            ->add('image_url1', [
                'extension' => [
                    'rule' => ['extension', ['jpg', 'jpeg', 'png']],
                    'message' => ConfigUtil::getMessage("ECL022", ["「jpg, jpeg, png」"]),
                    'on' => function($context) {
                        return !empty($context['data']['image_url1']);
                    }
                ],
                'fileSize' => [
                    'rule' => function($value, $context) {
                        $imgSize = isset($value['size']) ? $value['size'] : null;
                        $sizeDefault = ValueUtil::get('common.img_size')*1024*1024;
                        if($imgSize > $sizeDefault) {
                            return ConfigUtil::getMessage("ECL022", ["4MB"]);
                        }
                        return true;
                    },
                    'on' => function($context) {
                        return !empty($context['data']['image_url1']);
                    }
                ]
            ]);

        $validator
            ->allowEmptyFile('image_url2')
            ->add('image_url2', [
                'extension' => [
                    'rule' => ['extension', ['jpg', 'jpeg', 'png']],
                    'message' => ConfigUtil::getMessage("ECL022", ["「jpg, jpeg, png」"]),
                    'on' => function($context) {
                        return !empty($context['data']['image_url2']);
                    }
                ],
                'fileSize' => [
                    'rule' => function($value, $context) {
                        $imgSize = isset($value['size']) ? $value['size'] : null;
                        $sizeDefault = ValueUtil::get('common.img_size')*1024*1024;
                        if($imgSize > $sizeDefault) {
                            return ConfigUtil::getMessage("ECL022", ["4MB"]);
                        }
                        return true;
                    },
                    'on' => function($context) {
                        return !empty($context['data']['image_url2']);
                    }
                ]
            ]);

        $validator
            ->allowEmptyFile('image_url3')
            ->add('image_url3', [
                'extension' => [
                    'rule' => ['extension', ['jpg', 'jpeg', 'png']],
                    'message' => ConfigUtil::getMessage("ECL022", ["「jpg, jpeg, png」"]),
                    'on' => function($context) {
                        return !empty($context['data']['image_url3']);
                    }
                ],
                'fileSize' => [
                    'rule' => function($value, $context) {
                        $imgSize = isset($value['size']) ? $value['size'] : null;
                        $sizeDefault = ValueUtil::get('common.img_size')*1024*1024;
                        if($imgSize > $sizeDefault) {
                            return ConfigUtil::getMessage("ECL022", ["4MB"]);
                        }
                        return true;
                    },
                    'on' => function($context) {
                        return !empty($context['data']['image_url3']);
                    }
                ]
            ]);

        $validator
            ->notEmptyFile('thumb_image', ConfigUtil::getMessage("ECL001", ["サムネイル画像"]), function($context) {
                if(!empty($context['data']['thumb_image_url'])) {
                    return false;
                }
                return true;
            })
            ->add('thumb_image', [
                'extension' => [
                    'rule' => ['extension', ['jpg', 'jpeg', 'png']],
                    'message' => ConfigUtil::getMessage("ECL022", ["「jpg, jpeg, png」"]),
                    'on' => function($context) {
                        return !empty($context['data']['thumb_image']);
                    }
                ],
                'fileSize' => [
                    'rule' => function($value, $context) {
                        $imgSize = isset($value['size']) ? $value['size'] : null;
                        $sizeDefault = ValueUtil::get('common.img_size')*1024*1024;
                        if($imgSize > $sizeDefault) {
                            return ConfigUtil::getMessage("ECL022", ["4MB"]);
                        }
                        return true;
                    },
                    'on' => function($context) {
                        return !empty($context['data']['thumb_image']);
                    }
                ]
            ]);

        $validator
            ->notEmptyString('description', ['message' => ConfigUtil::getMessage('ECL001', ['概要説明'])])
            ->add('description', 'max-length', [
                'rule' => function ($value, $context) {
                    $length = ValueUtil::validateTextArea($value);
                    if($length > 1000) {
                        return ConfigUtil::getMessage("ECL002", ["概要説明", 1000, $length]);
                    }
                    return true;
                }
            ]);

        $validator
            ->notEmptyString('detail_description', ['message' => ConfigUtil::getMessage('ECL001', ['詳細説明'])])
            ->add('detail_description', 'max-length', [
                'rule' => function ($value, $context) {
                    $length = ValueUtil::countCharacters($value);
                    if($length > 3000) {
                        return ConfigUtil::getMessage("ECL002", ["詳細説明", 3000, $length]);
                    }
                    return true;
                }
            ]);

        $validator
            ->notEmptyString('start_time', ConfigUtil::getMessage("ECL001", ["販売開始日時"]))
            ->add('start_time', 'datetime', [
                'rule' => 'datetime',
                'message' => ConfigUtil::getMessage("ECL014", ["販売開始日時"])
            ]);

        $validator
            ->notEmptyString('end_time', ConfigUtil::getMessage("ECL001", ["販売終了日時"]))
            ->add('end_time', [
                'datetime' => [
                    'rule' => 'datetime',
                    'message' => ConfigUtil::getMessage("ECL014", ["販売終了日時"])
                ],
                'greaterThanDate' => [
                    'rule' => function($value, $context) {
                        $startTime = !empty($context['data']['start_time']) ? $context['data']['start_time'] : '';
                        $endTime = !empty($context['data']['end_time']) ? $context['data']['end_time'] : '';
                        if($endTime < $startTime) {
                            return ConfigUtil::getMessage("ECL036", ["販売終了日時", "販売開始日時"]);
                        }
                        return true;
                    }
                ]
            ]);

        $validator
            ->notEmptyString('host_area', ['message' => ConfigUtil::getMessage('ECL001', ['開催地域'])])
            ->add('host_area', [
                'length' => $this->checkMaxLength('開催地域', 10, 'host_area')
            ]);

        $validator
            ->allowEmptyString('venue')
            ->add('venue', [
                'length' => $this->checkMaxLength('開催場所', 50, 'venue')
            ]);

        $validator
            ->allowEmptyString('address')
            ->add('address', [
                'length' => $this->checkMaxLength('開催住所', 50, 'address')
            ]);

        $validator
            ->notEmptyString('event_date', ['message' => ConfigUtil::getMessage('ECL001', ['開催日'])])
            ->add('event_date', [
                'length' => $this->checkMaxLength('開催日', 50, 'event_date')
            ]);

        $validator
            ->allowEmptyString('mail')
            ->add('mail', [
                'length' => $this->checkMaxLength('お問合せ先メール', 50, 'mail'),
                'email' => [
                    'rule' => 'email',
                    'message' => ConfigUtil::getMessage("ECL007")
                ]
            ]);

        $validator
            ->allowEmptyString('phone_number')
            ->add('phone_number', [
                'length' => $this->checkMaxLength('お問合せ先電話番号', 50, 'phone_number')
            ]);

        $validator
            ->allowEmptyString('business_hour')
            ->add('business_hour', [
                'length' => $this->checkMaxLength('お問合せ先営業時間', 50, 'business_hour')
            ]);

        return $validator;
    }

    /**
     * Modifying Request Data Before Building Entities
     *
     * @param Event $event
     * @param \ArrayObject $data
     * @param \ArrayObject $options
     */
    public function beforeSave(Event $event, EntityInterface $entity, \ArrayObject $options) {
        if (!empty($entity->get('total_no_tax'))) {
            $totalNoTax = abs($entity->get('total_no_tax'));
            $tax = round($totalNoTax * (int) ValueUtil::get('common.tax_percent') / 100);
            $totalAmount = $totalNoTax + $tax;
            $entity->set('total_no_tax', $totalNoTax);
            $entity->set('tax', $tax);
            $entity->set('total_amount', $totalAmount);
        }
    }

    /**
     * get all Questionnaire data
     * @param array $conditions
     * @return \App\Model\Entity\Questionnaire|null
     */
    public function search($conditions) {
        try {
            $delFlg = ValueUtil::get('common.del_flg_val');
            $delFlgVal = isset($delFlg['undeleted']) ? $delFlg['undeleted'] : 0;
            $query = $this->find()
                        ->join([
                            'table'      => 'staff',
                            'alias'      => 'staff',
                            'type'       => 'LEFT',
                            'conditions' => 'staff.id = Questionnaire.created_by'
                        ])
                        ->where(['Questionnaire.del_flg' => $delFlgVal])
                        ->andWhere(['Questionnaire.deleted_at IS NULL']);

            if (count($conditions) > 0) {
                // タイトル
                if (strlen($conditions['title']) > 0) {
                    $title = $conditions['title'] . '%';
                    $query->andWhere(["Questionnaire.title LIKE " => $title]);
                }
                // 公開／非公開
                if (!empty($conditions['publish_flag'])) {
                    $query->andWhere(["Questionnaire.publish_flag IN " => $conditions['publish_flag']]);
                }
                // 公開日時
                if (strlen($conditions['start_time']) > 0 || strlen($conditions['end_time']) > 0) {
                    $startTime = "'".$conditions['start_time']."'";
                    $endTime = "'".$conditions['end_time']."'";
                    if (strlen($conditions['start_time']) > 0) {
                        $query->andWhere("DATE_FORMAT(Questionnaire.start_time, '%Y/%m/%d') >= ".$startTime);
                    }
                    if (strlen($conditions['end_time']) > 0) {
                        $query->andWhere("DATE_FORMAT(Questionnaire.end_time, '%Y/%m/%d') <=".$endTime);
                    }
                }
                // 決済要否
                if (!empty($conditions['payment_flag'])) {
                    $paymentFlg = '(' . implode($conditions['payment_flag'], ',') . ')';
                    $query->andWhere(["Questionnaire.payment_flag IN ".$paymentFlg]);
                }
                // 登録担当者エリア
                if (!empty($conditions['staff_area'])) {
                    $query->andWhere(["staff.area" => $conditions['staff_area']]);
                    $query->andWhere(['Questionnaire.created_by IS NOT NULL']);
                }
                // 販売状態
                if (!empty($conditions['time_search'])) {
                    $systemTime = "'".date('Y/m/d H:i:s')."'";
                    $conditions_or = [];
                    // 未販売
                    if (in_array(ValueUtil::get('questionnaire.time_search_val')['unsold'], $conditions['time_search'])) {
                        $conditions_or['OR'][] = [
                            "DATE_FORMAT(Questionnaire.start_time, '%Y/%m/%d %H:%i:%s') > ".$systemTime
                        ];
                    }
                    // 販売中
                    if (in_array(ValueUtil::get('questionnaire.time_search_val')['start_time'], $conditions['time_search'])) {
                        $conditions_or['OR'][] = [
                            "DATE_FORMAT(Questionnaire.start_time, '%Y/%m/%d %H:%i:%s') <= ".$systemTime,
                            "DATE_FORMAT(Questionnaire.end_time, '%Y/%m/%d %H:%i:%s') >= ".$systemTime
                        ];
                    }
                    // 販売終了
                    if (in_array(ValueUtil::get('questionnaire.time_search_val')['end_time'], $conditions['time_search'])) {
                        $conditions_or['OR'][] = [
                            "DATE_FORMAT(Questionnaire.end_time, '%Y/%m/%d %H:%i:%s') < ".$systemTime
                        ];
                    }
                    $query->andWhere($conditions_or);
                }
            }
            // order
            $query->order([
                'Questionnaire.created_at DESC'
            ]);
            return $query;
        } catch (\Exception $e) {
            return null;
        }
    }

    /**
     * get Questionnaire data by id
     *
     * @param $id
     * @return \App\Model\Entity\Questionnaire|bool
     */
    public function getQuestionnaireById($id = null) {
        try {
            $delFlg = ValueUtil::get('common.del_flg_val');
            $delFlgVal = isset($delFlg['undeleted']) ? $delFlg['undeleted'] : 0;
            $result = $this->find()
                        ->where(['Questionnaire.id' => $id])
                        ->andWhere(['Questionnaire.del_flg' => $delFlgVal])
                        ->andWhere(['Questionnaire.deleted_at IS NULL'])
                        ->first();

            return $result;
        } catch (\Exception $e) {
            return null;
        }
    }

    /**
     * Default validation rules.
     * check maxlength params
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    private function checkMaxLength($title, $length, $field) {
        $currentLength = isset($_REQUEST[$field]) ? mb_strlen($_REQUEST[$field]) : 0;

        return [
            'rule' => ['maxLength', $length],
            'message' => ConfigUtil::getMessage("ECL002", [$title, $length, $currentLength])
        ];
    }

    /**
     * check validation for date input type
     *
     * @param $date
     * @return bool
     */
    private function checkDate($date){
        $flag = false;
        if (preg_match("/(\d{4})-(\d{2})-(\d{2})$/", $date)) {
            $flag = true;
        }

        return $flag;
    }

    /**
     *  get last id
     * @return |null
     */
    public function getLastIdBeforeInsert() {
        try {
            $query = $this->find()->select(['id'])->last();
            return $query->id;
        } catch (\Exception $e) {
            return null;
        }
    }
}
