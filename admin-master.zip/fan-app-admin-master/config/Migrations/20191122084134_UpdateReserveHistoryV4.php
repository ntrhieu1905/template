<?php
use Migrations\AbstractMigration;

class UpdateReserveHistoryV4 extends AbstractMigration
{
    /**
     * Change Method.
     *
     * More information on this method is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-change-method
     * @return void
     */
    public function change()
    {
        try {
            $table = $this->table('reserve_history');
            $table
                ->changeColumn('rsv_sex', 'string', [
                    'default' => null,
                    'limit' => 1,
                    'null' => true
                ])
                ->changeColumn('del_flg', 'string', [
                    'default' => null,
                    'limit' => 1,
                    'null' => true
                ]);
            $table->save();
        } catch (\Exception $ex) {
            echo ($ex->getMessage());
        }
    }
}
