<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * MastTicket Entity
 *
 * @property int $id
 * @property int $ticket_type
 * @property string $ticket_name
 * @property string|null $list_price
 * @property int $unit_price
 * @property string|null $summary_description
 * @property string|null $detail_description
 * @property string|null $image_url1
 * @property string|null $image_url2
 * @property string|null $image_url3
 * @property int $category
 * @property int $area
 * @property int $number
 * @property int $number_disp
 * @property int $total_number
 * @property int $e_ticket
 * @property int $usage_limit
 * @property int $lower_limit
 * @property int $upper_limit
 * @property \Cake\I18n\FrozenTime $exp_from
 * @property \Cake\I18n\FrozenTime $exp_to
 * @property int $free_shipping
 * @property \Cake\I18n\FrozenTime $start_time
 * @property \Cake\I18n\FrozenTime $end_time
 * @property int $del_flg
 * @property int|null $created_by
 * @property \Cake\I18n\FrozenTime|null $created_at
 * @property int|null $updated_by
 * @property \Cake\I18n\FrozenTime|null $updated_at
 * @property int|null $deleted_by
 * @property \Cake\I18n\FrozenTime|null $deleted_at
 */
class MastTicket extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'id' => false,
        '*' => true
    ];
}
