<?php
use Migrations\AbstractMigration;

class UpdateReserveHistoryV2 extends AbstractMigration
{
    /**
     * Change Method.
     *
     * More information on this method is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-change-method
     * @return void
     */
    public function change()
    {
        try {
            $table = $this->table('reserve_history');
            $table
                ->addColumn('shop_kana', 'text', [
                    'default' => NULL,
                    'null' => TRUE,
                    'after' => 'shop_name'
                ])
                ->addColumn('master_area', 'string', [
                    'default' => null,
                    'limit' => 5,
                    'null' => true,
                    'after' => 'shop_kana'
                ])
                ->addColumn('shop_tel', 'text', [
                    'default' => NULL,
                    'null' => TRUE,
                    'after' => 'master_area'
                ])
                ->addColumn('shop_addr', 'text', [
                    'default' => NULL,
                    'null' => TRUE,
                    'after' => 'shop_tel'
                ])
            ;
            $table->save();
        } catch (\Exception $ex) {
            echo ($ex->getMessage());
        }
    }
}
