<?php
use Migrations\AbstractMigration;

class AlterMastTicket11092019 extends AbstractMigration
{
    /**
     * Change Method.
     *
     * More information on this method is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-change-method
     * @return void
     */
    public function change()
    {
        try {
            $table = $this->table('mast_ticket');
            $table
                ->changeColumn('start_time','datetime', [
                    'null' => true
                ])
                ->changeColumn('end_time','datetime', [
                    'null' => true
                ])
                ->update();
        } catch (\Exception $ex) {
            echo ($ex->getMessage());
        }
    }
}
