<?php
use Migrations\AbstractMigration;
use Phinx\Db\Adapter\MysqlAdapter;

class CreateJobManager extends AbstractMigration
{
    /**
     * Change Method.
     *
     * More information on this method is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-change-method
     * @return void
     */
    public function change()
    {
        try {
            if (!$this->table('job_manager')->exists()) {
                $table = $this->table('job_manager', [
                    'id' => false,
                    'primary_key' => 'id',
                    'encoding' => 'utf8',
                    'collation' => 'utf8_general_ci'
                ])
                    ->addColumn('id', 'biginteger', [
                        'identity' => true
                    ]);
                $table
                    ->addColumn('job_type', 'integer', [
                        'limit' => MysqlAdapter::INT_SMALL,
                        'null' => false
                    ])
                    ->addColumn('job_name', 'string', [
                        'limit' => 255,
                        'null' => false
                    ])
                    ->addColumn('job_status', 'integer', [
                        'limit' => MysqlAdapter::INT_SMALL,
                        'null' => false
                    ])
                    ->addColumn('job_start_time', 'datetime', [
                        'default' => null,
                        'null' => true
                    ])
                    ->addColumn('job_end_time', 'datetime', [
                        'default' => null,
                        'null' => true
                    ])
                    ->addColumn('file_name', 'string', [
                        'default' => null,
                        'limit' => 255,
                        'null' => true
                    ])
                    ->addColumn('del_flg', 'integer', [
                        'default' => 0,
                        'limit' => MysqlAdapter::INT_TINY,
                        'null' => false
                    ])
                    ->addColumn('created_by', 'biginteger', [
                        'default' => null,
                        'null' => true
                    ])
                    ->addColumn('created_at', 'datetime', [
                        'default' => null,
                        'null' => true
                    ])
                    ->addColumn('updated_by', 'biginteger', [
                        'default' => null,
                        'null' => true
                    ])
                    ->addColumn('updated_at', 'datetime', [
                        'default' => null,
                        'null' => true
                    ])
                    ->addColumn('deleted_by', 'biginteger', [
                        'default' => null,
                        'null' => true
                    ])
                    ->addColumn('deleted_at', 'datetime', [
                        'default' => null,
                        'null' => true
                    ]);
                $table->create();
            }
        } catch (\Exception $ex) {
            echo ($ex->getMessage());
        }
    }
}
