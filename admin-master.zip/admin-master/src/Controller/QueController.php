<?php
/**
 * Created by PhpStorm.
 * User: dat.tnt
 * Date: 2019/10/23
 * Time: 12:24
 */
namespace App\Controller;

use App\Libs\ConfigUtil;
use App\Libs\ValueUtil;
use App\Libs\DateUtil;
use App\Libs\ExportDataUtil;
use Cake\Event\Event;
use Cake\ORM\TableRegistry;
use App\Libs\EncryptUtil;

/**
 * Que content controller
 */
class QueController extends AppAdminController
{
    /**
     * Override beforeFilter callback
     *
     * @return \Cake\Network\Response|null|void
     */
    public function beforeFilter(Event $event) {
        parent::beforeFilter($event);
        // Load common model
        $this->loadModel('Questionnaire');
        $this->loadModel('MastQuestionnaireParts');
        $this->loadModel('QuestionnaireDetail');
        $this->loadModel('QuestionnaireResult');
        $this->loadModel('Staff');
        $this->loadModel('Order');
        $this->loadModel('MastTicket');
    }

    /**
     * A008 イベント一覧
     */
    public function a008() {
        $session = $this->getRequest()->getSession();
        // check and get session
        $params = [];
        $isSearch = FALSE;
        if ($session->check('Que.a008')) {
            $params = $session->read('Que.a008');
            $isSearch = TRUE;
            $this->set([
                'searchData' => $params,
            ]);
        }
        // process submit form
        if ($this->getRequest()->is(['post'])) {
            $searchData = $this->getRequest()->getData();
            // delete old and write new session
            $session->delete('Que.a008');
            $session->write('Que.a008', $searchData);

            // reload page
            return $this->redirect(['action' => 'a008']);
        }
        // get questionnaire
        $result = $this->Questionnaire->search($params);
        $questionnaires = $this->paginate($result, ['limit' => ConfigUtil::get('paginate.ten_pages')]);
        $this->set(compact('questionnaires', 'isSearch'));
        $this->set('baseURL', $this->getUrlTemplate(null, 'fan/fan/f0031/'));
        $this->set('_serialize', ['questionnaires']);
    }

    /**
     * A009イベント登録
     */
    public function a009($id = null) {
        header('Cache-Control: no cache');
        $screenId = 'a009';
        // handler error and get data
        if (!empty($id) && !is_numeric($id)) {
            return $this->redirect(['controller' => 'Top', 'action' => 'error']);
        } else if(!empty($id) && is_numeric($id)) {
            // edit screen
            $mastQuestionnaireParts = $this->MastQuestionnaireParts->getDataMastQuestionnaireParts($id);
            $questionnaire = $this->Questionnaire->getQuestionnaireById($id);
            if (empty($questionnaire)) {
                return $this->redirect(['controller' => 'Top', 'action' => 'error']);
            }
            $paymentFlag = $questionnaire['payment_flag'];
            $questionnaireDetail = $this->QuestionnaireDetail->getQuestionnaireDetail($id);
            $mastTicket = $this->MastTicket->getMastTicketByQuestionnaireId($id, ['screen' => 'a009'])->toArray();
        } else {
            // register screen
            $questionnaire = $this->Questionnaire->newEntity();
            $questionnaireDetail = [];
        }
        // submit handling
        if ($this->getRequest()->is(['post', 'patch', 'put'])) {
            $data = $this->getRequest()->getData();
            $queryComponent = $this->loadComponent('Query');
            $tblQuestionnaire = 'Questionnaire';
            $tblMastTicket = 'MastTicket';
            if(!isset($data['flag_form_event_ticket'])) {
                //-------------------- save questionnaire data --------------------//
                $params = $this->processDataOnA009($data, $id);
                // save questionnaire data
                $questionnaire = $queryComponent->saveTable($tblQuestionnaire, $params, $id);
                // save error
                if(is_bool($questionnaire)) {
                    $this->set(compact('mastQuestionnaireParts', 'questionnaire',
                        'questionnaireDetail', 'mastTicket', 'screenId'));
                    if(!empty($id)) {
                        return $this->Flash->error(ConfigUtil::getMessage('UPDATE_FAILURE'));
                    } else {
                        return $this->Flash->error(ConfigUtil::getMessage('CREATE_FAILURE'));
                    }
                }
                // show errors
                if(empty($questionnaire->getErrors())) {
                    //-------------------- upload image --------------------//
                    $this->processUploadImage($questionnaire, $params);
                    //if payment_flag = 0 set all unit_price of mastTicket = 0
                    if($questionnaire['payment_flag'] == ValueUtil::get('questionnaire.payment_flag_val')['no_payment']) {
                        $questionnaireUpdate = [
                            'unit_price' => 0,
                            'free_shipping' => ValueUtil::get('mast_ticket.free_shipping_val')['no_shipping']
                        ];
                        if(!empty($mastTicket)) {
                            foreach ($mastTicket as $ticketEvent) {
                                $queryComponent->saveTable($tblMastTicket, $questionnaireUpdate, $ticketEvent['id']);
                            }
                        }
                    }
                    $paymentFlag = $questionnaire['payment_flag'];
                    $this->set(compact('mastQuestionnaireParts', 'questionnaire',
                        'questionnaireDetail', 'mastTicket', 'screenId', 'paymentFlag'));
                    if(!empty($id)) {
                        $this->Flash->success(ConfigUtil::getMessage('UPDATE_SUCCESS'));
                    } else {
                        $this->Flash->success(ConfigUtil::getMessage('CREATE_SUCCESS'));
                    }
                    return $this->redirect(['action' => 'a009', $questionnaire->id]);
                }
                $this->showErrors($questionnaire->getErrors());
                $this->set(compact('data'));
            } else {
                //-------------------- save mast_ticket data --------------------//
                // refresh data
                $data = $this->processDataEventTicketForA009($data, $id);
                $modeSave = $data['mode_save'];
                $modeSaveVal = ValueUtil::get('common.mode_save');
                // create record
                if($modeSave == $modeSaveVal['add'] || $modeSave == $modeSaveVal['copy']) {
                    $mastTicketSave = $queryComponent->saveTable($tblMastTicket, $data, null, 'MastTicketA009');
                }
                // update record
                if($modeSave == $modeSaveVal['edit']) {
                    $mastTicketSave = $queryComponent->saveTable($tblMastTicket, $data, $data['id'], 'MastTicketA009');
                }
                // save error
                if(is_bool($mastTicketSave)) {
                    $this->set(compact('mastQuestionnaireParts', 'questionnaire',
                        'questionnaireDetail', 'mastTicket', 'screenId'));
                    if($modeSave == $modeSaveVal['edit']) {
                        return $this->Flash->error(ConfigUtil::getMessage('UPDATE_FAILURE'));
                    } else {
                        return $this->Flash->error(ConfigUtil::getMessage('CREATE_FAILURE'));
                    }
                }
                // show errors
                if(empty($mastTicketSave->getErrors())) {
                    $this->set(compact('mastQuestionnaireParts', 'questionnaire',
                        'questionnaireDetail', 'mastTicket', 'screenId'));
                    if($modeSave == $modeSaveVal['edit']) {
                        $this->Flash->success(ConfigUtil::getMessage('UPDATE_SUCCESS'));
                    } else {
                        $this->Flash->success(ConfigUtil::getMessage('CREATE_SUCCESS'));
                    }
                    return $this->redirect(['action' => 'a009', $id]);
                }
                $this->showErrors($mastTicketSave->getErrors());
            }
        }
        $this->set(compact('mastQuestionnaireParts', 'questionnaire',
            'questionnaireDetail', 'mastTicket', 'screenId', 'paymentFlag'));
    }

    /**
     * A010イベント編集
     */
    public function a010($id) {
        header('Cache-Control: no cache');
        if (empty($id) || !is_numeric($id)) {
            return $this->redirect(['controller' => 'Top', 'action' => 'error']);
        }
        $screenId = 'a010';
        // get mast_questionnaire_parts
        $mastQuestionnaireParts = $this->MastQuestionnaireParts->getDataMastQuestionnaireParts($id);
        // get questionnaire and questionnaire_detail
        $questionnaire = $this->Questionnaire->getQuestionnaireById($id);
        if (empty($questionnaire)) {
            return $this->redirect(['controller' => 'Top', 'action' => 'error']);
        }
        $paymentFlag = $questionnaire['payment_flag'];
        $questionnaireDetail = $this->QuestionnaireDetail->getQuestionnaireDetail($id);
        $mastTicket = $this->MastTicket->getMastTicketByQuestionnaireId($id, ['screen' => 'a009'])->toArray();
        // submit handling
        if ($this->getRequest()->is(['post', 'patch', 'put'])) {
            $data = $this->getRequest()->getData();
            $queryComponent = $this->loadComponent('Query');
            $tblQuestionnaire = 'Questionnaire';
            $tblMastTicket = 'MastTicket';
            if(!isset($data['flag_form_event_ticket'])) {
                //-------------------- save questionnaire data --------------------//
                $params = $this->processDataOnA009($data, $id);
                // save questionnaire data
                $questionnaire = $queryComponent->saveTable($tblQuestionnaire, $params, $id);
                // save error
                if(is_bool($questionnaire)) {
                    $this->set(compact('mastQuestionnaireParts', 'questionnaire',
                        'questionnaireDetail', 'screenId', 'mastTicket'));
                    return $this->Flash->error(ConfigUtil::getMessage('UPDATE_FAILURE'));
                }
                // show errors
                if(empty($questionnaire->getErrors())) {
                    //-------------------- upload image --------------------//
                    $this->processUploadImage($questionnaire, $params);
                    //if payment_flag = 0 set all unit_price of mastTicket = 0
                    if($questionnaire['payment_flag'] == ValueUtil::get('questionnaire.payment_flag_val')['no_payment']) {
                        $questionnaireUpdate = [
                            'unit_price' => 0,
                            'free_shipping' => ValueUtil::get('mast_ticket.free_shipping_val')['no_shipping']
                        ];
                        foreach ($mastTicket as $ticketEvent) {
                            $queryComponent->saveTable($tblMastTicket, $questionnaireUpdate, $ticketEvent['id']);
                        }
                    }
                    $paymentFlag = $questionnaire['payment_flag'];
                    $this->set(compact('mastQuestionnaireParts', 'questionnaire',
                        'questionnaireDetail', 'screenId', 'mastTicket', 'paymentFlag'));
                    $this->Flash->success(ConfigUtil::getMessage('UPDATE_SUCCESS'));
                    return $this->redirect(['action' => 'a010', $questionnaire->id]);
                }
                $this->showErrors($questionnaire->getErrors());
                $this->set(compact('data'));
            } else {
                //-------------------- save mast_ticket data --------------------//
                // refresh data
                $data = $this->processDataEventTicketForA009($data, $id);
                $modeSave = $data['mode_save'];
                $modeSaveVal = ValueUtil::get('common.mode_save');
                // create record
                if($modeSave == $modeSaveVal['add'] || $modeSave == $modeSaveVal['copy']) {
                    $mastTicketSave = $queryComponent->saveTable($tblMastTicket, $data, null, 'MastTicketA009');
                }
                // update record
                if($modeSave == $modeSaveVal['edit']) {
                    $mastTicketSave = $queryComponent->saveTable($tblMastTicket, $data, $data['id'], 'MastTicketA009');
                }
                // save error
                if(is_bool($mastTicketSave)) {
                    $this->set(compact('mastQuestionnaireParts', 'questionnaire',
                        'questionnaireDetail', 'mastTicket', 'screenId'));
                    if($modeSave == $modeSaveVal['edit']) {
                        return $this->Flash->error(ConfigUtil::getMessage('UPDATE_FAILURE'));
                    } else {
                        return $this->Flash->error(ConfigUtil::getMessage('CREATE_FAILURE'));
                    }
                }
                // show errors
                if(empty($mastTicketSave->getErrors())) {
                    $this->set(compact('mastQuestionnaireParts', 'questionnaire',
                        'questionnaireDetail', 'mastTicket', 'screenId'));
                    if($modeSave == $modeSaveVal['edit']) {
                        $this->Flash->success(ConfigUtil::getMessage('UPDATE_SUCCESS'));
                    } else {
                        $this->Flash->success(ConfigUtil::getMessage('CREATE_SUCCESS'));
                    }
                    return $this->redirect(['action' => 'a010', $id]);
                }
                $this->showErrors($mastTicketSave->getErrors());
            }
        }
        $this->set(compact( 'questionnaire', 'questionnaireDetail',
            'mastQuestionnaireParts', 'screenId', 'mastTicket', 'paymentFlag'));
    }

    /**
     * A009/A010イベント編集 - 追加ボタン
     */
    public function createQuestionnaireDetail($questionnaireId) {
        if ($this->getRequest()->is(['post'])) {
            try {
                // get data
                $data = $this->getRequest()->getData();
                $mastQuestionnaireId = $data['mastQuestionnairePartsId'];
                // get questionnaire by id
                $questionnaire = $this->Questionnaire->getQuestionnaireById($questionnaireId);
                // get mast_questionnaire by id
                $mastQuestionnaireParts = $this->MastQuestionnaireParts->getMastQuestionnairePartsById($mastQuestionnaireId);
                // check id exists
                if (empty($questionnaire) || empty($mastQuestionnaireParts)) {
                    $this->returnForAjax('error', 'create');
                }
                // check questionnaire.publish_flag = 1:public
                if ($questionnaire->publish_flag == ValueUtil::get('questionnaire.publish_flag_val')['public']) {
                    $this->returnForAjax('error', 'create');
                }
                // check label maxlength
                if (mb_strlen($data['labelName']) > 255) {
                    $this->returnForAjax('error', 'create', ConfigUtil::getMessage('ECL002', ['ラベル名', 255, mb_strlen($data['labelName'])]));
                }
                // check only one record for input_type from 1 -> 9
                if (in_array($mastQuestionnaireParts->input_type, ValueUtil::get('tok.ONLY_ONE'))) {
                    $countQuestionnaireDetail = $this->QuestionnaireDetail->countQuestionnaireDetailByType($questionnaireId, $mastQuestionnaireParts->input_type);
                    if ($countQuestionnaireDetail > 0) {
                        $this->returnForAjax('error', 'create', ConfigUtil::getMessage('ONLY_ONE_RECORD'));
                    }
                }
                // save questionnaire detail
                $params = $this->processDataOnCreateQuestionnaireDetail($data, $mastQuestionnaireParts, $questionnaire);
                $queryComponent = $this->loadComponent('Query');
                $questionnaireDetail = $queryComponent->saveTable('QuestionnaireDetail', $params, null);
                if(empty($questionnaireDetail->getErrors())) {
                    // not error
                    $this->returnForAjax('success', 'create', '', $questionnaireDetail);
                }
            } catch (\Exception $e) {
                $this->returnForAjax('error', 'create');
            }
        }
        $this->returnForAjax('error', 'create');
    }

    /**
     * update sort for questionnaire detail
     * @return [type] [description]
     */
    public function updateSortQuestionnaireDetail() {
        if ($this->getRequest()->is(['post'])) {
            $data = $this->getRequest()->getData();
            $questionnaireDetails = $data['detail'];
            $queryComponent = $this->loadComponent('Query');
            try {
                // upload column sort QuestionnaireDetail
                $result = $this->QuestionnaireDetail->updateArrayQuestionnaireDetails($questionnaireDetails);
                // if update false
                if ($result) {
                    // update successful
                    $this->returnForAjax('success', 'update');
                }
                // show error
                $this->returnForAjax('error', 'update');
            } catch (\Exception $e) {
                $this->returnForAjax('error', 'update');
            }
        }
    }

    /**
     * A009/A010イベント登録 - 削除ボタン
     */
    public function deleteQuestionnaireDetail() {
        if ($this->getRequest()->is(['post'])) {
            try {
                // load model
                $this->loadModel('QuestionnaireResultDetail');
                // get data
                $data = $this->getRequest()->getData();
                // if questionnaire_result_detail table has least one data, return error message ECL056
                $countQuestionnaireResultDetail = $this->QuestionnaireResultDetail->getCountByQuestionnaireDetail($data['id']);
                if ($countQuestionnaireResultDetail > 0) {
                    $this->returnForAjax('error', 'delete', ConfigUtil::getMessage('ECL056'));
                }
                $questionnaireDetail = $this->QuestionnaireDetail->getQuestionnaireDetailById($data['id']);
                $data = [
                    'mast_questionnaire_id' => $questionnaireDetail->mast_questionnaire_parts_id,
                    'input_type' => $questionnaireDetail->input_type
                ];
                // delete questionnaire detail
                if ($this->QuestionnaireDetail->delete($questionnaireDetail)) {
                    $this->returnForAjax('success', 'delete', '', $data);
                }
            } catch (\Exception $e) {
                $this->returnForAjax('error', 'delete');
            }
        }
        $this->returnForAjax('error', 'delete');
    }

    /**
     * A011 申込データ一覧
     */
    public function a011($questionnaireId = null) {
        //Check valid param id
        if(empty($questionnaireId) || !is_numeric($questionnaireId)){
            return $this->redirect(['controller' => 'Top', 'action' => 'error']);
        }
        $quest = $this->Questionnaire->getQuestionnaireById($questionnaireId);
        //Check no exists record of questionnaire.id
        if(empty($quest)){
            return $this->redirect(['controller' => 'Top', 'action' => 'error']);
        }
        //Set session
        $session = $this->getRequest()->getSession();
        $params = [];
        //Check searching data session
        if($session->check('Que.a011')){
            $params = $session->read('Que.a011');
            $this->set(['searchData' => $params]);
        }
        //Process request post
        if($this->getRequest()->is(['post'])){
            $data = $this->getRequest()->getData();
            //Export csv
            if(isset($data['csv-export-all']) || isset($data['csv-export-condition'])){
                $this->exportCsv($data);
            }
            //Write session
            $session->delete('Que.a011');
            $session->write('Que.a011', $data);
            //Redirect a020
            if(isset($data['mail-btn'])){
                if($session->check('Fan.a005')){
                    $session->delete('Fan.a005');
                }
                return $this->redirect(['controller' => 'mai', 'action' => 'a020']);
            }
            //Reload page
            return $this->redirect(['action' => 'a011', $questionnaireId]);
        }
        //Get records from database then paginate result
        $result = $this->Order->searchA011($params, $questionnaireId); // OrderTask #65554
        $disabled = true;
        $winningFlgVal = ValueUtil::get('order.winning_flg_val');
        //Disabled = false if all in 1 record have quesitonnaire_reuslt.winning_flg = 1
        if(!empty($result->toArray())){
            foreach($result as $order){
                if(!empty($order['winning_flg']) || $order['winning_flg'] == $winningFlgVal['winning']){
                    $disabled = false;
                    break;
                }
            }
        }
        $orderResult = $this->paginate($result, ['limit' => ConfigUtil::get('paginate.ten_pages')]);
        //Get value from libs
        $sex = ValueUtil::get('fan.sex');
        $area = ValueUtil::get('fan.area');
        $jobType = ValueUtil::get('fan.job_type');
        $winningFlg = ValueUtil::get('order.winning_flg');
        //Set parametters to view
        $this->set(compact('questionnaireId', 'orderResult', 'sex', 'area', 'jobType', 'winningFlg', 'winningFlgVal', 'disabled'));
    }

    /**
     * Update winning_flg by ajax
     *
     * @throws \Exception
     */
    public function updateWinningFlg() {
        //Process request ajax
        if($this->getRequest()->is(['ajax'])){
            $data = $this->getRequest()->getData();
            $id = $data['id'];
            $this->loadComponent('Query');
            $table = 'order';
            //Updated
            $result = $this->Query->saveTable($table, $data, $id);
            if($result){
                $this->returnForAjax('success', 'update');
            } else {
                $this->returnForAjax('error', 'update');
            }
        }
    }

    /**
     * Update questionnaire_result.receive_date and questionnaire_result.memo
     *
     * @return \Cake\Http\Response|null
     * @throws \Exception
     */
    public function updatePopupA011() {
        if($this->getRequest()->is(['post'])){
            $data = $this->getRequest()->getData();
            $id = $data['id'];
            $data['receive_date'] = !empty($data['receive_date']) ? $data['receive_date'] : null;
            $data['memo'] = !empty($data['memo']) ? $data['memo'] : null;
            $this->loadComponent('Query');
            $table = 'order';
            //Updated
            $result = $this->Query->saveTable($table, $data, $id);
            if($result){
                return $this->redirect(['action' => 'a011', $result['questionnaire_id']]);
            }
        }
    }

    /**
     * Export csv
     *
     * @param $data
     */
    public function exportCsv($data) {
        //Get params data
        $params = $data;
        $winningFlgVal = ValueUtil::get('questionnaire_result.winning_flg_val');
        //Search and export csv with conditions by winning_flg = 1
        if(isset($params['winning_flg']) && $params['winning_flg'] == $winningFlgVal['winning']){
            //Search by winning_flg = 1
            $orders = $this->Order->searchA011($params, $params['questionnaire_id'])
                ->where(['Order.winning_flg' => $winningFlgVal['winning']])
                ->toArray();
        } else { //Search and export all
            $orders = $this->Order->searchA011($params, $params['questionnaire_id'])->toArray();
        }
        //Get header csv
        $header = ValueUtil::get('questionnaire_result.header_csv');
        $headerQuestResultDetail = ValueUtil::get('questionnaire_result_detail.header_csv');
        //Set options value
        $options = [
            'sex' => ValueUtil::get('fan.sex'),
            'area' => ValueUtil::get('fan.area'),
            'job_type' => ValueUtil::get('fan.job_type'),
            'winning_flg' => ValueUtil::get('questionnaire_result.winning_flg'),
            'payment_method' => ValueUtil::get('questionnaire_result.payment_method'),
            'input_type' => ValueUtil::get('questionnaire_result_detail.input_type')
        ];
        $list = [];
        $list[] = $header;
        foreach($orders as $result){
            $arrData = [];
            $result['fan.id'] = isset($result['fan']['id']) ? $result['fan']['id'] : '';
            $result['fan.user_name'] = isset($result['fan']['user_name']) ? $result['fan']['user_name'] : '';
            $result['fan.email'] = isset($result['fan']['email']) ? $result['fan']['email'] : '';
            $result['questionnaire_result.id'] = isset($result['id']) ? $result['id'] : '';
            $result['questionnaire_id'] = isset($result['questionnaire_id']) ? $result['questionnaire_id'] : '';
            $result['payment_method'] = isset($result['payment_method']) && isset($options['payment_method'][$result['payment_method']]) ? $options['payment_method'][$result['payment_method']] : '';
            $result['total_no_tax'] = isset($result['total_no_tax']) ? $result['total_no_tax'] : '';
            $result['tax'] = isset($result['tax']) ? $result['tax'] : '';
            $result['total_amount'] = isset($result['total_amount']) ? $result['total_amount'] : '';
            $result['credit_token'] = isset($result['credit_token']) ? $result['credit_token'] : '';
            $result['winning_flg'] = isset($result['winning_flg']) && isset($options['winning_flg'][$result['winning_flg']]) ? $options['winning_flg'][$result['winning_flg']] : '';
            $result['receive_date'] = !empty($result['receive_date']) ? DateUtil::getJapaneseDate($result['receive_date'])  : '';
            $result['memo'] = isset($result['memo']) ? $result['memo'] : '';
            $result['created_by'] = isset($result['created_by']) ? $this->Staff->getStaffById($result['created_by'])['user_name'] : '';
            $result['created_at'] = !empty($result['created_at']) ? DateUtil::getJapaneseDate($result['created_at'], false, true)  : '';
            $result['updated_by'] = isset($result['updated_by']) ? $this->Staff->getStaffById($result['updated_by'])['user_name'] : '';
            $result['updated_at'] = !empty($result['updated_at']) ? DateUtil::getJapaneseDate($result['updated_at'], false, true)  : '';
            $result['deleted_by'] = isset($result['deleted_by']) ? $this->Staff->getStaffById($result['deleted_by'])['user_name'] : '';
            $result['deleted_at'] = !empty($result['deleted_at']) ? DateUtil::getJapaneseDate($result['deleted_at'], false, true)  : '';
            //Add column name to csv
            foreach($header as $colName => $colTitle){
                $arrData[$colName] = !empty($result[$colName]) ? $result[$colName] : '';
            }
            $tmpDataDetail = [];
            if(!empty($result['questionnaire_result_detail'])){
                foreach($result['questionnaire_result_detail'] as $key => $detail){
                    $detail['questionnaire_result_detail.id'] = isset($detail['id']) ? $detail['id'] : '';
                    $detail['questionnaire_detail_id'] = isset($detail['questionnaire_detail_id']) ? $detail['questionnaire_detail_id'] : '';
                    $detail['sort'] = isset($detail['sort']) ? $detail['sort'] : '';
                    $detail['label_name'] = isset($detail['label_name']) ? $detail['label_name'] : '';
                    $detail['input_type'] = isset($detail['input_type']) && isset($options['input_type'][$detail['input_type']]) ? $options['input_type'][$detail['input_type']] : '';
                    $detail['answer'] = isset($detail['answer']) ? $detail['answer'] : '';
                    $listDetail = [
                        'questionnaire_result_detail.id' => $detail['questionnaire_result_detail.id'],
                        'questionnaire_detail_id' => $detail['questionnaire_detail_id'],
                        'sort' => $detail['sort'],
                        'label_name' => $detail['label_name'],
                        'input_type' => $detail['input_type'],
                        'answer' => $detail['answer']
                    ];
                    //Set new array questionnaire_result_detail
                    array_push($tmpDataDetail, $listDetail);
                    $list[0] = array_merge($list[0], [
                        'questionnaire_result_detail.id'.$key => $headerQuestResultDetail['questionnaire_result_detail.id'],
                        'questionnaire_detail_id'.$key => $headerQuestResultDetail['questionnaire_detail_id'],
                        'sort'.$key => $headerQuestResultDetail['sort'],
                        'label_name'.$key => $headerQuestResultDetail['label_name'],
                        'input_type'.$key => $headerQuestResultDetail['input_type'],
                        'answer'.$key => $headerQuestResultDetail['answer'],
                    ]);
                }
            }
            //Process add questionnaire_result_detail
            foreach($tmpDataDetail as $key => $dataDetail){
                $arrData = array_merge($arrData, [
                    'questionnaire_result_detail.id'.$key => $dataDetail['questionnaire_result_detail.id'],
                    'questionnaire_detail_id'.$key => $dataDetail['questionnaire_detail_id'],
                    'sort'.$key => $dataDetail['sort'],
                    'label_name'.$key => $dataDetail['label_name'],
                    'input_type'.$key => $dataDetail['input_type'],
                    'answer'.$key => $dataDetail['answer'],
                ]);
            }
            $list[] = $arrData;
        }
        //Csv file name
        $fileName = 'A011'.'_'.DateUtil::getFileNameByCurrentTime().'.csv';
        //Excecute export csv
        $exportData = new ExportDataUtil();
        $exportData->exportCSV($list, $fileName);
    }

    /**
     * Process upload image before save to Questionnaire table
     *
     * @param $questionnaire
     * @param $data
     * @throws \Exception
     */
    private function processUploadImage($questionnaire, $data) {
        $imgData = [
            'image_url1' => $data['image_url1'],
            'image_url2' => $data['image_url2'],
            'image_url3' => $data['image_url3'],
            'thumb_image' => $data['thumb_image']
        ];
        // load components
        $queryComponent = $this->loadComponent('query');
        $fileComponent = $this->loadComponent('FileAwsS3');
        foreach ($imgData as $key => $img) {
            switch ($img['error']) {
                case UPLOAD_ERR_NO_FILE:
                    if(empty($data["{$key}_url"])){
                        $data[$key] = null;
                    } else {
                        // keep the same old image
                        $data[$key] = $data["{$key}_url"];
                    }
                    break;
                case UPLOAD_ERR_OK:
                    $imgUpload = !empty($img) ? $fileComponent->uploadFileToS3($img, 'questionnaire', $questionnaire->id, $key) : '';
                    $data[$key] = isset($imgUpload->data->file_path) ? current($imgUpload->data->file_path) : $data[$key];
                    break;
            }
        }
        // save image to db
        $queryComponent->saveTable('Questionnaire', $data, $questionnaire->id);
    }

    /**
     * Process data before display on a009 screen
     *
     * @param $params
     * @param $id
     * @return mixed
     */
    private function processDataOnA009($params, $id = null) {
        $params['del_flg'] = ValueUtil::get('common.del_flg_val')['undeleted'];
        $params['start_time'] = !empty($params['start_time']) ? $params['start_time'] : null;
        $params['end_time'] = !empty($params['end_time']) ? $params['end_time'] : null;
        $params['publish_flag'] = !is_null($params['publish_flag']) ? $params['publish_flag'] : null;
        $params['hash_url'] = null;
        // if choose publish_flag = 限定公開
        if ($params['publish_flag'] === ValueUtil::get('questionnaire.publish_flag_val')['limit_public']) {
            // if empty questionare_id
            if (is_null($id)) {
                //Calculate id value of new record
                $params['id'] = $this->Questionnaire->getLastIdBeforeInsert() + ValueUtil::get('common.increase_one');
                $id = $params['id'];
            }
            //Encrypt id
            $params['hash_url'] = EncryptUtil::encryptAes256((string)$id);
        }
        //Replace empty value with null value
        foreach ($params as  $key => $value) {
            if ($value == '') {
                $params[$key] = null;
            }
        }
        return $params;
    }

    /**
     * Process data on CreateQuestionnaireDetail function
     *
     * @param $params
     * @param $mastQuestionnaireParts
     * @param $questionnaire
     * @return mixed
     */
    private function processDataOnCreateQuestionnaireDetail($params, $mastQuestionnaireParts, $questionnaire) {
        // 必須フラグ
        $mandatoryFlg = ValueUtil::get('common.is_false');
        if ($params['required'] == 'required') {
            $mandatoryFlg = ValueUtil::get('common.is_true');
        }
        // questionnaire_detail.input_format
        $inputFormat = $mastQuestionnaireParts->input_format;
        if (!empty($params['options'])) {
            // convert data
            $inputFormatObj = json_decode($mastQuestionnaireParts->input_format, true);
            $inputFormatObj['options'] = explode(',', $params['options']);
            $inputFormat = json_encode($inputFormatObj);
        }
        // get sort value
        $sort = $this->QuestionnaireDetail->getMaxSortQuestionnaireDetail($questionnaire->id);
        $params['questionnaire_id']            = $questionnaire->id;
        $params['mast_questionnaire_parts_id'] = $mastQuestionnaireParts->id;
        $params['input_type']                  = $mastQuestionnaireParts->input_type;
        $params['sort']                        = (int)$sort['maxSort'] + ValueUtil::get('common.increase_one');
        if (in_array($mastQuestionnaireParts->input_type, ValueUtil::get('tok.ONLY_ONE'))) {
            $params['label_name']              = $mastQuestionnaireParts->label_name;
        } else {
            $params['label_name']              = $params['labelName'];
        }
        $params['label_name'] = ($params['label_name'] == '') ? null : $params['label_name'];
        $params['input_format']                = $inputFormat;
        $params['mandatory_flag']              = $mandatoryFlg;
        $params['del_flg']                     = ValueUtil::get('common.del_flg_val')['undeleted'];
        return $params;
    }

    /**
     * A011_1 チケット編集
     * A011_1
     */
    public function a0111($questionnaireId = null) {
        //Check valid param id
        if(empty($questionnaireId) || !is_numeric($questionnaireId)){
            return $this->redirect(['controller' => 'Top', 'action' => 'error']);
        }
        $quest = $this->Questionnaire->getQuestionnaireById($questionnaireId);
        //Check no exists record of questionnaire.id
        if(empty($quest)){
            return $this->redirect(['controller' => 'Top', 'action' => 'error']);
        }
        //get data mast_ticket by questionnaireId
        $mastTicketDatas = $this->MastTicket->getMastTicketByQuestionnaireId($questionnaireId)->toArray();
        //Set parametters to view
        $this->set(compact('mastTicketDatas', 'questionnaireId'));
    }

    /**
     * Get mast_ticket load by ajax
     */
    public function getMastTicketByAjax() {
        if($this->getRequest()->is(['post'])) {
            $data = $this->getRequest()->getData();
            $idMastTicket = $data['id_mast_ticket'];
            $mastTicket = $this->MastTicket->getMastTicketById($idMastTicket);
            $mastTicket['exp_from'] = !empty($mastTicket['exp_from']) ? $mastTicket['exp_from']->format('Y/m/d') : null;
            $mastTicket['exp_to'] = !empty($mastTicket['exp_to']) ? $mastTicket['exp_to']->format('Y/m/d') : null;
            $mastTicket['start_time'] = !empty($mastTicket['start_time']) ? $mastTicket['start_time']->format('Y/m/d H:i') : null;
            $mastTicket['end_time'] = !empty($mastTicket['end_time']) ? $mastTicket['end_time']->format('Y/m/d H:i') : null;
            echo !empty($mastTicket) ? json_encode($mastTicket) : null;
        }
        exit();
    }

    /**
     * Process data event ticket for A009
     *
     * @param $params
     * @param $id
     * @return mixed
     */
    public function processDataEventTicketForA009($params, $id) {
        $modeSaveVal = ValueUtil::get('common.mode_save');
        $ticketTypeVal = ValueUtil::get('mast_ticket.ticket_type_val');
        // create record for mode 1(add) and mode 3(copy)
        if($params['mode_save'] == $modeSaveVal['add'] || $params['mode_save'] == $modeSaveVal['copy']) {
            $params['questionnaire_id'] = $id;
            $params['ticket_type'] = $ticketTypeVal['event_ticket'];
            $params['total_number'] = $params['number'];
        }
        // update record for mode 2(edit)
        if($params['mode_save'] == $modeSaveVal['edit']) {
            $mastTicket = $this->MastTicket->getMastTicketById($params['id']);
            if(!empty($mastTicket)) {
                $params['total_number'] = $mastTicket['total_number'] + ($params['number'] - $mastTicket['number']);
                $params['lower_limit'] = !empty($params['lower_limit']) ? $params['lower_limit'] : 1;
            }
        }
        $params['exp_from'] = !empty($params['exp_from']) ? $params['exp_from'] : null;
        $params['exp_to'] = !empty($params['exp_to']) ? $params['exp_to'] : null;
        $params['start_time'] = !empty($params['start_time']) ? $params['start_time'] : null;
        $params['end_time'] = !empty($params['end_time']) ? $params['end_time'] : null;
        $params['free_shipping'] = isset($params['free_shipping']) ? $params['free_shipping'] :
            (isset($params['free_shipping_hidden']) ? $params['free_shipping_hidden'] : null);
        //Replace empty value with null value
        foreach ($params as  $key => $value) {
            if ($value == '') {
                $params[$key] = null;
            }
        }
        return $params;
    }

    /**
     * Delete physically record mast_ticket
     *
     * @param null $id
     * @return \Cake\Http\Response|null
     */
    public function deleteMastTicket($id = null) {
        try {
            // get record by id
            $mastTicket = $this->MastTicket->getMastTicketById($id);
            if(!empty($mastTicket)) {
                // delete physical
                $this->MastTicket->delete($mastTicket);
                $this->Flash->success(ConfigUtil::getMessage('DELETE_SUCCESS'));
                return $this->redirectAfterDelete('a009');
            }
            $this->Flash->error(ConfigUtil::getMessage('DELETE_FAILURE'));
            return $this->referer();
        } catch (\Exception $e) {
            return $this->redirect(['controller' => 'Top', 'action' => 'error']);
        }
    }
}
