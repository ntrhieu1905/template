<?php
namespace App\Model\Table;

use Aura\Intl\Exception;
use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;
use Cake\ORM\TableRegistry;
use Cake\Database\Expression\QueryExpression;
use App\Libs\ValueUtil;
use App\Libs\ConfigUtil;

/**
 * Staff Model
 *
 * @method \App\Model\Entity\Staff get($primaryKey, $options = [])
 * @method \App\Model\Entity\Staff newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Staff[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Staff|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Staff saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Staff patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Staff[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Staff findOrCreate($search, callable $callback = null, $options = [])
 */
class StaffTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('staff');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');
        //Add behavior
        $this->addBehavior('UpdateSync');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->allowEmptyString('id', null, 'create');

        $validator
            ->notEmptyString('user_name', ConfigUtil::getMessage("ECL001", ["氏名"]))
            ->add('user_name', 'max-length', [
                'rule' => function ($value, $context) {
                    $len = mb_strlen($value);
                    if($len > 50) {
                        return ConfigUtil::getMessage("ECL002", ["氏名", 50, $len]);
                    }
                    return true;
            }]);

        $validator
            ->notEmptyString('email', ConfigUtil::getMessage("ECL001", ["メールアドレス"]))
            ->add('email', 'max-length', [
                'rule' => function ($value, $context) {
                    $len = mb_strlen($value);
                    if($len > 255) {
                        return ConfigUtil::getMessage("ECL002", ["メールアドレス", 255, $len]);
                    }
                    return true;
            }])
            /*->add('email', [
                'unique' => [
                    'rule' => 'validateUnique',
                    'provider' => 'table',
                    'message' => ConfigUtil::getMessage("ECL049", ["メールアドレス"])
                ]]
            )*/
            ->add('email', 'mail-rule', [
                'rule' => 'email',
                'message' => ConfigUtil::getMessage("ECL007")]);

        $validator
            ->notEmptyString('password', ConfigUtil::getMessage("ECL001", ["パスワード"]))
            ->add('password', 'max-length', [
                'rule' => function ($value, $context) {
                    $len = mb_strlen($value);
                    if($len > 20) {
                        return ConfigUtil::getMessage("ECL002", ["パスワード", 20, $len]);
                    }
                    return true;
                }])
            ->add('password', 'min-length', [
                'rule' => function ($value, $context) {
                    $len = mb_strlen($value);
                    if($len < 10) {
                        return ConfigUtil::getMessage("ECL003", ["パスワード", 10, $len]);
                    }
                    return true;
                }])
            ->add('password', 'pass-rule', [
                'rule' => function ($value, $context) {
                    $regex_character = "/^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)[a-zA-Z\d]{9,21}$/";
                    preg_match($regex_character, $value, $match);
                    if(!$match) {
                        return ConfigUtil::getMessage("ECL050", ["パスワード"]);
                    }
                    return true;
                }]);

        $validator
            ->notEmptyString('user_flg', ConfigUtil::getMessage("ECL001", ["権限"]));

        $validator
            ->notEmptyString('area', ConfigUtil::getMessage("ECL001", ["エリア"]));

        $validator
            ->dateTime('last_login')
            ->allowEmptyDateTime('last_login');

        $validator
            ->notEmptyString('del_flg');

        $validator
            ->allowEmptyString('created_by');

        $validator
            ->dateTime('created_at')
            ->allowEmptyDateTime('created_at');

        $validator
            ->allowEmptyString('updated_by');

        $validator
            ->dateTime('updated_at')
            ->allowEmptyDateTime('updated_at');

        $validator
            ->allowEmptyString('deleted_by');

        $validator
            ->dateTime('deleted_at')
            ->allowEmptyDateTime('deleted_at');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
//        $rules->add($rules->isUnique(['email']));
        return $rules;
    }

    /**
     * Authenticate query for login
     *
     * @param Query $query
     * @param array $options
     * @return Query
     */
    public function findAuth(\Cake\ORM\Query $query, array $options) {
        $delFlg = ValueUtil::get('common.del_flg_val');
        $delVal = isset($delFlg['undeleted']) ? $delFlg['undeleted'] : 0;
        $query->where([
            'user_flg IN' => ValueUtil::get('common.user_flg_key'),
            'OR' => ['del_flg IS' => null, 'del_flg' => $delVal]
        ]);
        return $query;
    }

    /**
     * Get Staff data
     *
     * @return \App\Model\Entity\Staff|null
     */
    public function getStaffLogin($condistions = []) {
        try {
            $delFlg = ValueUtil::get('common.del_flg_val');
            $delVal = isset($delFlg['undeleted']) ? $delFlg['undeleted'] : 0;
            $email = isset($condistions['email']) ? $condistions['email'] : '';
            $password = isset($condistions['password']) ? $condistions['password'] : '';
            $result = $this->find()
                        ->where([
                            'email' => $email,
                            'password' => $password,
                            'user_flg IN' => ValueUtil::get('common.user_flg_key'),
                            'del_flg' => $delVal,
                            'deleted_at IS NULL'
                        ]);
            return $result;
        } catch (\Exception $e) {
            return null;
        }
    }

    /**
     * Get all Staff data
     *
     * @return \App\Model\Entity\Staff|null
     */
    public function getDatasStaff() {
        try {
            $delFlg = ValueUtil::get('common.del_flg_val');
            $delVal = isset($delFlg['undeleted']) ? $delFlg['undeleted'] : 0;
            $result = $this->find()
                ->order([
                    'created_at DESC'
                ]);
            return $result;
        } catch (\Exception $e) {
            return null;
        }
    }

    /**
     * set del_flg
     *
     * @param $id
     * @param $del_flag
     * @return \App\Model\Entity\Staff|bool
     */
    public function setDelFlg($id, $del_flag) {
        try{
            $staff = $this->find()->where(['id' => $id])-> first();
            //Set delete flag
            $staff->set('del_flg', $del_flag);
            //Update data
            $this->getConnection()->begin();
            $result = $this->save($staff);
            if($result){
                $this->getConnection()->commit();
            } else {
                $this->getConnection()->rollback();
            }
            return $result;
        } catch(\Exception $e) {
            $this->getConnection()->rollback();
            return false;
        }
    }

    /**
     * get data Staff
     *
     * @param $id
     * @return \App\Model\Entity\Staff|bool
     */
    public function getStaffById($id) {
        try {
            $result = $this->find()
                ->where([
                    'id' => $id
                ])->first();
            return $result;
        } catch (\Exception $e) {
            return null;
        }
    }
}
