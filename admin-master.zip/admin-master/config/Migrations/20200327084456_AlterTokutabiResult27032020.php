<?php
use Migrations\AbstractMigration;
use Phinx\Db\Adapter\MysqlAdapter;

class AlterTokutabiResult27032020 extends AbstractMigration
{
    /**
     * Change Method.
     *
     * More information on this method is available here:
     * https://book.cakephp.org/phinx/0/en/migrations.html#the-change-method
     * @return void
     */
    public function change()
    {
        $table = $this->table('tokutabi_result');
        $table
            ->addColumn('del_flg', 'integer', [
                'default' => 0,
                'null'    => false,
                'limit'   => MysqlAdapter::INT_TINY,
                'after'   => 'memo3'
            ])
            ->update();
    }
}
