<?php
use Migrations\AbstractMigration;

class AlterQuestionnaire31032020 extends AbstractMigration
{
    /**
     * Change Method.
     *
     * More information on this method is available here:
     * https://book.cakephp.org/phinx/0/en/migrations.html#the-change-method
     * @return void
     */
    public function change()
    {
        $table = $this->table('questionnaire');
        $table
            ->changeColumn('host_area', 'string', [
                'default' => null,
                'null'    => true,
                'limit'   => 10
            ])
            ->changeColumn('venue', 'string', [
                'default' => null,
                'null'    => true,
                'limit'   => 50
            ])
            ->changeColumn('adress', 'string', [
                'default' => null,
                'null'    => true,
                'limit'   => 50
            ])
            ->changeColumn('latitude', 'string', [
                'default' => null,
                'null'    => true,
                'limit'   => 50
            ])
            ->changeColumn('longitude', 'string', [
                'default' => null,
                'null'    => true,
                'limit'   => 50
            ])
            ->changeColumn('event_date', 'string', [
                'default' => null,
                'null'    => true,
                'limit'   => 50
            ])
            ->changeColumn('mail', 'string', [
                'default' => null,
                'null'    => true,
                'limit'   => 50
            ])
            ->changeColumn('phone_number', 'string', [
                'default' => null,
                'null'    => true,
                'limit'   => 50
            ])
            ->changeColumn('business_hour', 'string', [
                'default' => null,
                'null'    => true,
                'limit'   => 50
            ])
            ->addColumn('shipping_cost', 'biginteger', [
                'default' => 0,
                'null'    => false,
                'limit'   => 10,
                'after'   => 'application_limit'
            ])
            ->addColumn('free_shipping', 'biginteger', [
                'default' => 0,
                'null'    => false,
                'limit'   => 10,
                'after'   => 'shipping_cost'
            ])
            ->update();
    }
}
