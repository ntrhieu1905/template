<?php
use Migrations\AbstractMigration;
use Phinx\Db\Adapter\MysqlAdapter;

class UpdateFanv2 extends AbstractMigration
{
    /**
     * Change Method.
     *
     * More information on this method is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-change-method
     * @return void
     */
    public function change()
    {
        try {
            $table = $this->table('fan');
            $table
                ->addColumn('company_code', 'string', [
                    'default' => null,
                    'after' => 'working_company',
                    'limit' => 50,
                    'null' => true
                ])
                ->save();
        }
        catch (\Exception $ex) {
            echo ($ex->getMessage());
        }

    }
}
