$(document).ready(function() {
    $('.datepicker').datepicker();
    $('#birthday_from_csv').val($('[name="birthday_from"]').val());
    $('[name="birthday_from"]').change(function () {
        $('#birthday_from_csv').val($(this).val());
    });
    $('#birthday_to_csv').val($('[name="birthday_to"]').val());
    $('[name="birthday_to"]').change(function () {
        $('#birthday_to_csv').val($(this).val());
    });
    //CSV export
    $('#csv-export-tmp').click(function () {
        var form = $('form');
        form.each(function (i, obj) {
            var frma028 = $('#frma028').find('input').clone();
            if($(obj).is(':hidden')) {
                $(obj).append(frma028);
            }
        });
        //append to postLink form then click csv-export button
        setTimeout(
            function()
            {
                $('#csv-export').click();
            }, 500); //Set the time 500 to wait for the button to click next time
    });
    // Check validate
    $('#popup-frmA028').validate({
        rules: {
            memo1: {
                maxlength: 255,
            },
            memo2: {
                maxlength: 255,
            },
            memo3: {
                maxlength: 255,
            }
        },
        messages: {
            memo1: {
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), params, $(input).val().length]);
                }
            },
            memo2: {
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), params, $(input).val().length]);
                }
            },
            memo3: {
                maxlength: function(params, input) {
                    return $.validator.messages.maxlength([$(input).data('label'), params, $(input).val().length]);
                }
            }
        },
        submitHandler: function(form) {
            $('#popup-updateA028').attr('disabled', true);
            form.submit();
        }
    });

    //Pass value in modal
    $('#sur-a028').on('show.bs.modal', function(e) {
        $('#popup-frmA028').validate().resetForm();
        $('#popup-frmA028').attr('action',$('#url-popup-a028').val());
        $('#quest-result-id').val($(e.relatedTarget).data('id'));
        $('#memo1').val($(e.relatedTarget).data('memo1'));
        $('#memo2').val($(e.relatedTarget).data('memo2'));
        $('#memo3').val($(e.relatedTarget).data('memo3'));
        $('#screen-id').val($(e.relatedTarget).data('screen_id'));
    });
    $('#sur-a028').on('hidden.bs.modal', function(e) {
        $(this).find('#memo1').removeClass('error-message');
        $(this).find('#memo2').removeClass('error-message');
        $(this).find('#memo3').removeClass('error-message');
        $(this).find('#memo-error').remove();
        //Process css focus
        $(this).parent().find('#popup-'+$(this).find('#quest-result-id').val()).css({
            'background': '#3b99fc',
            'color': '#fff',
            'border': '1px solid #3b99fc'
        });
    });
});
