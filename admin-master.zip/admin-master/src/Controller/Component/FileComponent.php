<?php
/**
 * Created by PhpStorm.
 * User: dat.tnt
 * Date: 2019/10/23
 * Time: 12:24
 */
namespace App\Controller\Component;

use App\Libs\ValueUtil;
use Cake\Controller\Component;
use Cake\Controller\ComponentRegistry;
use Cake\Filesystem\Folder;
use App\Libs\ConfigUtil;

class FileComponent extends Component
{

    const NG = 201;
    const OK = 200;

    public $allowedExtension;
    public $imageSize;
    public $resizeWidth = 300;
    public $resizeWidthCus = 800;
    public $resizeHeight = 200;
    public $resizeHeightCus = 300;

    function __construct(ComponentRegistry $registry, array $config = [])
    {
        parent::__construct($registry, $config);
        $this->allowedExtension = explode('|', ValueUtil::get('common.img_extension'));
        $this->imageSize = ValueUtil::get('common.img_size') * 1024 * 1024;
    }

    /**
     * upload file
     *
     * @param $file
     * @param $maxSize
     * @return object
     */
    public function uploadFile($file, $screen, $id, $imgType = null, $fileType = 'img') {
        $response = [];
        $resData = [];
        $code = self::OK;
        $message = "OK";
        //$uploadFolder = ValueUtil::get('common.image_path')  . $screen . DS . $id;
        $uploadFolder = ConfigUtil::get('image_path')  . $screen . DS . $id;
        // path save to db
        $path = $screen . '/' . $id;
        // get file size
        $maxSize = $this->imageSize;
        if ($imgType == 'thumb_img') {
            $maxSize = ValueUtil::get('common.thumb_img_size') * 1024 * 1024;
        }
        // get file source
        if ($fileType === 'img') {
            $source = $file['tmp_name'];
        } else {
            $source = $file;
        }
        $fileSize = filesize($source);

        if ($fileType == 'img') {
            // image file
            $data = getimagesize($source);
            if (empty($data) || !is_array($data)) {
                $response['code'] = self::NG;
                $response['message'] = ConfigUtil::getMessage("ECL022", [ValueUtil::get('common.img_extension')]);
                $response['data'] = (object) $resData;

                return (object) $response;
            }
            list($srcWidth, $srcHeight, $type) = $data;
            $ext = $this->_image_type_to_extension($type);
            $allowFile = $this->allowedExtension;
        } else {
            // another file
            $infoFile = pathinfo($file);
            $ext = $infoFile['extension'];
            $allowFile = explode(',', $fileType);
        }

        // Allow certain file formats
        if (!in_array($ext, $allowFile)) {
            $code = self::NG;
            if ($fileType == 'img') {
                $message =  ConfigUtil::getMessage("ECL022", [ValueUtil::get('common.img_extension')]);
            } else {
                $message =  ConfigUtil::getMessage("ECL022", [$fileType]);
            }
        } elseif ($fileSize > $maxSize) {
            // Check file size
            $code = self::NG;
            $message =  ConfigUtil::getMessage("ECL023", [$this->human_filesize($maxSize)]);
        } else {
            $now = \DateTime::createFromFormat('U.u', number_format(microtime(true), 6, '.', ''));
            $targetfile = substr($now->format("YmdHisu"), 0, -2) . "." . $ext;
            // create folder upload
            $this->mkdir($uploadFolder);
            //get destination path image
            $dstPath = $uploadFolder . DS . $targetfile;
            if ($fileType == 'img') {
                // resize image
                if($imgType == 'title_image') {
                    //if image is title image
                    $resizeWidth = $this->resizeWidthCus;
                    $resizeHeight = $this->resizeHeightCus;
                } else {
                    $resizeWidth = $this->resizeWidth;
                    $resizeHeight = $this->resizeHeight;
                }
                // create image
                $dst = ImageCreateTrueColor($resizeWidth, $resizeHeight);
                $backgroundColor = ImageColorAllocate($dst, 255, 255, 255);
                ImageFilledRectangle($dst, 0, 0, $resizeWidth, $resizeHeight, $backgroundColor);
                switch ($ext) {
                    case 'png':
                        $src = imagecreatefrompng($source);
                        break;
                    case 'jpg':
                    case 'jpeg':
                        $src = imagecreatefromjpeg($source);
                        break;
                    default :
                        return false;
                        break;
                }
                imagecopyresampled($dst, $src, 0, 0, 0, 0, $resizeWidth, $resizeHeight, $srcWidth, $srcHeight);
                imagejpeg($dst, $dstPath, 100);
                @chmod($dst, 0755);
                $resData['file_path'] = [$path . '/' . $targetfile];
            } else {
                if (rename($source, $uploadFolder . '/' . $targetfile)) {
                    // just save relative path
                    $resData['file_path'] = [$path . '/' . $targetfile];
                } else {
                    $code = self::NG;
                    $message = 'System error';
                }
            }
        }
        // return code, message and file path
        $response['code'] = $code;
        $response['message'] = $message;
        $response['data'] = (object) $resData;

        return (object) $response;
    }

    /**
     * @param $imagetype
     * @return bool|string
     */
    private function _image_type_to_extension($imagetype)
    {
        if (empty($imagetype)) {
            return false;
        }
        switch ($imagetype) {
            case IMAGETYPE_GIF      :
                return 'gif';
            case IMAGETYPE_JPEG     :
                return 'jpg';
            case IMAGETYPE_PNG      :
                return 'png';
            case IMAGETYPE_SWF      :
                return 'swf';
            case IMAGETYPE_PSD      :
                return 'psd';
            case IMAGETYPE_BMP      :
                return 'bmp';
            case IMAGETYPE_TIFF_II  :
                return 'tiff';
            case IMAGETYPE_TIFF_MM  :
                return 'tiff';
            case IMAGETYPE_JPC      :
                return 'jpc';
            case IMAGETYPE_JP2      :
                return 'jp2';
            case IMAGETYPE_JPX      :
                return 'jpf';
            case IMAGETYPE_JB2      :
                return 'jb2';
            case IMAGETYPE_SWC      :
                return 'swc';
            case IMAGETYPE_IFF      :
                return 'aiff';
            case IMAGETYPE_WBMP     :
                return 'wbmp';
            case IMAGETYPE_XBM      :
                return 'xbm';
            default                 :
                return false;
        }
    }

    /**
     * @param $bytes
     * @param int $decimals
     * @return string
     */
    public function human_filesize($bytes, $decimals = 0)
    {
        $sz = 'BKMGTP';
        $factor = floor((strlen($bytes) - 1) / 3);
        return sprintf("%.{$decimals}f", $bytes / pow(1000, $factor)) . @$sz[$factor] . 'B';
    }

    /**
     * @param $file
     * @return mixed|string
     */
    public function ext($file)
    {
        return mb_strtolower(trim(mb_strrchr($file, '.'), '.'));
    }

    /**
     * @param $targetdir
     * @return bool
     */
    public function mkdir($targetdir)
    {
        if (!is_dir($targetdir)) {
            $dir = new Folder($targetdir, true, 0755);
            if (!$dir) {
                return false;
            }
        }
        return true;
    }

}
