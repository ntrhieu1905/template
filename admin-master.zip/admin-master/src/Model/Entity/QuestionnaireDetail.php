<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * QuestionnaireDetail Entity
 *
 * @property int $id
 * @property int|null $questionnaire_id
 * @property int|null $mast_questionnaire_parts_id
 * @property int $input_type
 * @property int|null $sort
 * @property string|null $label_name
 * @property string|null $input_format
 * @property int|null $mandatory_flag
 * @property int $del_flg
 * @property int|null $created_by
 * @property \Cake\I18n\FrozenTime|null $created_at
 * @property int|null $updated_by
 * @property \Cake\I18n\FrozenTime|null $updated_at
 * @property int|null $deleted_by
 * @property \Cake\I18n\FrozenTime|null $deleted_at
 *
 * @property \App\Model\Entity\Questionnaire $questionnaire
 * @property \App\Model\Entity\MastQuestionnairePart $mast_questionnaire_part
 * @property \App\Model\Entity\QuestionnaireResultDetail[] $questionnaire_result_detail
 */
class QuestionnaireDetail extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'questionnaire_id' => true,
        'mast_questionnaire_parts_id' => true,
        'input_type' => true,
        'sort' => true,
        'label_name' => true,
        'input_format' => true,
        'mandatory_flag' => true,
        'del_flg' => true,
        'created_by' => true,
        'created_at' => true,
        'updated_by' => true,
        'updated_at' => true,
        'deleted_by' => true,
        'deleted_at' => true,
        'questionnaire' => true,
        'mast_questionnaire_part' => true,
        'questionnaire_result_detail' => true
    ];
}
