<?php
/**
 * Created by PhpStorm.
 * User: leminhtoan
 * Date: 3/27/17
 * Time: 14:36
 */

namespace App\Model\Behavior;


use App\Libs\ConfigUtil;
use Cake\Datasource\EntityInterface;
use Cake\Event\Event;
use Cake\Log\Log;
use Cake\ORM\Behavior;

class LogUpdateBehavior extends Behavior
{
    /**
     * Before update event
     *
     * @param Event $event
     * @param EntityInterface $entity
     * @param \ArrayObject $options the options passed to the save method
     */
    public function beforeSave(Event $event, EntityInterface $entity, \ArrayObject $options)
    {
        // Log all data before update/insert to DB
        Log::info([
            'Log' => 'Insert/Update Table',
            'Action' => $entity->isNew() ? "Insert" : "Update",
            'Table Data'  => print_r($entity, true)
        ]);
    }

}