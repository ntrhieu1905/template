<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Tokutabi Entity
 *
 * @property int $id
 * @property string|null $title
 * @property string|null $description
 * @property int $publish_flag
 * @property \Cake\I18n\FrozenTime|null $start_time
 * @property \Cake\I18n\FrozenTime|null $end_time
 * @property int $survey_type
 * @property string|null $hash_url
 * @property int $del_flg
 * @property int|null $created_by
 * @property \Cake\I18n\FrozenTime|null $created_at
 * @property int|null $updated_by
 * @property \Cake\I18n\FrozenTime|null $updated_at
 * @property int|null $deleted_by
 * @property \Cake\I18n\FrozenTime|null $deleted_at
 *
 * @property \App\Model\Entity\TokutabiDetail[] $tokutabi_detail
 * @property \App\Model\Entity\TokutabiResult[] $tokutabi_result
 * @property \App\Model\Entity\TokutabiResultDetail[] $tokutabi_result_detail
 */
class Tokutabi extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'id' => false,
        '*' => true,
    ];
}
