<?php
/**
 * Created by PhpStorm.
 * User: leminhtoan
 * Date: 3/28/17
 * Time: 16:49
 */

namespace App\Log;

use App\Libs\ConfigUtil;
use Cake\Log\Engine\FileLog;
use Cake\Routing\Router;

/**
 * Customize file log
 * Class CustomFileLog
 * @package App\Log
 */
class CustomFileLog extends FileLog
{
    /**
     * Override log function
     * Implements writing to log files.
     *
     * @param string $level The severity level of the message being written.
     *    See Cake\Log\Log::$_levels for list of possible levels.
     * @param string $message The message you want to log.
     * @param array $context Additional information about the logged message
     * @return bool success of write.
     */
    public function log($level, $message, array $context = [])
    {
        $request    = Router::getRequest();

        $clientIp   = '-';
        $sessionId  = '-';
        $loginId    = '-';
        $role       = '-';
        if($request){
            $clientIp   = $request->clientIp();
            $session    = $request->getSession();
            $sessionId  = $session->id();
            $user       = ConfigUtil::getLoginUser();
            $loginId    = isset($user["id"]) ? $user["id"] : "";
            $role       = isset($user["role"]) ? $user["role"] : "";
        }

        $displayLevel = $level;
        if(in_array($level, ['critical', 'alert', 'emergency'])){
            $displayLevel = 'FATAL';
        }

        $message = $this->_format($message, $context);
        $output = date('Y-m-d H:i:s') . ', ' . ucfirst($displayLevel) . ', ' . $sessionId . ', ' . $clientIp .
                                        ', ' . $loginId . ', ' . $role .': ' . $message . "\n";
        $filename = $this->_getFilename($level);
        if (!empty($this->_size)) {
            $this->_rotateFile($filename);
        }

        $pathname = $this->_path . $filename;
        $mask = $this->_config['mask'];
        if (empty($mask)) {
            return file_put_contents($pathname, $output, FILE_APPEND);
        }

        $exists = file_exists($pathname);
        $result = file_put_contents($pathname, $output, FILE_APPEND);
        static $selfError = false;

        if (!$selfError && !$exists && !chmod($pathname, (int)$mask)) {
            $selfError = true;
            trigger_error(vsprintf(
                'Could not apply permission mask "%s" on log file "%s"',
                [$mask, $pathname]
            ), E_USER_WARNING);
            $selfError = false;
        }

        return $result;
    }
}