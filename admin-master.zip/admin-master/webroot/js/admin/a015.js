$(document).ready(function() {
    // 価格, 残枚数 not negative
    $('body').on('input', '#unit-price',function () {
        this.value = (this.value < 0) ? Math.abs(this.value) : this.value;
    });
    $('body').on('input', '#number',function () {
        this.value = (this.value < 0) ? Math.abs(this.value) : this.value;
    });
});