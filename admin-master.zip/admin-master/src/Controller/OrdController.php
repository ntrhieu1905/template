<?php
/**
 * Created by PhpStorm.
 * User: dat.tnt
 * Date: 2019/10/23
 * Time: 12:24
 */
namespace App\Controller;

use App\Libs\ConfigUtil;
use App\Libs\DateUtil;
use App\Libs\ExportDataUtil;
use App\Libs\ValueUtil;
use Cake\Event\Event;
use Cake\ORM\TableRegistry;

/**
 * order content controller
 */
class OrdController extends AppAdminController
{
    /**
     * Override beforeFilter callback
     *
     * @return \Cake\Network\Response|null|void
     */
    public function beforeFilter(Event $event) {
        parent::beforeFilter($event);
        //Load common model
        $this->loadModel('order');
    }

    /**
     * A013 チケット購入一覧
     *
     * @return \Cake\Http\Response|null
     */
    public function a013()
    {
        //Get login user data
        $session = $this->getRequest()->getSession();
        //Check searching data session
        $params = [];
        if ($session->check('Ord.a013')) {//When have session
            $params = $session->read('Ord.a013');
            $this->set([
                'searchData' => $params,
            ]);
        }
        //Process after submit
        if ($this->getRequest()->is(['post'])) {
            $searchData = $this->getRequest()->getData();
            //Write session
            $session->delete('Ord.a013');
            $session->write('Ord.a013', $searchData);
            //Reload page
            return $this->redirect(['action' => 'a013']);
        }
        //Get records from database then paginate result
        $result = $this->Order->search($params);
        $orders = $this->paginate($result, ['limit' => ConfigUtil::get('paginate.ten_pages')]);
        //Show list evaluation
        $this->set(compact('orders'));
        $this->set('_serialize', ['orders']);
    }

    /**
     * Export Csv
     * screen A013 - A0131
     */
    public function exportCsv()
    {
        if ($this->getRequest()->is(['post'])) {
            $params = $this->getRequest()->getData();
            //Get records from database then paginate result
            $orders = $this->Order->search($params, true)->toArray();
            //Get header
            $header = ValueUtil::get('order.header_csv');
            //Screen A0131
            if(isset($params['screen_id_a0131'])) {
                $orders = $this->Order->search($params, true, ['screenA0131' => true])->toArray();
                $header = ValueUtil::get('order.header_csv_a0131');
            }
            $fieldIsNumeric = ValueUtil::get('order.csv_field_is_numeric');
            $options = [
                'screen_id_a0131' => isset($params['screen_id_a0131']) ? $params['screen_id_a0131'] : '',
                'payment_method' => ValueUtil::get('order.payment_method'),
                'prefecture' => ValueUtil::get('order.prefecture'),
                'del_flg' => ValueUtil::get('common.del_flg'),
                'mas_category' => ValueUtil::get('mast_ticket.category'),
                'mas_area' => ValueUtil::get('mast_ticket.area'),
            ];
            $listOrders = [];
            $listOrders[] = $header;
            foreach ($orders as $order) {
                $arrData = [];
                $this->processOrderData($order, $options);
                //Add column name to csv
                foreach ($header as $colName => $colTitle) {
                    //Check in array is field numeric
                    if(in_array($colName, $fieldIsNumeric)) {
                        //Set value 0 by field numeric
                        $arrData[$colName] = !empty($order[$colName]) ? $order[$colName] : 0;
                    } else {
                        //Set value null by field normal text
                        $arrData[$colName] = !empty($order[$colName]) ? $order[$colName] : '';
                    }
                }
                $listOrders[] = $arrData;
            }
            //Csv file name
            $fileName = 'A013_' . DateUtil::getFileNameByCurrentTime() . '.csv';
            if(isset($params['screen_id_a0131'])) {
                $fileName = $params['screen_id_a0131'] . '_' . DateUtil::getFileNameByCurrentTime() . '.csv';
            }
            //Execute export csv
            $exportData = new ExportDataUtil();
            $exportData->exportCSV($listOrders, $fileName);
        }
    }

    /**
     * Process order data
     *
     * @param array $order
     * @param array $options
     */
    public function processOrderData($order = [], $options = [])
    {
        $order['id'] = !empty($order['id']) ? $order['id'] : '';
        $order['fan_id'] = !empty($order['fan_id']) ? $order['fan_id'] : '';
        if(isset($options['screen_id_a0131']) && !empty($options['screen_id_a0131'])) {
            $order['questionnaire_id'] = !empty($order['questionnaire_id']) ? $order['questionnaire_id'] : '';
        }
        $order['fan_user_name'] = !empty($order['fan_user_name']) ? $order['fan_user_name'] : '';
        $order['fan_user_kana'] = !empty($order['fan_user_kana']) ? $order['fan_user_kana'] : '';
        $order['order_date'] = !empty($order['order_date']) ? DateUtil::getJapaneseDate($order['order_date'], false, true) : '';
        $order['total_no_tax'] = !empty($order['total_no_tax']) ? $order['total_no_tax'] : 0;
        $order['tax'] = !empty($order['tax']) ? $order['tax'] : 0;
        $order['total_amount'] = !empty($order['total_amount']) ? $order['total_amount'] : 0;
        $order['payment_method'] = isset($order['payment_method']) && isset($options['payment_method'][$order['payment_method']]) ? $options['payment_method'][$order['payment_method']] : '';
        $order['credit_token'] = !empty($order['credit_token']) ? $order['credit_token'] : '';
        $order['receive_plan_date'] = !empty($order['receive_plan_date']) ? DateUtil::getJapaneseDate($order['receive_plan_date'], true) : '';
        $order['receive_date'] = !empty($order['receive_date']) ? DateUtil::getJapaneseDate($order['receive_date']) : '';
        $order['memo'] = !empty($order['memo']) ? $order['memo'] : '';
        $order['user_name'] = !empty($order['user_name']) ? $order['user_name'] : '';
        $order['mobile'] = !empty($order['mobile']) ? $order['mobile'] : '';
        $order['tel'] = !empty($order['tel']) ? $order['tel'] : '';
        $order['zip'] = !empty($order['zip']) ? $order['zip'] : '';
        $order['prefecture'] = isset($order['prefecture']) && isset($options['prefecture'][$order['prefecture']]) ? $options['prefecture'][$order['prefecture']] : '';
        $order['city'] = !empty($order['city']) ? $order['city'] : '';
        $order['address1'] = !empty($order['address1']) ? $order['address1'] : '';
        $order['address2'] = !empty($order['address2']) ? $order['address2'] : '';
        $order['del_flg'] = isset($order['del_flg']) && isset($options['del_flg'][$order['del_flg']]) ? $options['del_flg'][$order['del_flg']] : '';
        $order['created_at'] = !empty($order['created_at']) ? DateUtil::getJapaneseDate($order['created_at'], false, true) : '';
        $order['updated_at'] = !empty($order['updated_at']) ? DateUtil::getJapaneseDate($order['updated_at'], false, true) : '';
        $order['deleted_at'] = !empty($order['deleted_at']) ? DateUtil::getJapaneseDate($order['deleted_at'], false, true) : '';
        $order['created_by'] = !empty($order['created_staff']['user_name']) ? $order['created_staff']['user_name'] : '';
        $order['updated_by'] = !empty($order['updated_staff']['user_name']) ? $order['updated_staff']['user_name'] : '';
        $order['deleted_by'] = !empty($order['deleted_staff']['user_name']) ? $order['deleted_staff']['user_name'] : '';
        $order['ori_id'] = !empty($order['ori_id']) ? $order['ori_id'] : '';
        $order['ori_ticket_id'] = !empty($order['ori_ticket_id']) ? $order['ori_ticket_id'] : '';
        $order['mas_ticket_name'] = !empty($order['mas_ticket_name']) ? $order['mas_ticket_name'] : '';
        $order['mas_unit_price'] = !empty($order['mas_unit_price']) ? $order['mas_unit_price'] : 0;
        $order['mas_category'] = isset($order['mas_category']) && isset($options['mas_category'][$order['mas_category']]) ? $options['mas_category'][$order['mas_category']] : '';
        $order['mas_area'] = isset($order['mas_area']) && isset($options['mas_area'][$order['mas_area']]) ? $options['mas_area'][$order['mas_area']] : '';
        $order['ori_order_number'] = !empty($order['ori_order_number']) ? $order['ori_order_number'] : '';
        $order['ori_total_no_tax'] = !empty($order['ori_total_no_tax']) ? $order['ori_total_no_tax'] : 0;
    }

    /**
     * Update order.receive_date and order.memo
     * Screen A013 - A0131
     *
     * @return \Cake\Http\Response|null
     * @throws \Exception
     */
    public function updatePopupA013()
    {
        if ($this->getRequest()->is('post')) {
            $data = $this->getRequest()->getData();
            $id = $data['id'];
            $data['receive_date'] = !empty($data['receive_date']) ? $data['receive_date'] : null;
            $data['memo'] = !empty($data['memo']) ? $data['memo'] : null;
            //Update order
            $queryComponent = $this->loadComponent('Query');
            $OrdTable = 'Order';
            $result = $queryComponent->saveTable($OrdTable, $data, $id);
            //Check when save data not success
            if (is_bool($result)) {
                return $this->Flash->error(ConfigUtil::getMessage('UPDATE_FAILURE'));
            }
            //Show validate errors
            if (!empty($result->getErrors())) {
                // check screen_id to redirect
                if(isset($data['screen_id']) && $data['screen_id'] == 'A0131') {
                    $this->redirect(['controller' => 'Ord', 'action' => 'a0131']);
                } else {
                    $this->redirect(['controller' => 'Ord', 'action' => 'a013']);
                }
                return $this->showErrors($result->getErrors());
            }
            // check screen_id to redirect
            if(isset($data['screen_id']) && $data['screen_id'] == 'A0131') {
                return $this->redirect(['controller' => 'Ord', 'action' => 'a0131']);
            } else {
                return $this->redirect(['controller' => 'Ord', 'action' => 'a013']);
            }

        }
    }

    /**
     * A014 チケット購入詳細
     */
    public function a014($id = null) {
        //Check valid Id
        if(empty($id) || !is_numeric($id)) {
            return $this->redirect(['controller' => 'Top', 'action' => 'error']);
        }
        //get data of fan
        $order = $this->Order->getOrderById($id);
        if(empty($order)) {
            return $this->redirect(['controller' => 'Top', 'action' => 'error']);
        }
        //Show list evaluation
        $this->set(compact('order'));
    }

    /**
     * A013_1 イベントチケット購入一覧
     */
    public function a0131() {
        //Get login user data
        $session = $this->getRequest()->getSession();
        //Check searching data session
        $params = [];
        if ($session->check('Ord.a0131')) {//When have session
            $params = $session->read('Ord.a0131');
            $this->set([
                'searchData' => $params,
            ]);
        }
        //Process after submit
        if ($this->getRequest()->is(['post'])) {
            $searchData = $this->getRequest()->getData();
            //Write session
            $session->delete('Ord.a0131');
            $session->write('Ord.a0131', $searchData);
            //Reload page
            return $this->redirect(['action' => 'a0131']);
        }
        //Get records from database then paginate result
        $result = $this->Order->search($params, false, ['screenA0131' => true]);
        $orders = $this->paginate($result, ['limit' => ConfigUtil::get('paginate.ten_pages')]);
        //Show list evaluation
        $this->set(compact('orders'));
        $this->set('_serialize', ['orders']);
    }

    /**
     * A0141 イベントチケット購入詳細
     */
    public function a0141($id = null) {
        //Check valid Id
        if(empty($id) || !is_numeric($id)) {
            return $this->redirect(['controller' => 'Top', 'action' => 'error']);
        }
        //Get data of order
        $order = $this->Order->getOrderById($id);
        if(empty($order)) {
            return $this->redirect(['controller' => 'Top', 'action' => 'error']);
        }
        //Show list evaluation
        $this->set(compact('order'));
    }
}
