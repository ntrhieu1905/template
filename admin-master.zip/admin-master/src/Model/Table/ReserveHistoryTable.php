<?php
namespace App\Model\Table;

use App\Libs\ValueUtil;
use Cake\Database\Expression\QueryExpression;
use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * ReserveHistory Model
 *
 * @property \App\Model\Table\ShopsTable&\Cake\ORM\Association\BelongsTo $Shops
 * @property \App\Model\Table\MemsTable&\Cake\ORM\Association\BelongsTo $Mems
 * @property \App\Model\Table\CpnsTable&\Cake\ORM\Association\BelongsTo $Cpns
 * @property \App\Model\Table\InsTable&\Cake\ORM\Association\BelongsTo $Ins
 *
 * @method \App\Model\Entity\ReserveHistory get($primaryKey, $options = [])
 * @method \App\Model\Entity\ReserveHistory newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\ReserveHistory[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\ReserveHistory|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\ReserveHistory saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\ReserveHistory patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\ReserveHistory[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\ReserveHistory findOrCreate($search, callable $callback = null, $options = [])
 */
class ReserveHistoryTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('reserve_history');
        $this->setDisplayField('rsv_log_id');
        $this->setPrimaryKey('rsv_log_id');

        $this->belongsTo('Shops', [
            'foreignKey' => 'shop_id',
            'joinType' => 'INNER'
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('rsv_log_id')
            ->allowEmptyString('rsv_log_id', null, 'create');

        $validator
            ->dateTime('rsv_date')
            ->allowEmptyDateTime('rsv_date');

        $validator
            ->integer('rsv_count')
            ->allowEmptyString('rsv_count');

        $validator
            ->scalar('rsv_course')
            ->allowEmptyString('rsv_course');

        $validator
            ->scalar('rsv_coupon')
            ->allowEmptyString('rsv_coupon');

        $validator
            ->scalar('rsv_name')
            ->allowEmptyString('rsv_name');

        $validator
            ->scalar('rsv_kana')
            ->allowEmptyString('rsv_kana');

        $validator
            ->scalar('rsv_company')
            ->allowEmptyString('rsv_company');

        $validator
            ->scalar('rsv_tel')
            ->allowEmptyString('rsv_tel');

        $validator
            ->scalar('rsv_tel2')
            ->allowEmptyString('rsv_tel2');

        $validator
            ->scalar('rsv_email')
            ->allowEmptyString('rsv_email');

        $validator
            ->allowEmptyString('rsv_sex');

        $validator
            ->scalar('rsv_remark')
            ->allowEmptyString('rsv_remark');

        $validator
            ->dateTime('in_tsp')
            ->allowEmptyDateTime('in_tsp');

        $validator
            ->integer('rsv_course_price')
            ->allowEmptyString('rsv_course_price');

        $validator
            ->scalar('rsv_course_price_org')
            ->allowEmptyString('rsv_course_price_org');

        $validator
            ->notEmptyString('del_flg');

        $validator
            ->allowEmptyString('created_by');

        $validator
            ->dateTime('created_at')
            ->allowEmptyDateTime('created_at');

        $validator
            ->allowEmptyString('updated_by');

        $validator
            ->dateTime('updated_at')
            ->allowEmptyDateTime('updated_at');

        $validator
            ->allowEmptyString('deleted_by');

        $validator
            ->dateTime('deleted_at')
            ->allowEmptyDateTime('deleted_at');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['shop_id'], 'Shops'));
        return $rules;
    }

    /**
     * Search by conditions
     * @param $params
     * @return Query
     */
    public function search($params) {
        $query = $this->find()->where(['del_flg' => 0]);
        //Get params
        $shop_id = isset($params['id']) ? $params['id'] : '';
        $shop_name = isset($params['shop_name']) ? $params['shop_name'] : '';
        $start_date = isset($params['start_date']) ? $params['start_date'] : '';
        $end_date = isset($params['end_date']) ? $params['end_date'] : '';
        $rsv_name = isset($params['rsv_name']) ? $params['rsv_name'] : '';
        //search by ID
        if (strlen($shop_id) > 0) {
            if (is_numeric($shop_id)) {
                $query->andWhere(['ReserveHistory.shop_id' => $shop_id]);
            } else {
                $query->andWhere(['ReserveHistory.shop_id' => null]);
            }
        }
        //search by 来店予定日
        $conditions_date = [];
        if (strlen($start_date) > 0) {
            $start_date = date('Y-m-d', strtotime($start_date));
            $conditions_date['AND'][] = [new QueryExpression("DATE_FORMAT(ReserveHistory.rsv_date, '%Y-%m-%d') >= '$start_date'")];
        }
        if (strlen($end_date) > 0) {
            $end_date = date('Y-m-d', strtotime($end_date));
            $conditions_date['AND'][] = [new QueryExpression("DATE_FORMAT(ReserveHistory.rsv_date, '%Y-%m-%d') <= '$end_date'")];
        }
        $query->andWhere($conditions_date);
        //Search by Shop Name
        if (strlen($shop_name) > 0) {
            $query->andWhere(['ReserveHistory.shop_name LIKE' => $shop_name .'%']);
        }
        //Search by rsv_name
        if (strlen($rsv_name) > 0) {
            $query->andWhere(['ReserveHistory.rsv_name LIKE' => $rsv_name .'%']);
        }
        // get record undeleted
        $delFlg = ValueUtil::get('common.del_flg_val');
        $delVal = isset($delFlg['undeleted']) ? $delFlg['undeleted'] : 0;
        $query->andWhere([
            'del_flg' => $delVal,
            'deleted_at IS NULL',
        ]);
        //sort follow rsv_date
        $query->order(['ReserveHistory.rsv_date' => 'DESC']);
        return $query;
    }
}
