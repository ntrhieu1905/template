<?php
use Migrations\AbstractMigration;

class UpdateOrderItems extends AbstractMigration
{
    /**
     * Change Method.
     *
     * More information on this method is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-change-method
     * @return void
     */
    public function change()
    {
        try {
            $table = $this->table('order_items');
            $table->dropForeignKey('fan_id');
            $table->save();
        } catch (\Exception $ex) {
            echo ($ex->getMessage());
        }

        try {
            $table = $this->table('order_items');
            $table->removeColumn('fan_id');
            $table->save();
        } catch (\Exception $ex) {
            echo ($ex->getMessage());
        }
    }
}
