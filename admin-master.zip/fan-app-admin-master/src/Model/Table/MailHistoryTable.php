<?php
namespace App\Model\Table;

use App\Libs\ConfigUtil;
use App\Libs\ValueUtil;
use Cake\Database\Expression\QueryExpression;
use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * MailHistory Model
 *
 * @method \App\Model\Entity\MailHistory get($primaryKey, $options = [])
 * @method \App\Model\Entity\MailHistory newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\MailHistory[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\MailHistory|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\MailHistory saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\MailHistory patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\MailHistory[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\MailHistory findOrCreate($search, callable $callback = null, $options = [])
 */
class MailHistoryTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('mail_history');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');
        //Add behavior
        $this->addBehavior('UpdateSync');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->allowEmptyString('id', null, 'create');

        $validator
            ->notEmptyString('send_time', ConfigUtil::getMessage("ECL001", ["送信予定日時"]))
            ->add('send_time', 'datetime', [
                'rule' => ['datetime'],
                'message' => ConfigUtil::getMessage("ECL010", ['送信予定日時'])
            ]);

        $validator
            ->scalar('mail_from')
            ->maxLength('mail_from', 255)
            ->allowEmptyString('mail_from');

        $validator
            ->scalar('subject')
            ->notEmptyString('subject', ConfigUtil::getMessage("ECL001", ["件名"]))
            ->add('subject', 'max-length', [
                'rule' => function ($value, $context) {
                    $len = mb_strlen($value);
                    if ($len > 100) {
                        return ConfigUtil::getMessage("ECL002", ["件名", 100, $len]);
                    }
                    return true;
                }
            ]);

        $validator
            ->allowEmptyString('mail_template');

        $validator
            ->notEmptyString('mail_content', ConfigUtil::getMessage("ECL001", ["本文"]))
            ->add('mail_content', 'max-length', [
                'rule' => function ($value, $context) {
                    $len = mb_strlen($value);
                    if ($len > 2000) {
                        return ConfigUtil::getMessage("ECL002", ["本文", 2000, $len]);
                    }
                    return true;
                }
            ]);

        $validator
            ->scalar('send_to_file')
            ->add('send_to_file', 'max-length', [
                'rule' => function ($value, $context) {
                    $len = mb_strlen($value);
                    if ($len > 255) {
                        return ConfigUtil::getMessage("ECL002", ["件名", 255, $len]);
                    }
                    return true;
                }
            ])
            ->allowEmptyFile('send_to_file');

        $validator
            ->notEmptyString('del_flg');

        $validator
            ->allowEmptyString('created_by');

        $validator
            ->dateTime('created_at')
            ->allowEmptyDateTime('created_at');

        $validator
            ->allowEmptyString('updated_by');

        $validator
            ->dateTime('updated_at')
            ->allowEmptyDateTime('updated_at');

        $validator
            ->allowEmptyString('deleted_by');

        $validator
            ->dateTime('deleted_at')
            ->allowEmptyDateTime('deleted_at');

        return $validator;
    }

    /**
     * search by conditions
     * @param $params
     * @return Query
     */
    public function search($params) {
        $query = $this->find()->where(['1=1']);
        //Get params
        $subject = isset($params['subject']) ? $params['subject'] : '';
        $start_date = isset($params['start_date']) ? $params['start_date'] : '';
        $end_date = isset($params['end_date']) ? $params['end_date'] : '';
        //search by subject
        if (strlen($subject) > 0) {
            $query->andWhere(['MailHistory.subject LIKE' => '%'.$subject.'%']);
        }
        //search by date
        $conditions_date = [];
        if (strlen($start_date) > 0) {
            $start_date = date('Y-m-d', strtotime($start_date));
            $conditions_date['AND'][] = [new QueryExpression("DATE_FORMAT(MailHistory.send_time, '%Y-%m-%d') >= '$start_date'")];
        }

        if (strlen($end_date) > 0) {
            $end_date = date('Y-m-d', strtotime($end_date));
            $conditions_date['AND'][] = [new QueryExpression("DATE_FORMAT(MailHistory.send_time, '%Y-%m-%d') <= '$end_date'")];
        }
        $query->andWhere($conditions_date);
        // get record undeleted
        $delFlg = ValueUtil::get('common.del_flg_val');
        $delVal = isset($delFlg['undeleted']) ? $delFlg['undeleted'] : 0;
        $query->andWhere([
            'del_flg' => $delVal,
            'deleted_at IS NULL',
        ]);
        //sort follow send_time
        $query->order(['MailHistory.send_time' => 'DESC']);
        return $query;
    }

    /**
     * get data mail
     * @param null $id
     * @return array|\Cake\Datasource\EntityInterface|null
     */
    public function getMailById($id = null) {
        try {
            $delFlg = ValueUtil::get('common.del_flg_val');
            $delVal = isset($delFlg['undeleted']) ? $delFlg['undeleted'] : 0;
            $result = $this->find()
                ->where([
                    'id' => $id,
                    'del_flg' => $delVal,
                    'deleted_at IS NULL',
                ])->first();
            return $result;
        } catch (\Exception $e) {
            return null;
        }
    }

    /**
     * get last record
     * @return mixed
     */
    public function getLastRecordMailHistory()
    {
        $result = $this->find('all')->all();
        return $result->last();
    }
}
