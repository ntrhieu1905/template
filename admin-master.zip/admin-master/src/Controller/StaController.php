<?php
/**
 * Created by PhpStorm.
 * User: dat.tnt
 * Date: 2019/10/23
 * Time: 12:24
 */
namespace App\Controller;

use App\Libs\ConfigUtil;
use App\Libs\ValueUtil;
use Cake\Event\Event;
use Cake\ORM\TableRegistry;

/**
 * Sta content controller
 */
class StaController extends AppAdminController
{
    /**
     * Override beforeFilter callback
     *
     * @return \Cake\Network\Response|null|void
     */
    public function beforeFilter(Event $event) {
        parent::beforeFilter($event);
        //Load common model
        $this->loadModel('Staff');
    }

    /**
     * A002 社員一覧
     * A002
     */
    public function a002(){
        $staffs = $this->paginate($this->Staff->getDatasStaff(), ['limit' => ConfigUtil::get('paginate.ten_pages')]);
        $this->set(compact('staffs'));
    }

    /**
     * set del_flg
     *
     * @param $staff_id
     * @param $del_flag
     * @return \Cake\Http\Response|null
     */
    public function setDelFlg($staff_id = null, $del_flag = null) {
        //set del_flg
        $result = $this->Staff->setDelFlg($staff_id, $del_flag);
        if(!$result) {
            return $this->redirect(['controller' => 'Top', 'action' => 'error']);
        }
        //Reload page a002
        $this->redirectAfterDelete('a002');
    }

    /**
     * A003 社員登録
     * A003
     */
    public function a003(){
        $staffTable = 'Staff';
        if($this->getRequest()->is(['post', 'put', 'patch'])) {
            $params = $this->getRequest()->getData();
            //set last_login
            $params['last_login'] = date("Y/m/d H:i:s");
            //load query component
            $queryComponent = $this->loadComponent('Query');
            //Check duplicate email
            $staffExisted = $queryComponent->checkEmailExisted('Staff', $params['email'], $params['id_staff'])->first();
            if ($staffExisted) {
                return $this->Flash->error(ConfigUtil::getMessage('ECL049',['メールアドレス']));
            }
            //save staff data
            $staff = $queryComponent->saveTable($staffTable, $params);
            //check when save data not success
            if(is_bool($staff)) {
                $this->set(compact('staff'));
                return $this->Flash->error(ConfigUtil::getMessage('CREATE_FAILURE'));
            }
            if(empty($staff->getErrors())) {
                $this->Flash->success(ConfigUtil::getMessage('CREATE_SUCCESS'));
                return $this->redirect(['action' => 'a002']);
            }
            $this->showErrors($staff->getErrors());
        }
    }

    /**
     * A004 社員編集
     * A004
     */
    public function a004($id =null){
        //Check valid Id
        if(empty($id) || !is_numeric($id)){
            return $this->redirect(['controller' => 'Top', 'action' => 'error']);
        }
        //get data of staff
        $staff = $this->Staff->getStaffById($id);
        if(empty($staff)){
            return $this->redirect(['controller' => 'Top', 'action' => 'error']);
        }
        $staffTable = 'Staff';
        if($this->getRequest()->is(['post', 'put', 'patch'])) {
            $params = $this->getRequest()->getData();
            //load query component
            $queryComponent = $this->loadComponent('Query');
            //Check duplicate email
            $staffExisted = $queryComponent->checkEmailExisted('Staff', $params['email'], $params['id_staff'])->first();
            if ($staffExisted) {
                $this->set(compact('staff'));
                return $this->Flash->error(ConfigUtil::getMessage('ECL049',['メールアドレス']));
            }
            //process password
            if(!empty($params['password_edit'])) {
                $params['password'] = $params['password_edit'];
            }
            //save staff data
            $staff = $queryComponent->saveTable($staffTable, $params, $id);
            //check when save data not success
            if(is_bool($staff)) {
                $this->set(compact('staff'));
                return $this->Flash->error(ConfigUtil::getMessage('UPDATE_FAILURE'));
            }
            if(empty($staff->getErrors())) {
                $this->Flash->success(ConfigUtil::getMessage('UPDATE_SUCCESS'));
                return $this->redirect(['action' => 'a002']);
            }
            $this->showErrors($staff->getErrors());
        }
        $this->set(compact('staff'));
    }

    /**
     * Remote check exists email
     */
    public function checkExistsEmail() {
        if ($this->getRequest()->is(['post'])) {
            $data = $this->getRequest()->getData();
            $queryComponent = $this->loadComponent('Query');
            $fan = $queryComponent->checkEmailExisted('Staff', $data['email'], $data['id'])->first();
            echo $fan ? false : true;
        }
        exit();
    }
}