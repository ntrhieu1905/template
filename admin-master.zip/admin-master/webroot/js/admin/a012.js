$(document).ready(function () {
    // validation
    $('#res012').validate({
        ignore: [],
        focusInvalid: true,
        rules: {
            'start_date': {
                datetime: true,
            },
            'end_date': {
                datetime: true,
            },
        },
        messages: {
            'start_date': {
                datetime: $.validator.messages.datetime('公開日時'),
            },
            'end_date': {
                datetime: $.validator.messages.datetime('終了日時'),
            },
        },
        onfocusout: function(element) {
            this.element(element);
        },
        submitHandler: function(form) {
            $('#arr01Search').attr('disabled', true);
            form.submit();
        }
    });
    $('#csv-export-tmp').click(function () {
        var form = $('form');
        form.each(function (i, obj) {
            var frma012 = $('#res012').find('input').clone();
            if($(obj).is(':hidden')) {
                $(obj).append(frma012);
            }
        });
        //append to postLink form then click csv-export button
        setTimeout(
            function()
            {
                $('#csv-export').click();
            }, 500); //Set the time 500 to wait for the button to click next time
    });
});
