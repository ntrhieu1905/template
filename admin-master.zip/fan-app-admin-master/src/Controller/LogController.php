<?php
/**
 * Created by PhpStorm.
 * User: dat.tnt
 * Date: 2019/10/23
 * Time: 12:24
 */
namespace App\Controller;

use App\Libs\ConfigUtil;
use App\Libs\ValueUtil;
use Cake\Event\Event;
use Cake\ORM\TableRegistry;

/**
 * Log content controller
 */
class LogController extends AppAdminController
{
    /**
     * Override beforeFilter callback
     *
     * @return \Cake\Network\Response|null|void
     */
    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
        // Allow users to register and logout.
        // You should not add the "login" action to allow list. Doing so would
        // cause problems with normal functioning of AuthComponent.
        $this->Auth->allow(['logout']);
        //load model
        $this->loadModel('Staff');
    }

    /**
     * Override beforeRender callback
     *
     * @param \Cake\Event\Event $event The beforeRender event.
     * @return \Cake\Network\Response|null|void
     */
    public function beforeRender(Event $event) {
        parent::beforeRender($event);
        //Load layout
        $this->viewBuilder()->setLayout('login');
    }

    /**
     * Login to management system
     * A001
     *
     * @return \Cake\Network\Response|null|void
     */
    public function login(){
        //fix ERR_CACHE_MISS in chrome
        header('Cache-Control: no cache'); //no cache
        if(!isset($_SESSION))
        {
            session_cache_limiter('private_no_expire'); // works
            session_start();
        }
        $session = $this->getRequest()->getSession();
        $params = $this->request;
        $user = $this->Auth->user();
        if($user && isset($user['user_flg'])){
            $session->destroy();
            return $this->redirect(['controller' => 'Log', 'action'=> 'login']);
        }
        //Process login with form data
        if ($this->request->is('post')) {
            $loginUser = $this->Auth->identify();
            $email = trim($params->getData('email_address'));
            $password = trim(hash('sha256',$params->getData('password'), false));
            $conditions = [
                'email' => $email,
                'password' => $password,
            ];
            //Get data in staff table
            $staff = $this->Staff->getStaffLogin($conditions);
            if(count($staff->toArray()) == 1){
                $roleList = ConfigUtil::get('role');
                $roleKey = ValueUtil::get('common.user_flg_key');
                $staffData = $staff->first();
                if(!in_array($staffData->user_flg, $roleKey)) {
                    return $this->redirect(['controller' => 'Top', 'action' => 'permissionError']);
                }
                $sessionInfo = [
                    'id' => $staffData->id,
                    'user_name' => $staffData->user_name,
                    'area' => $staffData->area,
                    'user_flg' => $staffData->user_flg,
                    'role' => $roleList[$staffData->user_flg],
                ];
                //save sessions
                $this->Auth->setUser($sessionInfo);
                $session->delete('Usr.info');
                $session->write('Usr.info', $sessionInfo);
                // Update last login
                $staffData->last_login = new \DateTime();
                $this->Staff->save($staffData);
                //Redirect to current page
                return $this->redirect($this->Auth->redirectUrl());
            }else{
                $this->Flash->error(ConfigUtil::getMessage("ECL017"), ['escape' => false]);
            }
        }
    }

    /**
     * Logout function
     * @return \Cake\Http\Response|null
     */
    public function logout()
    {
        $session = $this->request->session();
        $session->destroy();
        return $this->redirect($this->Auth->logout());
    }
}
