<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * TicketManager Entity
 *
 * @property int $id
 * @property int|null $fan_id
 * @property int|null $ticket_id
 * @property int|null $order_items_id
 * @property int $used_ticket
 * @property int|null $created_by
 * @property \Cake\I18n\FrozenTime|null $created_at
 * @property int|null $updated_by
 * @property \Cake\I18n\FrozenTime|null $updated_at
 * @property int|null $deleted_by
 * @property \Cake\I18n\FrozenTime|null $deleted_at
 *
 * @property \App\Model\Entity\Fan $fan
 * @property \App\Model\Entity\MastTicket $mast_ticket
 * @property \App\Model\Entity\OrderItem $order_item
 */
class TicketManager extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'id' => false,
        '*' => true,
    ];
}
